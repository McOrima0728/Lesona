(function() {
  var pageId = 'fikasana';

  var chapters = [];
  var currentView = 'list';
  var currentChapterIndex = null;
  var currentSearchQuery = '';

  function loadChapters() {
    return new Promise(function(resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'data/lisitra/fikasana.json');
      xhr.onload = function() {
        if (xhr.status === 200) {
          try {
            var data = JSON.parse(xhr.responseText);
            resolve(data.fikasana);
          } catch (e) {
            console.error("Erreur de parsing JSON:", e);
            reject([]);
          }
        } else {
          console.error("Erreur de chargement des chapitres:", xhr.statusText);
          reject([]);
        }
      };
      xhr.onerror = function() {
        console.error("Erreur réseau lors du chargement des chapitres.");
        reject([]);
      };
      xhr.send();
    });
  }

  function getTitle(chapter) {
    for (var key in chapter) {
      if (key.startsWith('title_')) {
        return chapter[key];
      }
    }
    return 'Titre inconnu';
  }

  function formatTitleCase(str) {
    if (!str) return '';
    return str.toLowerCase().split(' ').map(function(word) {
      return word.charAt(0).toUpperCase() + word.slice(1);
    }).join(' ');
  }

  function renderList() {
    return (
      '<div class="spa-page" id="fikasana-page">' +
        '<div class="spa-header">' +
          '<img src="assets/icons/arrow_back.svg" alt="Back" class="back-button">' +
          '<div class="title">Teny fikasana</div>' +
          '<img src="assets/icons/search.svg" alt="Search" class="search-button">' +
        '</div>' +
        '<div class="spa-content list-container">' +
          '<div class="list">' +
            '<div class="loading">' +
              '<div class="spinner-button-container">' +
                '<div class="spinner-button"></div>' +
                '<div class="spinner-button delay-1"></div>' +
                '<div class="spinner-button delay-2"></div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<style>' +
          '.spa-header {' +
          'display: flex;' +
          'align-items: center;' +
          'justify-content: space-between;' +
          'padding-left: 12px;' +
          'position: fixed;' +
          'top: 0;' +
          'width: 100%;' +
          'background: #006A60;' +
          'z-index: 1000;' +
          'box-shadow: 0 2px 5px rgba(0,0,0,0.2);' +
        '}' +
        '.spa-page { position: relative; height: 100%; overflow: hidden; }' +
        
        '.spa-header .search-button {' +
          'margin-right: 0;' +
          'cursor: none;' +
        '}' +
          '.spa-header .title {' +
            'flex-grow: 1;' +
            'text-align: left;' +
          '}' +
          '.spa-page-nested .spa-header {' +
            'display: flex;' +
            'align-items: center;' +
          '}' +
          
          '.spa-page-nested .spa-header .title {' +
            'flex: 1 1 auto;' +
            'min-width: 0;' +
            'white-space: nowrap;' +
            'overflow: hidden;' +
            'text-overflow: ellipsis;' +
            'margin-right: 20px;' +
          '}' +
          '.spa-header .search-button {' +
            'cursor: none;' +
          '}' +
          '.list-container { padding: 0px; margin-top:50px; min-height: 300px; position: relative; }' +
          '.list { display: flex; flex-direction: column; gap: 0px; }' +
          '.row { display: flex; align-items: center; gap: 15px; padding: 15px; color: #424242; border-bottom: 1px solid #d9d9d9;}' +
          '.row:active { background:rgba(0,0,0,0.05); }' +
          '.row .icon { width: 24px; height: 24px; filter:invert(0.5); }' +
          '.row .meta { flex-grow: 1; }' +
          '.row .title { font-size: 18px; font-weight: bold; color: #424242}' +
          
          '.row .subtitle { font-size: 14px; color: #757575; margin-top: 4px;}' +
          '.loading {' +
            'position: absolute;' +
            'top: 50%;' +
            'left: 50%;' +
            'transform: translate(-50%, -50%);' +
            'display: flex;' +
            'justify-content: center;' +
          '}' +

          '/* NOUVELLES RÈGLES POUR LES TROIS BOUTONS SPIN */' +
          '.spinner-button-container {' +
            'display: flex;' +
            'gap: 10px;' +
            'align-items: center;' +
            'justify-content: center;' +
          '}' +
          '.spinner-button {' +
            'width: 10px;' +
            'height: 10px;' +
            'border-radius: 50%;' +
            'background-color: #006A60;' +
            'animation: bounce 1s infinite;' +
          '}' +
          '.spinner-button.delay-1 {' +
            'animation-delay: 0.1s;' +
          '}' +
          '.spinner-button.delay-2 {' +
            'animation-delay: 0.2s;' +
          '}' +
          '@keyframes bounce {' +
            '0%, 80%, 100% {' +
              'transform: scale(0);' +
              'opacity: 0;' +
            '}' +
            '40% {' +
              'transform: scale(1);' +
              'opacity: 1;' +
            '}' +
          '}' +
          '/* FIN DES NOUVELLES RÈGLES */' +

          '.error { text-align: center; color: #fff; padding: 20px; }' +
        '</style>' +
      '</div>'
    );
  }

  function renderListContent(loadedChapters) {
    return loadedChapters.map(function(chap, i) {
      return (
        '<div class="row chapter-item" data-index="' + i + '">' +
          '<img class="icon" src="assets/icons/promesse.svg" alt="Icon" />' +
          '<div class="meta">' +
            '<div class="title">' + formatTitleCase(getTitle(chap)) + '</div>' +
            '<div class="subtitle">' + chap.definition + '</div>' +
          '</div>' +
        '</div>'
      );
    }).join('');
  }

  function renderChapterContent(chapter) {
    var paragraphsHtml = chapter.paragraphs.map(function(p, i) {
      var parts = p.text.split(' - ');
      if (parts.length > 1) {
        var verseText = parts[0].trim();
        var verseReference = parts.slice(1).join(' - ').trim().replace(/;$/, '');
        return (
          '<div class="verse-block">' +
            '<h4 class="verse-reference">' + verseReference + '</h4>' +
            '<p id="' + p.id + '" data-paragraph-index="' + i + '">' + verseText + '</p>' +
          '</div>'
        );
      } else {
        return '<p id="' + p.id + '" data-paragraph-index="' + i + '" class="single-paragraph">' + p.text + '</p>';
      }
    }).join('');

    return (
      '<div class="spa-page-nested" id="fikasana-content-page">' +
        '<header class="spa-header transparent">' +
          '<img src="assets/icons/arrow_back.svg" alt="Back" class="chapter-back-button">' +
          '<div class="title hidden">' + formatTitleCase(getTitle(chapter)) + '</div>' +
          '<div style="display: flex; gap: 30px;">' +
              '<img src="assets/icons/copy.svg" alt="Copy" class="copy-button">' +
              '<img src="assets/icons/share.svg" alt="Share" class="share-button">' +
          '</div>' +
        '</header>' +
        '<div class="spa-content content-container">' +
          '<div class="image-container">' +
            '<img src="' + chapter.header_image + '" alt="Header Image" class="header-image" />' +
            '<div class="image-title">' + formatTitleCase(getTitle(chapter)) + '</div>' +
          '</div>' +
          paragraphsHtml +
        '</div>' +
        '<div id="copy-feedback" class="copy-feedback">Chapitres copiés</div>' +
        '<style>' +
          '.content-container { padding: 0px; padding-bottom: 20px; color: #2C2C2C; margin-top:0px;}' +
          '.verse-block {' +
            'background-color: #F6F7FC;' +
            'border: 1px solid #d9d9d9;' +
            'border-radius: 10px;' +
            'padding: 15px;' +
            'margin: 10px 6px;' +
          '}' +
          '.verse-reference {' +
            'font-weight: bold;' +
            'font-size: 18px;' +
            'color: #006A60;' +
            'margin-bottom: 10px;' +
            'text-align: left;' +
          '}' +
          '.verse-block p, .single-paragraph { ' +
            'font-size: 22px; ' +
            'line-height: 1.6; ' +
            'text-align:left;' +
            'margin: 0;' +
            'padding: 0;' +
          '}' +
          '.single-paragraph {' +
            'background-color: #F8F4F0;' +
            'border-radius: 10px;' +
            'padding:15px;' +
            'margin: 10px 6px; ' +
          '}' +
          'strong {color:#BF9B7A; font-style:italic;}' +
          '.image-container { position: relative; text-align: left; margin-bottom: 6px; overflow: hidden; }' +
          '.header-image { width: 100%; height: 350px; border-radius: 0px; object-fit: cover; transition: height 0.2s ease; }' +
          '.image-title {' +
            'position: absolute;' +
            'bottom: 20px;' +
            'left: 10px;' +
            'color: #fff;' +
            'font-size: 20px;' +
            'font-weight: bold;' +
            'text-shadow: 1px 1px 4px rgba(0,0,0,0.7);' +
            'transition: font-size 0.2s ease, bottom 0.2s ease;' +
          '}' +
          '.highlight {' +
            'background-color: #ffff00;' +
            'color: #2C2C2C;' +
            'transition: background-color 0.5s ease-out;' +
          '}' +
          
          '/* NOUVELLE CLASSE POUR LE PARAGRAPHE COMPLET */' +
          '.highlight-paragraph {' +
            'background-color: rgba(255, 255, 0, 0.2);' +
            'transition: background-color 0.5s ease;' +
          '}' +

          '/* NOUVEAU CSS POUR L\'EN-TÊTE DU CHAPITRE */' +
          '#fikasana-content-page .spa-header.transparent {' +
            'background: transparent;' +
            'box-shadow: none;' +
            'transition: background 0.3s ease, box-shadow 0.3s ease;' +
            'justify-content: space-between;' +
          '}' +
          
          '#fikasana-content-page .spa-header.scrolled {' +
            'background: #006A60;' +
            'box-shadow: 0 2px 5px rgba(0,0,0,0.2);' +
          '}' +

          '#fikasana-content-page .spa-header .share-button,' +
          '#fikasana-content-page .spa-header .copy-button {' +
            'margin-right: 0px;' +
            'cursor: none;' +
          '}' +
          
          '/* Règle pour le titre */' +
          '#fikasana-content-page .spa-header .title {' +
            'opacity: 0;' +
            'transition: opacity 0.3s ease;' +
          '}' +
          
          '#fikasana-content-page .spa-header.scrolled .title {' +
            'opacity: 1;' +
          '}' +

          '/* Style pour le message de feedback de copie */' +
          '.copy-feedback {' +
            'position: fixed;' +
            'bottom: 20px;' +
            'left: 50%;' +
            'transform: translateX(-50%);' +
            'background-color: #d9d9d9;' +
            'color: #000000;' +
            'padding: 10px 20px;' +
            'border-radius: 50px;' +
            'z-index: 2000;' +
            'opacity: 0;' +
            'transition: opacity 0.5s ease-in-out;' +
            'font-size: 16px;' +
          '}' +

          '.copy-feedback.show {' +
            'opacity: 1;' +
          '}' +
        '</style>' +
      '</div>'
    );
  }

  function renderSearchPage() {
    return (
      '<div class="spa-page-nested" id="fikasana-search-page">' +
        '<header class="spa-header">' +
          '<img src="assets/icons/arrow_back.svg" alt="Back" class="search-back-button">' +
          '<div class="search-box">' +
            '<input type="text" id="search-input" placeholder="Rechercher un mot..." value="' + currentSearchQuery + '">' +
          '</div>' +
        '</header>' +
        '<div id="search-count-container">' +
          '<div id="search-results-count"></div>' +
        '</div>' +
        '<div class="spa-content search-results-container">' +
          '<div id="search-results" class="list"></div>' +
        '</div>' +
        '<style>' +
          '#fikasana-search-page .spa-header {' +
            'display: flex;' +
            'align-items: center;' +
            'gap: 5px;' +
            'padding: 10px;' +
          '}' +
          '.search-box {' +
            'flex-grow: 1;' +
          '}' +
          '#search-input {' +
            'width: 90%;' +
            'padding: 0px;' +
            'border: none;' +
            'background: none;' +
            'color: #fff;' +
            'font-size: 16px;' +
            'box-sizing: border-box;' +
          '}' +
          '#search-input:focus {' +
            'outline: none;' +
            'background: none;' +
          '}' +
          '#search-input::placeholder {' +
            'color: #f9f9f9;' +
          '}' +
          '#search-count-container {' +
            'position: fixed;' +
            'top: 50px;' +
            'width: 100%;' +
            'padding: 10px;' +
            'background: transparent;' +
            'color: #2C2C2C;' +
            'text-align: left;' +
            'z-index: 999;' +
            'font-weight:bold;' +
          '}' +
          '.search-results-container {' +
            'margin-top: 90px;' +
            'padding: 0px;' +
            'position: relative;' +
            'height: 100%;' +
          '}' +
          '.search-results-item {' +
            'padding: 15px;' +
            'border-bottom: 1px solid #d9d9d9;' +
          '}' +
          '.search-results-item h4 {' +
            'margin: 0;' +
            'color: #fff;' +
          '}' +
          '.search-results-item p {' +
            'margin: 15px 0 0;' +
            'color: #f9f9f9;' +
            'font-size: #757575;' +
          '}' +
          '.highlight-search {' +
            'background-color: yellow;' +
            'color: black;' +
          '}' +
          '.search-empty-icon {' +
            'position: absolute;' +
            'top: 50%;' +
            'left: 50%;' +
            'transform: translate(-50%, -50%);' +
            'opacity: 0.5;' +
            'width: 50px;' +
            'height: 50px;' +
            'filter:invert(0.5);' +
          '}' +
        '</style>' +
      '</div>'
    );
  }

  function performSearch(query) {
    var resultsContainer = document.getElementById('search-results');
    var resultsCountContainer = document.getElementById('search-results-count');
    if (!resultsContainer || !resultsCountContainer) return;

    resultsContainer.innerHTML = '';
    
    if (query.length < 2) {
      resultsContainer.innerHTML = '<img src="assets/icons/empty.svg" alt="Search icon" class="search-empty-icon">';
      resultsCountContainer.textContent = '';
      return;
    }

    var lowerCaseQuery = query.toLowerCase();
    var results = [];

    chapters.forEach(function(chapter, chapterIndex) {
      var title = getTitle(chapter);
      if (title.toLowerCase().includes(lowerCaseQuery)) {
        results.push({
          chapterIndex: chapterIndex,
          title: formatTitleCase(title),
          snippet: 'Titre : ' + title,
          isTitle: true,
          paragraphId: null
        });
      }

      chapter.paragraphs.forEach(function(paragraph) {
        if (paragraph.text.toLowerCase().includes(lowerCaseQuery)) {
          var parts = paragraph.text.split(' - ');
          var textSnippet = parts[0];
          var words = textSnippet.split(' ');
          var firstOccurrenceIndex = words.findIndex(function(word) { return word.toLowerCase().includes(lowerCaseQuery); });
          var snippetStart = Math.max(0, firstOccurrenceIndex - 5);
          var snippetEnd = Math.min(words.length, firstOccurrenceIndex + 10);
          var snippet = words.slice(snippetStart, snippetEnd).join(' ') + '...';
          
          results.push({
            chapterIndex: chapterIndex,
            title: formatTitleCase(title),
            snippet: snippet.replace(new RegExp(query, 'gi'), '<span class="highlight-search">' + query + '</span>'),
            paragraphId: paragraph.id
          });
        }
      });
    });

    resultsCountContainer.textContent = results.length + ' résultat' + (results.length > 1 ? 's' : '') + ' trouvé' + (results.length > 1 ? 's' : '');

    if (results.length > 0) {
      resultsContainer.innerHTML = results.map(function(result) {
        return (
          '<div class="row search-results-item chapter-item" data-index="' + result.chapterIndex + '" data-paragraph-id="' + result.paragraphId + '">' +
            '<div class="meta">' +
              '<div class="title">' + result.title + '</div>' +
              '<div class="subtitle">' + result.snippet + '</div>' +
            '</div>' +
          '</div>'
        );
      }).join('');
    } else {
      resultsContainer.innerHTML = '';
    }
  }

  function showChapter(index, query, paragraphId) {
    var page = document.getElementById('fikasana-page');
    if (!page) return;

    var chapter = chapters[index];
    if (!chapter) return;

    page.insertAdjacentHTML('beforeend', renderChapterContent(chapter));
    
    var nestedPage = page.querySelector('#fikasana-content-page');
    var backButton = nestedPage.querySelector('.chapter-back-button');
    var shareButton = nestedPage.querySelector('.share-button');
    var copyButton = nestedPage.querySelector('.copy-button');
    var headerImage = nestedPage.querySelector('.header-image');
    var imageTitle = nestedPage.querySelector('.image-title');
    var contentContainer = nestedPage.querySelector('.spa-content');
    var chapterHeader = nestedPage.querySelector('.spa-header');
    var copyFeedback = nestedPage.querySelector('#copy-feedback');

    if (backButton) {
      backButton.onclick = function() { window.history.back(); };
    }
    
    if (shareButton) {
        shareButton.onclick = function() {
            var message = 'Découvrez ce chapitre de \'Hery fikasana\': ' + getTitle(chapter) + '\n\n' + chapter.paragraphs.map(function(p) { return p.text; }).join('\n\n');
            var subject = getTitle(chapter);
            var file = null;
            var url = window.location.href;

            if (window.plugins && window.plugins.socialsharing) {
                window.plugins.socialsharing.share(message, subject, file, url, function(result) {
                    console.log("Partage réussi:", result);
                }, function(error) {
                    console.error("Erreur lors du partage:", error);
                });
            } else if (navigator.share) {
                navigator.share({
                    title: getTitle(chapter),
                    text: message,
                    url: url
                })
                .then(function() {
                    console.log('Partage Web API réussi.');
                })
                .catch(function(error) {
                    console.error('Erreur lors du partage avec le Web API:', error);
                });
            } else {
                console.warn('Ni le plugin Cordova ni le Web Share API ne sont disponibles pour le partage.');
            }
        };
    }

    if (copyButton) {
        copyButton.onclick = function() {
            var textToCopy = getTitle(chapter) + '\n\n' + chapter.paragraphs.map(function(p) { return p.text; }).join('\n\n');
            if (navigator.clipboard) {
              navigator.clipboard.writeText(textToCopy)
              .then(function() {
                copyFeedback.classList.add('show');
                setTimeout(function() {
                    copyFeedback.classList.remove('show');
                }, 2000);
              })
              .catch(function(error) {
                console.error('Erreur lors de la copie:', error);
              });
            } else {
              var textarea = document.createElement('textarea');
              textarea.value = textToCopy;
              textarea.style.position = 'fixed';
              document.body.appendChild(textarea);
              textarea.focus();
              textarea.select();
              try {
                document.execCommand('copy');
                copyFeedback.classList.add('show');
                setTimeout(function() {
                    copyFeedback.classList.remove('show');
                }, 2000);
              } catch (err) {
                console.error('Erreur lors de la copie via execCommand:', err);
              }
              document.body.removeChild(textarea);
            }
        };
    }
    
    contentContainer.addEventListener('scroll', function(e) {
      var scrollTop = e.target.scrollTop;
      var minHeight = 50;
      var newHeight = Math.max(350 - scrollTop, minHeight);
      headerImage.style.height = newHeight + 'px';

      var scaleTitle = Math.max(1, newHeight / 350);
      imageTitle.style.fontSize = 20 * scaleTitle + 'px';
      imageTitle.style.bottom = 20 * scaleTitle + 'px';
      
      if (scrollTop > 150) {
        chapterHeader.classList.add('scrolled');
      } else {
        chapterHeader.classList.remove('scrolled');
      }
    });

    if (query && paragraphId) {
      var targetParagraph = document.getElementById(paragraphId);
      if (targetParagraph) {
        var verseBlock = targetParagraph.closest('.verse-block');
        if (verseBlock) {
          verseBlock.classList.add('highlight-paragraph');
          setTimeout(function() { verseBlock.classList.remove('highlight-paragraph'); }, 5000);
        } else {
          targetParagraph.classList.add('highlight-paragraph');
          setTimeout(function() { targetParagraph.classList.remove('highlight-paragraph'); }, 5000);
        }

        var highlightedText = targetParagraph.innerHTML.replace(new RegExp(query, 'gi'), function(match) { return '<span class="highlight">' + match + '</span>'; });
        targetParagraph.innerHTML = highlightedText;
        
        targetParagraph.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        setTimeout(function() {
            var highlightedSpans = targetParagraph.querySelectorAll('.highlight');
            highlightedSpans.forEach(function(span) {
                span.outerHTML = span.innerHTML;
            });
        }, 5000);
      }
    }
    
    setTimeout(function() {
        nestedPage.classList.add('active');
    }, 10);
  }

  function showSearchPage() {
    var page = document.getElementById('fikasana-page');
    if (!page) return;

    page.insertAdjacentHTML('beforeend', renderSearchPage());
    
    var nestedPage = page.querySelector('#fikasana-search-page');
    var backButton = nestedPage.querySelector('.search-back-button');
    var searchInput = nestedPage.querySelector('#search-input');
    var resultsContainer = nestedPage.querySelector('#search-results');
    
    if (backButton) {
      backButton.onclick = function() { window.history.back(); };
    }
    
    if (searchInput) {
      searchInput.focus();
      searchInput.addEventListener('input', function(e) {
        currentSearchQuery = e.target.value;
        performSearch(currentSearchQuery);
      });
    }

    if (resultsContainer) {
      resultsContainer.onclick = function(e) {
        var row = e.target.closest('.chapter-item');
        if (row) {
          var index = parseInt(row.dataset.index);
          var paragraphId = row.dataset.paragraphId;
          hideSearchPage();
          showChapter(index, currentSearchQuery, paragraphId);
          window.history.pushState({ spa: pageId, view: 'content', chapter: index, paragraphId: paragraphId }, "");
        }
      };
    }

    performSearch(currentSearchQuery);

    setTimeout(function() {
        nestedPage.classList.add('active');
    }, 10);
  }

  function hideChapter() {
    var page = document.getElementById('fikasana-page');
    if (!page) return;

    var nestedPage = page.querySelector('#fikasana-content-page');
    if (nestedPage) {
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(function() {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  function hideSearchPage() {
    var page = document.getElementById('fikasana-page');
    if (!page) return;

    var nestedPage = page.querySelector('#fikasana-search-page');
    if (nestedPage) {
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(function() {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  function init() {
    var page = document.getElementById('fikasana-page');
    if (!page) return;
    
    var backButton = page.querySelector('.back-button');
    if (backButton) {
      backButton.onclick = function() { window.history.back(); };
    }

    var searchButton = page.querySelector('.search-button');
    if (searchButton) {
      searchButton.onclick = function() {
        currentSearchQuery = '';
        showSearchPage();
        window.history.pushState({ spa: pageId, view: 'search' }, "");
      };
    }

    var listContainer = page.querySelector('.list-container .list');
    
    loadChapters().then(function(loadedChapters) {
      chapters = loadedChapters;
      if (chapters.length > 0) {
        listContainer.innerHTML = renderListContent(chapters);
      } else {
        listContainer.innerHTML = '<div class="error">Impossible de charger le contenu.</div>';
      }

      listContainer.onclick = function(e) {
        var row = e.target.closest('.chapter-item');
        if (row) {
          currentChapterIndex = parseInt(row.dataset.index);
          showChapter(currentChapterIndex);
          window.history.pushState({ spa: pageId, view: 'content', chapter: currentChapterIndex }, "");
        }
      };
    });
  }

  function handlePopState(state) {
    var spaPage = document.getElementById('fikasana-page');
    if (!spaPage) return;
    
    if (state && state.spa === pageId) {
      if (state.view === 'content' && state.chapter !== undefined) {
        if (parseInt(state.chapter) !== currentChapterIndex) {
            hideSearchPage();
            showChapter(parseInt(state.chapter));
        }
        currentView = 'content';
        currentChapterIndex = parseInt(state.chapter);
      } else if (state.view === 'search') {
          hideChapter();
          showSearchPage();
          currentView = 'search';
          currentChapterIndex = null;
      } else if (state.view === 'list') {
        hideChapter();
        hideSearchPage();
        currentView = 'list';
        currentChapterIndex = null;
      } else {
        window.history.back();
      }
    } else {
      hideSpaPage();
    }
  }

  window.drawerPages = window.drawerPages || {};
  window.drawerPages[pageId] = {
    render: function() {
      currentView = 'list';
      currentChapterIndex = null;
      return renderList();
    },
    init: init,
    destroy: function() {},
    handlePopState: handlePopState
  };

})();