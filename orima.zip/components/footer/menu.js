(function(){
  const container = document.getElementById("menu");
  container.innerHTML = `<div class="list"></div>`;
  const list = container.querySelector('.list');

  const items = [
    {id: 'fahasalamana', icon:'assets/icons/health.svg', title:'Fahasalamana', subtitle:'Torohevitra mahasoa'},
    {id: 'toriteny', icon:'assets/icons/mic.svg', title:'Toriteny', subtitle:'Fianarana toriteny'},
    {id: 'fikasana', icon:'assets/icons/menu_book.svg', title:'Teny fikasana', subtitle:'Fampaherezana'},
    {id: 'fampianarana', icon:'assets/icons/book.svg', title:'Fandalinana ara-Baiboly', subtitle:'Inona ny marina ?'},
    {id: 'hafatra', icon:'assets/icons/message.svg', title:'Hafatra feno fanovozan-kery', subtitle:'Hafatra fampaherezana'},
    {id: 'fanomezana', icon:'assets/icons/gift.svg', title:'Fanomezam-pahasoavana', subtitle:'Ny andraikitra kristiana'},
    {id: 'tonokalo', icon:'assets/icons/brush.svg', title:'Tononkalo', subtitle:'Ny asa-soratra'}
  ];

  items.forEach(it=>{
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `
      <div class="icon-bg">
        <img src="${it.icon}" alt="${it.title}" class="left"/>
      </div>
      <div class="meta">
        <div class="title">${it.title}</div>
        <div class="subtitle">${it.subtitle}</div>
      </div>`;

    row.onclick = () => {
      window.goToSpaPage(it.id);
    };
    
    list.appendChild(row);
  });

  const style = document.createElement('style');
  style.textContent = `
    #menu .list {
      display:flex;
      flex-direction:column;
    }
    #menu .row {
      display:flex;
      align-items:center;
      gap:12px;
      padding:15px;
      background:transparent;
      border:none;
      text-align:left;
      cursor:none;
      width:100%;
      border-bottom:1px solid #d9d9d9;
    }
    #menu .row:active {
      background:rgba(0,0,0,0.05);
    }
    #menu .icon-bg {
      display:flex;
      align-items:center;
      justify-content:center;
      width:42px;
      height:42px;
      background:#F6F7FC;
      border-radius:8px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.12),
                  0 1px 2px rgba(0,0,0,0.24);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    #menu .left {
      width:22px;
      height:22px;
      filter:invert(0.5);
    }
    #menu .meta .title {
      font-weight:bold;
      color:#4E3D43;
      font-size:17px;
    }
    #menu .meta .subtitle {
      font-size:15px;
      color:#757575;
      margin-top:3px;
    }
  `;
  document.head.appendChild(style);
})();