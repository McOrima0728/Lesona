window.drawerPages = window.drawerPages || {};

window.drawerPages["mofo"] = {
    render: function() {
        return ''
            + '<style>'
            + '.spa-page { position: relative; height: 100%; overflow: hidden; }'
            + '.spa-headers { position: fixed; top: 0; left: 0; width: 100%; height: 50px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; z-index: 100; background-color: transparent; transition: background-color 0.3s, box-shadow 0.3s; }'
            + '.spa-headers.scrolled { background-color: #006A60; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }'
            + '.spa-headers img { width: 24px; height: 24px; }'
            + '.header-left, .header-right { display: flex; align-items: center; }'
            + '.header-left img, .header-right img { display: flex; align-items: center; justify-content: center; width: 48px; height: 48px; transition: background-color 0.2s; padding: 12px; margin: -12px; }'
            + '.spa-headers .titles { font-size: 18px; font-weight: bold; color: transparent; transition: color 0.3s; margin-left: 8px; max-width: 90%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }'
            + '.spa-headers.scrolled .titles { color: #ffffff; }'
            + '.spa-content { position: absolute; top: 0; left: 0; right: 0; bottom: 0; overflow-y: scroll; padding-top: 0px; }'
            + '.mofo-image-container { width: 100%; height: 350px; overflow: hidden; position: relative; }'
            + '.mofo-image-container img { width: 100%; height: 100%; object-fit: cover; display: block; }'
            + '.mofo-image-container .mofo-actions { position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); display: flex; gap: 40px; padding-bottom: 20px; }'
            + '.mofo-content-container { background: #ffffff; border-top-left-radius: 10px; border-top-right-radius: 10px; margin-top: -20px; padding: 14px; position: relative; display: none; }'
            + '.mofo-content-container .mofo-date { color: #888; font-size: 16px; text-align: center; margin-bottom: 8px; }'
            + '.mofo-content-container .h2-wrapper { display: flex; align-items: center; justify-content: center; margin-bottom: 16px; }'
            + '.mofo-content-container .h2-wrapper::before, .mofo-content-container .h2-wrapper::after { content: ""; flex-grow: 1; height: 2px; background-color: #006A60; }'
            + '.mofo-content-container h2 { color: #006A60; font-size: 22px; margin: 0 16px; white-space: nowrap; }'
            + '.mofo-content-container p { color: #424242; line-height: 1.7; margin-bottom: 16px; text-align: left; font-size: 18px; }'
            + '.mofo-content-container p span.verse-number { font-weight: bold; margin-right: 6px; color: #006A60; }'
            + '.mofo-content-container p.first-verse::first-letter { font-size: 36px; font-weight: bold; float: left; line-height: 1; margin-right: 6px; color: #006A60; }'
            + '.mofo-actions .action-button { background-color: rgba(255, 255, 255, 0.2); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; transition: background-color 0.2s; }'
            + '.mofo-actions .action-button:active { background-color: rgba(28, 98, 126, 0.1); }'
            + '.mofo-actions .action-button img { width: 22px; height: 22px; }'
            + '.toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 2px; padding: 16px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); opacity: 0; transition: visibility 0s, opacity 0.5s linear; }'
            + '.toast.show { visibility: visible; opacity: 1; }'
            + '@keyframes shimmer { 0% { background-position: -468px 0; } 100% { background-position: 468px 0; } }'
            + '.mofo-skeleton { background: #fff; border-top-left-radius: 10px; border-top-right-radius: 10px; margin-top: -20px; padding: 14px; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); }'
            + '.skeleton-box { height: 20px; background: #f6f7f8; background-image: linear-gradient(to right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%); background-repeat: no-repeat; background-size: 800px 100%; animation: shimmer 1.5s infinite linear; border-radius: 4px; }'
            + '.skeleton-title { width: 60%; height: 28px; margin: 0 auto 16px; }'
            + '.skeleton-line { width: 100%; height: 18px; margin-bottom: 12px; }'
            + '.skeleton-line:last-child { width: 80%; }'
            + '</style>'
            + '<div class="spa-page">'
            + '<header class="spa-headers">'
            + '<div class="header-left">'
            + '<img src="assets/icons/arrow_back.svg" alt="Retour" onclick="history.back()">'
            + '<div class="titles" id="header-title">Fiambenana Maraina</div>'
            + '</div>'
            + '<div class="header-right">'
            + '<img src="assets/icons/share.svg" alt="Partager" onclick="window.drawerPages.mofo.shareVerse()">'
            + '</div>'
            + '</header>'
            + '<div class="spa-content">'
            + '<div class="mofo-image-container">'
            + '<img src="assets/acceuil/breads.jpg" alt="Velomin\'ny Teniny">'
            + '</div>'
            + '<div class="mofo-content-container" id="mofo-content">'
            + '<p id="mofo-date" class="mofo-date"></p>'
            + '<div class="h2-wrapper"><h2 id="mofo-title"></h2></div>'
            + '<div id="mofo-verses"></div>'
            + '</div>'
            + '<div id="mofo-skeleton" class="mofo-skeleton">'
            + '<p id="skeleton-date" class="mofo-date"></p>'
            + '<div class="h2-wrapper"><div class="skeleton-box skeleton-title"></div></div>'
            + '<div id="skeleton-lines">'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '</div>'
            + '</div>'
            + '</div>'
            + '<div id="toast" class="toast"></div>'
            + '</div>';
    },

    showToast: function(message) {
        var toast = document.getElementById("toast");
        toast.innerHTML = message;
        toast.className = "toast show";
        setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
    },

    loadVerse: function() {
        var mofoDate = document.getElementById("mofo-date");
        var skeletonDate = document.getElementById("skeleton-date");
        var mofoTitle = document.getElementById("mofo-title");
        var headerTitle = document.getElementById("header-title");
        var mofoVerses = document.getElementById("mofo-verses");
        var mofoContent = document.getElementById("mofo-content");
        var mofoSkeleton = document.getElementById("mofo-skeleton");

        mofoContent.style.display = 'none';
        mofoSkeleton.style.display = 'block';

        var today = new Date();
        var monthNames = ["Janoary","Febroary","Martsa","Aprily","Mey","Jona","Jolay","Aogositra","Septambra","Oktobra","Novambra","Desambra"];
        var dateText = today.getDate() + ' ' + monthNames[today.getMonth()] + ' ' + today.getFullYear();
        mofoDate.textContent = dateText;
        skeletonDate.textContent = dateText;

        var targetUrl = encodeURIComponent('https://www.advantistalyon.com/mg/fiambenana-maraina-androany');
        var proxyUrl = `https://api.allorigins.win/get?url=${targetUrl}`;

        fetch(proxyUrl)
            .then(response => { 
                if(response.ok) return response.json(); 
                throw new Error('Erreur serveur proxy'); 
            })
            .then(data => {
                var parser = new DOMParser();
                var doc = parser.parseFromString(data.contents, 'text/html');
                var mainContent = doc.querySelector('.entry-content, .post-content, .et_pb_post_content, article');

                if(mainContent) {
                    var realTitle = mainContent.querySelector('h2, h3')?.innerText || "Mofon’aina";
                    var paragraphs = Array.from(mainContent.querySelectorAll('p'))
                        .map(p => `<p>${p.innerText}</p>`).join("");

                    mofoTitle.textContent = realTitle;
                    headerTitle.textContent = realTitle;
                    mofoVerses.innerHTML = paragraphs;
                    
                    mofoSkeleton.style.display = 'none';
                    mofoContent.style.display = 'block';

                } else {
                    mofoTitle.textContent = "Mofon’aina";
                    headerTitle.textContent = "Mofon’aina";
                    mofoVerses.innerHTML = "<p>Impossible de trouver le contenu du jour.</p>";
                    mofoSkeleton.style.display = 'none';
                    mofoContent.style.display = 'block';
                }
            })
            .catch(err => {
                mofoTitle.textContent = "Mofon’aina";
                headerTitle.textContent = "Mofon’aina";
                mofoVerses.innerHTML = `<p>ressayer plus tard...</p>`;
                mofoSkeleton.style.display = 'none';
                mofoContent.style.display = 'block';
            });
    },

    shareVerse: function() {
        var titleText = document.getElementById("mofo-title").innerText;
        var versesText = document.getElementById("mofo-verses").innerText;
        var textToShare = titleText + '\n\n' + versesText;

        if (window.plugins && window.plugins.socialsharing) {
            window.plugins.socialsharing.share(textToShare, titleText, null, null,
                () => { this.showToast('Verset partagé avec succès.'); },
                () => { this.showToast('Erreur de partage.'); }
            );
        } else {
            this.showToast('Partage non disponible.');
        }
    },

    init: function() {
        console.log("Page mofo initialisée.");
        this.loadVerse();

        var header = document.querySelector(".spa-headers");
        var content = document.querySelector(".spa-content");
        var imageContainer = document.querySelector(".mofo-image-container");
        var image = imageContainer.getElementsByTagName("img")[0];
        var imageHeight = imageContainer.offsetHeight;

        content.onscroll = function() {
            var scrollY = content.scrollTop;
            if(scrollY >= imageHeight - 50) header.className = "spa-headers scrolled";
            else header.className = "spa-headers";
            imageContainer.style.height = Math.max(350, imageHeight - scrollY) + "px";
            image.style.transform = "scale(" + (1 + scrollY/1000) + ")";
        };

        // Add event listeners for network status
        window.addEventListener('online', () => {
            console.log("Network connection re-established. Reloading content...");
            this.loadVerse();
        });

        window.addEventListener('offline', () => {
            console.log("Network connection lost.");
            // Optional: you can add a toast message here
            this.showToast('Connexion Internet perdue.');
        });
    },

    destroy: function() {
        console.log("Page mofo détruite.");
        // Optional: remove event listeners on destroy to prevent memory leaks
        window.removeEventListener('online', this.loadVerse);
    }
};