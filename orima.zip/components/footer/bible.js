(function(){
  const container = document.getElementById("bible");
  container.innerHTML = `<div class="list"></div>`;

  const list = container.querySelector('.list');
  const items = [
    {id:'protestanta', title:'Baiboly protestanta', subtitle:'Dikan-teny 1865', icon:'assets/icons/menu_book.svg'},
    {id:'diem', title:'Baiboly Diem', subtitle:'Dikan-teny iombonana', icon:'assets/icons/book.svg'},
    {id:'finoana', title:'Fotom-pinoana', subtitle:'Fotom-pinoana ara-Baiboly', icon:'assets/icons/church.svg'},
    {id:'kilalao', title:'Kilalao ara-Baiboly', subtitle:'Ny Soratra Masina', icon:'assets/icons/quiz.svg'}
  ];

  items.forEach(it=>{
    const button = document.createElement('button');
    button.className = 'row';
    button.innerHTML = `
      <div class="icon-bg">
        <img src="${it.icon}" alt="${it.title}" class="left"/>
      </div>
      <div class="meta">
        <div class="title">${it.title}</div>
        <div class="subtitle">${it.subtitle}</div>
      </div>`;
    button.addEventListener('click', () => {
        window.goToSpaPage(it.id);
    });
    list.appendChild(button);
  });

  const style = document.createElement('style');
  style.textContent = `
    #bible .list {
      display:flex;
      flex-direction:column;
    }
    #bible .row {
      display:flex;
      align-items:center;
      gap:12px;
      padding:15px;
      background:transparent;
      border:none;
      text-align:left;
      cursor:none;
      width:100%;
      border-bottom:1px solid #d9d9d9;
    }
    #bible .row:active {
      background:rgba(0,0,0,0.05);
    }
    #bible .icon-bg {
      display:flex;
      align-items:center;
      justify-content:center;
      width:42px;
      height:42px;
      background:#F6F7FC;
      border-radius:8px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.12),
                  0 1px 2px rgba(0,0,0,0.24);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    #bible .left {
      width:22px;
      height:22px;
      filter:invert(0.5);
    }
    #bible .meta .title {
      font-weight:bold;
      color:#424242;
      font-size:17px;
    }
    #bible .meta .subtitle {
      font-size:15px;
      color:#757575;
      margin-top:3px;
    }
  `;
  document.head.appendChild(style);
})();