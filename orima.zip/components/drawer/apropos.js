window.drawerPages = window.drawerPages || {};

window.drawerPages["apropos"] = {
    render: function() {
        return `
            <style>
                .apropos-content {
                    padding: 14px;
                    line-height: 1.6;
                    background: #ffffff;
                    margin-top: 50px;
                }
                .apropos-content h2, .apropos-content h3 {
                    color: #757575;
                    margin-bottom: 20px;
                }
                .apropos-content p {
                    margin-bottom: 0px;
                    color: #333;
                }

                .card {
                    padding: 0px;
                    margin-bottom: 20px;
                }

                .features-list {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                    padding: 0px;
                    border-radius: 12px;
                }
                .feature-item {
                    flex: 1 1 calc(50% - 10px);
                    display: flex;
                    align-items: center;
                    padding: 8px;
                    border-radius: 8px;
                    background: #F6F7FC;
                    margin-bottom: 0px;
                    border: 1px solid #d9d9d9;
                }
                .feature-item img {
                    width: 20px;
                    height: 20px;
                    margin-right: 8px;
                }

                .developer-container {
                    display: flex;
                    align-items: center;
                    padding: 20px;
                    margin-bottom: 15px;
                    border-radius: 12px;
                    background: #F6F7FC;
                    border: 1px solid #d9d9d9;
                }
                .developer-container img {
                    width: 70px;
                    height: 70px;
                    border-radius: 50%;
                    margin-right: 15px;
                    object-fit: cover;
                }
                .developer-info h4 {
                    margin: 0;
                    font-size: 18px;
                    color: #757575;
                }
                .developer-info p {
                    margin: 5px 0 0 0;
                    font-size: 14px;
                    color: #555;
                }

                .contact-row {
                    display: flex;
                    justify-content: space-between;
                    gap: 10px;
                    margin-bottom: 50px;
                }
                .contact-btn {
                    flex: 1;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 8px;
                    background: #F6F7FC;
                    color: #2c2c2c;
                    border: none;
                    border-radius: 50px;
                    font-size: 14px;
                    cursor: none;
                    transition: 0.3s;
                }
                .contact-btn img {
                    width: 18px;
                    height: 18px;
                    margin-right: 12px;
                    filter:invert(1);
                }
                
                .version {
                    text-align: center;
                    font-size: 12px;
                    color: #888;
                    margin-top: 20px;
                }

                /* Styles pour le header fixé */
                .spa-header {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    z-index: 1000;
                    background-color: #006A60;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    padding: 14px;
                    display: flex;
                    align-items: center;
                    color: #fff;
                }
                .spa-header img {
                    width: 24px;
                    height: 24px;
                    margin-right: 10px;
                }
                .spa-header .title {
                    font-size: 20px;
                    font-weight: bold;
                }
                
            </style>

            <div class="spa-page">
                <header class="spa-header">
                    <img src="assets/icons/arrow_back.svg" alt="Retour">
                    <div class="title">À propos</div>
                </header>

                <div class="spa-content apropos-content">

                    <div class="card">
                        <p>Votre compagnon spirituel pour la méditation et l'étude de la Bible. Cette application est développée pour aider la communauté adventiste à explorer les textes sacrés facilement et efficacement.</p>
                    </div>

                    <div class="card">
                        <h3>Objectif</h3>
                        <p>Faciliter l'accès aux textes sacrés, encourager la méditation quotidienne et le développement spirituel.</p>
                    </div>

                    <div class="card">
                        <h3>Fonctionnalités</h3>
                        <div class="features-list">
                            <div class="feature-item">
                                <img src="assets/icons/bible.svg" alt="Bible"> Lecture de la Bible
                            </div>
                            <div class="feature-item">
                                <img src="assets/icons/search.svg" alt="Recherche"> Recherche rapide
                            </div>
                            <div class="feature-item">
                                <img src="assets/icons/bookmark.svg" alt="Bookmark"> Marque-pages & notes
                            </div>
                            <div class="feature-item">
                                <img src="assets/icons/moon.svg" alt="Theme"> Mode clair/sombre
                            </div>
                            <div class="feature-item">
                                <img src="assets/icons/notification.svg" alt="Notification"> Notifications de méditation
                            </div>
                        </div>
                    </div>

                    <h3>Développeur</h3>
                    <div class="developer-container">
                        <img src="assets/motivation/bible.jpg" alt="Développeur">
                        <div class="developer-info">
                            <h4>TANJONA HARISOA Orima Mickaël</h4>
                            <p>Passionné par la technologie et la spiritualité, il crée des applications intuitives et performantes.</p>
                        </div>
                    </div>

                    <h3>Contact</h3>
                    <div class="contact-row">
                        <button class="contact-btn" onclick="window.location.href='mailto:contact@nyhafatro.app'">
                            <img src="assets/icons/mail.svg" alt="Email"> Mail
                        </button>
                        <button class="contact-btn" onclick="window.open('https://wa.me/26134000000', '_blank')">
                            <img src="assets/icons/whatsapp.svg" alt="WhatsApp"> WhatsApp
                        </button>
                        <button class="contact-btn" onclick="window.open('https://www.facebook.com/nyhafatro', '_blank')">
                            <img src="assets/icons/facebook.svg" alt="Facebook"> Facebook
                        </button>
                    </div>

                    <div class="version">
                        Version 1.0.1 | Tous droits réservés © 2025
                    </div>
                </div>
            </div>
        `;
    },
    init: function() {
        console.log("Page 'À propos' initialisée.");
    },
    destroy: function() {
        console.log("Page 'À propos' détruite.");
    }
};