window.drawerPages = window.drawerPages || {};

window.drawerPages["mofonaina"] = {
    render: function() {
        return ''
            + '<style>'
            + '.spa-page { position: relative; height: 100%; overflow: hidden; }'
            + '.spa-headers { position: fixed; top: 0; left: 0; width: 100%; height: 50px; display: flex; align-items: center; justify-content: space-between; padding: 0 16px; z-index: 100; background-color: transparent; transition: background-color 0.3s, box-shadow 0.3s; }'
            + '.spa-headers.scrolled { background-color: #006A60; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }'
            + '.spa-headers img { width: 24px; height: 24px; }'
            + '.header-left { display: flex; align-items: center; overflow: hidden; }'
            + '.header-left img { display: flex; align-items: center; justify-content: center; width: 48px; height: 48px; transition: background-color 0.2s; padding: 12px; margin: -12px; }'
            + '.spa-headers .titles { font-size: 18px; font-weight: bold; color: transparent; transition: color 0.3s; margin-left: 8px; max-width: 90%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }'
            + '.spa-headers.scrolled .titles { color: #ffffff; }'
            + '.spa-content { position: absolute; top: 0; left: 0; right: 0; bottom: 0; overflow-y: scroll; padding-top: 0px; }'
            + '.mofonaina-image-container { width: 100%; height: 350px; overflow: hidden; position: relative; }'
            + '.mofonaina-image-container img { width: 100%; height: 100%; object-fit: cover; display: block; }'
            + '.mofonaina-image-container .mofonaina-actions { position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); display: flex; gap: 40px; padding-bottom: 20px; }'
            + '.mofonaina-content-container { background: #ffffff; border-top-left-radius: 20px; border-top-right-radius: 20px; margin-top: -20px; padding: 14px; position: relative; }'
            + '.mofonaina-content-container .mofonaina-date { color: #888; font-size: 16px; text-align: center; margin-bottom: 8px; }'
            + '.mofonaina-content-container h2 { color: #006A60; margin-bottom: 16px; font-size: 22px; text-align:center; text-transform:uppercase; }'
            + '.mofonaina-content-container p { color: #2c2c2c; line-height: 1.7; margin-bottom: 16px; text-align: left; font-size: 20px; }'
            + '.mofonaina-content-container p.first-verse { font-style: italic; border-left: 5px solid #006A60; padding-left: 15px; margin-bottom: 15px; }'
            + '.mofonaina-actions .action-button { background-color: rgba(255, 255, 255, 0.2); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; transition: background-color 0.2s; }'
            + '.mofonaina-actions .action-button:active { background-color: rgba(28, 98, 126, 0.1); }'
            + '.mofonaina-actions .action-button img { width: 22px; height: 22px; }'
            + '.toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 2px; padding: 16px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); opacity: 0; transition: visibility 0s, opacity 0.5s linear; }'
            + '.toast.show { visibility: visible; opacity: 1; }'
            + '.mofonaina-reference-label { font-size: 16px; font-weight: bold; color: #006A60; margin-top: 20px; margin-bottom: 10px; }'
            + '</style>'
            + '<div class="spa-page">'
            + '<header class="spa-headers">'
            + '<div class="header-left">'
            + '<img src="assets/icons/arrow_back.svg" alt="Retour" onclick="history.back()">'
            + '<div class="titles" id="header-title"></div>'
            + '</div>'
            + '</header>'
            + '<div class="spa-content">'
            + '<div class="mofonaina-image-container">'
            + '<img src="assets/acceuil/message.jpg" alt="Mofonaina" id="mofonaina-image">'
            + '<div class="mofonaina-actions">'
            + '<div class="action-button" onclick="window.drawerPages.mofonaina.shareVerse()">'
            + '<img src="assets/icons/share.svg" alt="Partager">'
            + '</div>'
            + '<div class="action-button" onclick="window.drawerPages.mofonaina.copyVerse()">'
            + '<img src="assets/icons/copy.svg" alt="Copier">'
            + '</div>'
            + '</div>'
            + '</div>'
            + '<div class="mofonaina-content-container" id="mofonaina-content">'
            + '<p id="mofonaina-date" class="mofonaina-date"></p>'
            + '<h2 id="mofonaina-title"></h2>'
            + '<p id="mofonaina-reference-label" class="mofonaina-reference-label"></p>'
            + '<div id="mofonaina-verses"></div>'
            + '</div>'
            + '</div>'
            + '<div id="toast" class="toast"></div>'
            + '</div>';
    },

    showToast: function(message) {
        var toast = document.getElementById("toast");
        toast.innerHTML = message;
        toast.className = "toast show";
        setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
    },
    
    loadMofonaina: function(date) {
        var mofonainaDate = document.getElementById("mofonaina-date");
        var mofonainaTitle = document.getElementById("mofonaina-title");
        var headerTitle = document.getElementById("header-title");
        var mofonainaVerses = document.getElementById("mofonaina-verses");
        var mofonainaReferenceLabel = document.getElementById("mofonaina-reference-label");
        var content = document.querySelector(".spa-content");
        
        var monthNames = ["Janoary", "Febroary", "Martsa", "Aprily", "Mey", "Jona", "Jolay", "Aogositra", "Septambra", "Oktobra", "Novambra", "Desambra"];
        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        mofonainaDate.innerHTML = day + ' ' + monthNames[monthIndex] + ' ' + year;

        var startDate = new Date("2022-01-14");
        startDate.setHours(0, 0, 0, 0);
        date.setHours(0, 0, 0, 0);

        var diffDays = Math.floor((date - startDate) / (1000 * 60 * 60 * 24));
        
        var localStorageKey = "mofonaina_data";
        var bookFilePath = "data/lisitra/mofonaina.json";

        // Fonction pour afficher le contenu
        var displayContent = function(data) {
            var entryIndex = (diffDays % data.length + data.length) % data.length;
            var entry = data[entryIndex];
            
            var formattedReference = entry.reference.charAt(0).toUpperCase() + entry.reference.slice(1).toLowerCase();

            mofonainaTitle.innerHTML = formattedReference;
            headerTitle.innerHTML = formattedReference;
            mofonainaReferenceLabel.innerHTML = "Toko sy andininy:";
            mofonainaVerses.innerHTML = "";
            var firstParagraph = true;
            entry.paragraphs.forEach(paragraphText => {
                var p = document.createElement("p");
                p.innerText = paragraphText;
                if(firstParagraph) {
                    p.className = "first-verse";
                    firstParagraph = false;
                }
                mofonainaVerses.appendChild(p);
            });
            content.scrollTop = 0;
        };
        
        // 1. Tenter de récupérer depuis le localStorage
        try {
            var cachedData = localStorage.getItem(localStorageKey);
            if (cachedData) {
                var data = JSON.parse(cachedData);
                displayContent(data);
                return; // Arrêter la fonction si les données sont en cache
            }
        } catch (e) {
            console.error("Erreur d'accès au localStorage:", e);
        }

        // 2. Sinon, charger via XHR et mettre en cache
        var xhr = new XMLHttpRequest();
        xhr.open("GET", bookFilePath, true);
        xhr.onreadystatechange = function(){
            if(xhr.readyState === 4 && xhr.status === 200){
                var data = JSON.parse(xhr.responseText);
                try {
                    localStorage.setItem(localStorageKey, xhr.responseText);
                } catch (e) {
                    console.error("Erreur d'écriture dans le localStorage:", e);
                }
                displayContent(data);
            }
        };
        xhr.send();
    },

    loadDailyMofonaina: function() {
        this.loadMofonaina(new Date());
    },

    setupMidnightUpdate: function() {
        var now = new Date();
        var tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
        var timeToMidnight = tomorrow.getTime() - now.getTime();

        setTimeout(function() {
            window.drawerPages.mofonaina.loadDailyMofonaina();
            window.drawerPages.mofonaina.scheduleDailyNotification();
            setInterval(function() {
                window.drawerPages.mofonaina.loadDailyMofonaina();
                window.drawerPages.mofonaina.scheduleDailyNotification();
            }, 24 * 60 * 60 * 1000);
        }, timeToMidnight);
    },

    scheduleDailyNotification: function() {
        if (window.cordova && window.cordova.plugins && window.cordova.plugins.notification.local) {
            cordova.plugins.notification.local.cancel(1, function() {
                var now = new Date();
                var notificationTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 6, 30, 0); 
                
                if (now.getHours() > 6 || (now.getHours() === 6 && now.getMinutes() >= 30)) {
                    notificationTime.setDate(now.getDate() + 1);
                }

                var monthNames = ["Janoary", "Febroary", "Martsa", "Aprily", "Mey", "Jona", "Jolay", "Aogositra", "Septambra", "Oktobra", "Novambra", "Desambra"];
                var today = new Date();
                var formattedDate = today.getDate() + ' ' + monthNames[today.getMonth()] + ' ' + today.getFullYear();
                
                var mofonainaTitle = document.getElementById("mofonaina-title").innerText;
                var notificationTitle = "Mofonaina ho an'ny androany";
                var notificationText = "Ny Mofonaina ho an'ny " + formattedDate + " dia manomboka amin'ny andinin-teny hoe: " + mofonainaTitle + ". Mirary tontolo andro sambatra.";

                cordova.plugins.notification.local.schedule({
                    id: 1,
                    title: notificationTitle,
                    text: notificationText,
                    smallIcon: 'res://icon',
                    at: notificationTime,
                    every: 'day',
                    data: { page: 'mofonaina.js' }
                });
            });
        }
    },

    copyVerse: function() {
        var versesElement = document.getElementById("mofonaina-verses");
        var versesText = versesElement.innerText;
        var titleText = document.getElementById("mofonaina-title").innerText;
        var textToCopy = titleText + '\n\n' + versesText;

        navigator.clipboard.writeText(textToCopy).then(() => {
            this.showToast('Contenu copié !');
        }).catch(() => {
            this.showToast('Impossible de copier le contenu.');
        });
    },

    shareVerse: function() {
        var titleText = document.getElementById("mofonaina-title").innerText;
        var versesElement = document.getElementById("mofonaina-verses");
        var versesText = versesElement.innerText;
        var textToShare = titleText + '\n\n' + versesText;
        
        if (window.plugins && window.plugins.socialsharing) {
            window.plugins.socialsharing.share(textToShare, null, null, null, () => {
                this.showToast('Contenu partagé avec succès.');
            }, () => {
                this.showToast('Erreur de partage.');
            });
        } else if (navigator.share) {
            var shareData = {
                title: "Mofonaina: " + titleText,
                text: textToShare,
            };
            navigator.share(shareData).then(() => {
                this.showToast('Contenu partagé avec succès.');
            }).catch(() => {
                this.showToast('Erreur de partage.');
            });
        } else {
            this.showToast('La fonction de partage n\'est pas supportée.');
        }
    },

    init: function() {
        console.log("Page Mofonaina initialisée.");
        
        this.loadDailyMofonaina();
        this.setupMidnightUpdate();
        this.scheduleDailyNotification();

        if (window.cordova && window.cordova.plugins && window.cordova.plugins.notification.local) {
            cordova.plugins.notification.local.on("click", function (notification) {
                if (notification.data && notification.data.page === 'mofonaina.js') {
                    window.location.hash = '#mofonaina'; 
                }
            });
        }

        var header = document.querySelector(".spa-headers");
        var content = document.querySelector(".spa-content");
        var imageContainer = document.querySelector(".mofonaina-image-container");
        var image = imageContainer.getElementsByTagName("img")[0];
        var imageHeight = imageContainer.offsetHeight;

        content.onscroll = function() {
            var scrollY = content.scrollTop;
            if(scrollY >= imageHeight - 50) header.className = "spa-headers scrolled";
            else header.className = "spa-headers";
            imageContainer.style.height = Math.max(350, imageHeight - scrollY) + "px";
            image.style.transform = "scale(" + (1 + scrollY/1000) + ")";
        };
    },
    destroy: function() {
        console.log("Page Mofonaina détruite.");
    }
};