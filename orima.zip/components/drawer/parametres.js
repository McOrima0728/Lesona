// Fichier : components/drawer/parametres.js

window.drawerPages = window.drawerPages || {};

window.drawerPages["parametres"] = {
    render: function() {
        return `
            <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
            <style>
                .parametres-content {
                    font-family: 'Roboto', Arial, sans-serif;
                    padding: 14px;
                    margin-top: 50px; /* Adjusted margin for the fixed header */
                    background: #ffffff;
                    border-radius: 12px;
                }

                .parametres-item {
                    margin-bottom: 30px;
                }

                .parametres-item label {
                    display: block;
                    font-weight: 500;
                    margin-bottom: 10px;
                    font-size: 14px;
                    color: #333;
                }

                .text-container {
                    min-height: 200px;
                    max-height: 200px;
                    overflow-y: auto;
                    padding: 0px;
                    border-radius: 0px;
                    background: transparent;
                    font-size: 16px;
                    line-height: 1.5;
                    font-family: 'Roboto', sans-serif;
                    transition: all 0.2s ease;
                    user-select: none;
                }

                #font-select {
                    width: 100%;
                    padding: 10px 12px;
                    border-radius: 8px;
                    border: 1px solid #ccc;
                    background: #fff;
                    font-size: 14px;
                    color: #333;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.08);
                    cursor: none;
                    transition: all 0.2s ease;
                }
                #font-select:hover {
                    border-color: #1C627E;
                    box-shadow: 0 2px 6px rgba(28,98,126,0.3);
                }
                #font-select:focus {
                    outline: none;
                    border-color: #145a75;
                    box-shadow: 0 2px 6px rgba(28,98,126,0.4);
                }

                select, input[type="range"] {
                    -webkit-appearance: none;
                    background: transparent;
                    cursor: none;
                }

                input[type="range"] {
                    width: 100%;
                }
                input[type="range"]::-webkit-slider-runnable-track {
                    height: 10px;
                    border-radius: 6px;
                    background: linear-gradient(to right, #1C627E 0%, #1C627E var(--range-progress, 50%), #ddd var(--range-progress, 50%), #ddd 100%);
                }
                input[type="range"]::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    width: 10px;
                    height: 24px;
                    border-radius: 20px;
                    background: #1C627E;
                    margin-top: -7px;
                    transition: background 0.2s;
                }
                input[type="range"]::-moz-range-track {
                    height: 6px;
                    border-radius: 3px;
                    background: #ddd;
                }
                input[type="range"]::-moz-range-progress {
                    background: #1C627E;
                    height: 6px;
                    border-radius: 3px;
                }
                input[type="range"]::-moz-range-thumb {
                    width: 16px;
                    height: 16px;
                    border-radius: 50%;
                    background: #1C627E;
                    border: none;
                }
                input[type="range"]:hover::-webkit-slider-thumb {
                    background: #145a75;
                }

                .slider-wrapper {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    width: 100%;
                }

                .slider-icon {
                    width: 24px;
                    height: 24px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    flex-shrink: 0;
                }

                .slider-track-wrapper {
                    flex-grow: 1;
                    display: flex;
                    align-items: center;
                    position: relative;
                }

                .value-display {
                    font-weight: 500;
                    font-size: 13px;
                    color: #1C627E;
                    text-align: center;
                    position: absolute;
                    top: -50px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: orange;
                    padding: 4px 6px;
                    border-radius: 20px;
                    display: none;
                    pointer-events: none;
                }

                /* Styles pour le header fixé */
                .spa-header {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    z-index: 1000;
                    background-color: #006A60;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    padding: 14px;
                    display: flex;
                    align-items: center;
                    color: #fff;
                }
                .spa-header img {
                    width: 24px;
                    height: 24px;
                    margin-right: 10px;
                }
                .spa-header .title {
                    font-size: 20px;
                    font-weight: bold;
                }
            </style>

            <div class="spa-page">
                <header class="spa-header">
                    <img src="assets/icons/arrow_back.svg" alt="Retour">
                    <div class="title">Paramètres</div>
                </header>

                <div class="spa-content parametres-content">

                    <div class="parametres-item">
                        <div class="text-container">
                            Fa toy izao no nitiavan’Andriamanitra izao tontolo izao: nomeny ny Zanani-lahy Tokana, mba tsy ho very izay rehetra mino Azy, fa hanana fiainana mandrakizay.
                        </div>
                    </div>

                    <div class="parametres-item">
                        <label>Font</label>
                        <select id="font-select">
                            <option value="Roboto" selected>Roboto</option>
                            <option value="Arial">Arial</option>
                            <option value="Times New Roman">Times New Roman</option>
                            <option value="Courier New">Courier New</option>
                        </select>
                    </div>

                    <div class="parametres-item">
                        <label>Font Size</label>
                        <div class="slider-wrapper">
                            <div class="slider-icon">
                                <img src="assets/icons/text.svg" alt="Petit" width="20" height="20">
                            </div>
                            <div class="slider-track-wrapper">
                                <input type="range" id="font-size-range" min="12" max="40" value="16">
                                <div class="value-display" id="font-size-value">16px</div>
                            </div>
                            <div class="slider-icon">
                                <img src="assets/icons/text.svg" alt="Grand" width="26" height="26">
                            </div>
                        </div>
                    </div>

                    <div class="parametres-item">
                        <label>Interligne</label>
                        <div class="slider-wrapper">
                            <div class="slider-icon">
                                <img src="assets/icons/space.svg" alt="Petit" width="20" height="20">
                            </div>
                            <div class="slider-track-wrapper">
                                <input type="range" id="line-height-range" min="0.5" max="3" step="0.1" value="1.5">
                                <div class="value-display" id="line-height-value">1.5</div>
                            </div>
                            <div class="slider-icon">
                                <img src="assets/icons/space.svg" alt="Grand" width="26" height="26">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        `;
    },

    init: function() {
        console.log("Page 'Paramètres' initialisée.");

        const textContainer = document.querySelector(".text-container");
        const fontSelect = document.getElementById("font-select");

        const fontSizeRange = document.getElementById("font-size-range");
        const fontSizeValue = document.getElementById("font-size-value");

        const lineHeightRange = document.getElementById("line-height-range");
        const lineHeightValue = document.getElementById("line-height-value");

        const updateProgress = (range) => {
            const min = parseFloat(range.min);
            const max = parseFloat(range.max);
            const val = parseFloat(range.value);
            const percent = ((val - min) / (max - min)) * 100;
            range.style.setProperty('--range-progress', percent + '%');
        };

        textContainer.style.fontFamily = fontSelect.value;
        textContainer.style.fontSize = fontSizeRange.value + "px";
        textContainer.style.lineHeight = lineHeightRange.value;

        fontSelect.addEventListener("change", () => {
            textContainer.style.fontFamily = fontSelect.value;
        });

        const setupSlider = (range, valueDisplay, applyStyle) => {
            range.addEventListener("input", () => {
                const val = range.value;
                applyStyle(val);
                valueDisplay.textContent = val + (range === lineHeightRange ? '' : 'px');
                valueDisplay.style.display = 'block';

                const thumbPosition = (val - parseFloat(range.min)) / (parseFloat(range.max) - parseFloat(range.min));
                const sliderWidth = range.clientWidth;
                const thumbOffset = thumbPosition * (sliderWidth - 10) + 5; // 10 is the thumb width, 5 is half
                valueDisplay.style.left = `${thumbOffset}px`;
                valueDisplay.style.transform = `translateX(-50%)`;
            });

            range.addEventListener("change", () => {
                valueDisplay.style.display = 'none';
            });

            updateProgress(range);
        };

        setupSlider(fontSizeRange, fontSizeValue, (val) => {
            textContainer.style.fontSize = val + "px";
            updateProgress(fontSizeRange);
        });

        setupSlider(lineHeightRange, lineHeightValue, (val) => {
            textContainer.style.lineHeight = val;
            updateProgress(lineHeightRange);
        });
    },

    destroy: function() {
        console.log("Page 'Paramètres' détruite.");
    }
};