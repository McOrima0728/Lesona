(function() {
  const pageId = 'finoana';
  const BELIEFS_DATA_PATH = 'data/lisitra/croyance.json';
  const BIBLE_VERSE_DATA_PATH = 'data/baiboly/';

  let currentView = 'list';
  let beliefsData = null;
  let currentBelief = null;
  let currentBeliefIndex = 0;
  let currentVerseReference = null;

  const spaContainer = document.getElementById('spa-container');
  let bibleDataCache = {};
  const localStorageKey = 'finoana_verse_colors';

  async function fetchBeliefsData() {
    if (beliefsData) {
      return beliefsData;
    }
    try {
      const response = await fetch(BELIEFS_DATA_PATH);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      beliefsData = data.croyances;
      currentBelief = beliefsData[0];
      currentBeliefIndex = 0;
      return beliefsData;
    } catch (error) {
      console.error("Failed to fetch beliefs data:", error);
      return null;
    }
  }

  async function fetchVerseContent(verseRef) {
      const parts = verseRef.match(/([\w\s-]+)\s+(\d+)(?::(\d+)(?:,(\d+))?)?/);
      if (!parts) return null;

      const bookName = parts[1].toLowerCase().replace(/\s/g, '-').replace(/_/g, '-');
      const chapter = parts[2];
      const verses = parts.slice(3).filter(Boolean).map(Number);

      if (!bookName || !chapter) return null;

      const bookPath = `${BIBLE_VERSE_DATA_PATH}${bookName}.json`;
      if (!bibleDataCache[bookName]) {
          try {
              const response = await fetch(bookPath);
              if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
              bibleDataCache[bookName] = await response.json();
          } catch (error) {
              console.error(`Failed to fetch book data for ${bookName}:`, error);
              return null;
          }
      }

      if (bibleDataCache[bookName] && bibleDataCache[bookName][chapter]) {
          let content = [];
          if (verses.length > 0) {
              verses.forEach(vNum => {
                  const text = bibleDataCache[bookName][chapter][vNum];
                  if (text) {
                      content.push(`<strong>${vNum}</strong> ${text}`);
                  }
              });
          } else {
              for (const vNum in bibleDataCache[bookName][chapter]) {
                  content.push(`<strong>${vNum}</strong> ${bibleDataCache[bookName][chapter][vNum]}`);
              }
          }
          return content.join('\n');
      }

      return null;
  }
  
  function renderList() {
    const beliefTitle = currentBelief ? `${currentBelief.numero} ${currentBelief.title}` : 'Loading...';
    return `
      <div class="spa-page" id="finoana-page">
        <div class="spa-header" id="list-header" style="background-color: #006A60;">
          <img src="assets/icons/menu.svg" alt="Menu" class="menu-button">
          <div class="title" id="list-title" style="opacity: 1; color: white; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; max-width: calc(100% - 90px);">
            ${beliefTitle}
          </div>
        </div>
        <div class="spa-content list-container" id="list-container" style="font-size:20px; padding-bottom: 20px;">
          <div class="belief-content" id="belief-content-placeholder" style="padding: 10px;">
            <p>Loading content...</p>
          </div>
        </div>
      </div>
    `;
  }
  
  function renderMenuPage() {
      return `
      <div class="spa-page-nested" id="menu-page">
          <div class="spa-header">
              <img src="assets/icons/arrow_back.svg" alt="Back" class="menu-back-button">
              <div class="title">Fotom-pinoana</div>
          </div>
          <div class="spa-content content-container-menu" style="margin-top: 50px; padding: 0px;">
              <ul class="nav-list" id="beliefs-list"></ul>
          </div>
      </div>
      <style>
          .spa-page-nested .spa-header { position: fixed; top: 0; width: 100%; z-index: 1000; background-color: #006A60;}
          .spa-page-nested .spa-header .title { opacity: 1; }
          .content-container-menu { padding: 0px; color: #2c2c2c; line-height: 1.6; margin-top: 50px;}
          .nav-list { list-style: none; padding: 0; }
          .nav-list-item { 
              padding: 10px; 
              border-bottom: 1px solid #d9d9d9;
              cursor: none;
              transition: background-color 0.3s ease;
              display: flex;
              align-items: center;
          }
          .nav-list-item:active { background:rgba(0,0,0,0.05); font-weight: bold; }
          .nav-list-item:last-child { border-bottom: none; }
          .nav-list-item .title { font-weight: bold; font-size: 18px; color: #2c2c2c; flex-grow: 1; }
          .nav-list-item .numero {
              font-size: 14px;
              color: #2c2c2;
              margin-right: 15px;
              display: flex;
              align-items: center;
              justify-content: center;
              width: 30px;
              height: 30px;
              border-radius: 50%;
              background-color: #F6F7FC;
              box-shadow: 0 1px 3px rgba(0,0,0,0.12),
                  0 1px 2px rgba(0,0,0,0.24);
              font-weight: bold;
              flex-shrink: 0;
          }
      </style>
      `;
  }
  
  function renderVerseActionsMenu(title, content) {
      return `
      <div class="verse-menu-container show">
          <div class="close-handle"></div>
          <div class="menu-title">${title}</div>
          <div class="verse-content-display">
              ${content}
          </div>
          <div class="menu-section action-buttons" style="margin-top: 0px;">
              <button class="action-button" id="copy-verse-button">
                  <img src="assets/icons/copy.svg" alt="Copy">
                  <span>Copier</span>
              </button>
              <button class="action-button" id="share-verse-button">
                  <img src="assets/icons/share.svg" alt="Share">
                  <span>Partager</span>
              </button>
          </div>
      </div>
      <style>
        .verse-content-display {
            padding: 10px 20px;
            max-height: 250px;
            overflow-y: auto;
            color: #fff;
            line-height: 1.6;
        }
        .verse-content-display strong {
            color: #d1c4e9;
        }
      </style>
      `;
  }

  async function fetchAndRenderBelief() {
    const placeholder = document.getElementById('belief-content-placeholder');
    if (!placeholder) return;
    
    await fetchBeliefsData();
    if (!beliefsData || beliefsData.length === 0) {
        placeholder.innerHTML = `<p>Error loading beliefs data.</p>`;
        return;
    }
    
    currentBelief = beliefsData[currentBeliefIndex];
    if (!currentBelief) {
        placeholder.innerHTML = `<p>Belief not found.</p>`;
        return;
    }

    const beliefTitle = `${currentBelief.numero} ${currentBelief.title}`;
    document.querySelector('#finoana-page .title').textContent = beliefTitle;

    let htmlContent = '';
    
    currentBelief.paragraphs.forEach(paragraph => {
        htmlContent += `<p>${paragraph}</p>`;
    });

    if (currentBelief.versets && currentBelief.versets.length > 0) {
        htmlContent += `<div class="verse-references" style="margin-top: 20px; padding: 0px; background-color: #f9f9f9; border-radius:20px;">`;
        currentBelief.versets.forEach(verse => {
            htmlContent += `<div class="verse-ref-item" data-ref="${verse}" style="font-size: 20px; font-style: italic; color: #2c2c2; cursor: none; margin-bottom: 5px; padding:20px;">${verse}</div>`;
        });
        htmlContent += `</div>`;
    }
    
    placeholder.innerHTML = htmlContent;
    setupVerseReferenceListeners();
    const listContainer = document.getElementById('list-container');
    if (listContainer) {
      listContainer.scrollTop = 0;
    }
  }

  function setupVerseReferenceListeners() {
      const verseRefs = document.querySelectorAll('.verse-ref-item');
      verseRefs.forEach(ref => {
          ref.addEventListener('click', async (event) => {
              const verseRef = event.target.dataset.ref;
              const verseTitle = event.target.textContent;
              const content = await fetchVerseContent(verseRef);
              if (content) {
                  showVerseActionsMenu(verseTitle, content);
                  currentVerseReference = { title: verseTitle, content: content };
              } else {
                  console.error("Verse content not found.");
              }
          });
      });
  }

  function showVerseActionsMenu(title, content) {
      const page = document.getElementById('finoana-page');
      if (!page) return;

      const existingMenu = page.querySelector('.verse-menu-container');
      if (existingMenu) {
          existingMenu.remove();
      }
      
      page.insertAdjacentHTML('beforeend', renderVerseActionsMenu(title, content));
      const menuContainer = page.querySelector('.verse-menu-container');

      const closeMenu = () => {
          menuContainer.classList.remove('show');
          setTimeout(() => menuContainer.remove(), 300);
      };
      
      menuContainer.querySelector('.close-handle').addEventListener('click', closeMenu);
      setupMenuActionListeners();
  }
  
  function hideVerseActionsMenu() {
    const page = document.getElementById('finoana-page');
    if (!page) return;
    const existingMenu = page.querySelector('.verse-menu-container');
    if (existingMenu) {
        existingMenu.classList.remove('show');
        setTimeout(() => existingMenu.remove(), 300);
    }
  }

  function setupMenuActionListeners() {
    document.getElementById('copy-verse-button').addEventListener('click', () => {
        if (!currentVerseReference) return;
        const textToCopy = `${currentVerseReference.title}\n${currentVerseReference.content.replace(/<strong>/g, '').replace(/<\/strong>/g, '')}`;
        navigator.clipboard.writeText(textToCopy).catch(err => {
            console.error('Erreur lors de la copie: ', err);
        });
        hideVerseActionsMenu();
    });

    document.getElementById('share-verse-button').addEventListener('click', async () => {
        if (!currentVerseReference) return;
        if (navigator.share) {
            try {
                await navigator.share({
                    title: currentVerseReference.title,
                    text: currentVerseReference.content.replace(/<strong>/g, '').replace(/<\/strong>/g, ''),
                });
            } catch (error) {
                console.error('Erreur de partage: ', error);
            }
        }
        hideVerseActionsMenu();
    });
  }

  function showMenuPage() {
    const page = document.getElementById('finoana-page');
    if (!page) return;
    
    page.insertAdjacentHTML('beforeend', renderMenuPage());
    
    const nestedPage = page.querySelector('#menu-page');
    const backButton = nestedPage.querySelector('.menu-back-button');
    if (backButton) {
        backButton.onclick = () => window.history.back();
    }
    
    populateBeliefsList();

    setTimeout(() => {
        nestedPage.classList.add('active');
    }, 10);
  }

  function hideMenuPage() {
      const page = document.getElementById('finoana-page');
      if (!page) return;
      const nestedPage = page.querySelector('#menu-page');
      if (nestedPage) {
          nestedPage.classList.remove('active');
          nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
          nestedPage.style.transform = 'scale(0.98)';
          nestedPage.style.opacity = '0';
          setTimeout(() => {
              nestedPage.parentNode.removeChild(nestedPage);
          }, 400);
      }
  }
  
  async function populateBeliefsList() {
      await fetchBeliefsData();
      const list = document.getElementById('beliefs-list');
      if (!list || !beliefsData) return;
      
      let html = '';
      beliefsData.forEach((belief, index) => {
          const activeClass = belief.id === (currentBelief ? currentBelief.id : null) ? 'active' : '';
          html += `<li class="nav-list-item ${activeClass}" data-index="${index}">
                      <div class="numero">${belief.numero}</div>
                      <div class="title">${belief.title}</div>
                   </li>`;
      });
      list.innerHTML = html;
      list.querySelectorAll('.nav-list-item').forEach(item => {
          item.addEventListener('click', () => {
              currentBeliefIndex = parseInt(item.getAttribute('data-index'));
              hideMenuPage();
              fetchAndRenderBelief();
          });
      });
  }

  function init() {
    const page = document.getElementById('finoana-page');
    if (!page) return;
    
    const menuButton = page.querySelector('.menu-button');
    if (menuButton) {
      menuButton.onclick = () => {
        showMenuPage();
        window.history.pushState({ spa: pageId, view: 'menu' }, "");
      };
    }
    fetchAndRenderBelief();
  }
  
  function handlePopState(state) {
    const spaPage = document.getElementById('finoana-page');
    if (!spaPage) {
        return;
    }
    if (state && state.spa === pageId) {
      if (state.view === 'list') {
        hideMenuPage();
        hideVerseActionsMenu();
      }
    } else {
      hideSpaPage();
    }
  }

  window.drawerPages = window.drawerPages || {};
  window.drawerPages[pageId] = {
    render: function() {
      currentView = 'list';
      return renderList();
    },
    init: init,
    destroy: function() {},
    handlePopState: handlePopState
  };
})();