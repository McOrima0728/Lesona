(function(){
  const container = document.getElementById("livres");
  container.innerHTML = `<div class="list"></div>`;
  const list = container.querySelector('.list');

  const books = [
    {id: 'mifanandrina1', title: 'Hery mifanandrina I', author: 'E.G.White', summary: 'Hery mifanandrina eo amin\’i Kristy sy i Satana ary ny safidy malalaky ny olombelona.', thumb: 'assets/livres/mifanandrina.jpg', count: 42},
    {id: 'tanora', title: 'Hafatra ho an\'ny tanora', author: 'E.G.White', summary: 'Ireo torolalana tsara amin\'ny fanompoana hampianarina ny tanora.', thumb: 'assets/livres/tanora.jpg', count: 35},
    {id: 'fanompoana', title: 'Fanompoana Kristiana', author: 'E.G.White', summary: 'Ny asa misionera miandry ny kristiana nantsoin\'i Jesosy ho mpiara-miasa Aminy.', thumb: 'assets/livres/fanompoana.jpg', count: 28},
    {id: 'fanantenana', title: 'Ilay fanantenana lehibe', author: 'E.G.White', summary: 'Ny fiavian\'i Jesosy fanindroany sy ireo fanantenana miandry.', thumb: 'assets/livres/fanantenana.jpg', count: 25},
    {id: 'amparany', title: 'Any am-parany any', author: 'E.G.White', summary: 'Ny olan\'ny andro farany sy ireo loza maro hitranga.', thumb: 'assets/livres/farany.jpg', count: 20},
    {id: 'fiomanana', title: 'Fiomanana ho amin\'ny fotoan-tsararotra farany', author: 'E.G.White', summary: 'Ireo toe-javatra hiseho hiomanan\'ny vahoakan\'Andriamanitra amin\'ny fanenjehana.', thumb: 'assets/livres/fiomanana.jpg', count: 18},
    {id: 'vavolombelona', title: 'Vavolombelona mahery', author: 'E.G.White', summary: 'Ny dia misioneran\'ireo apostolin\'i Kristy.', thumb: 'assets/livres/vavolombelona.jpg', count: 32},
    {id: 'ranonorana', title: 'Fiomanana ho amin\'ny ranonorana farany', author: 'E.G.White', summary: 'Ny fandraisana ny Fanahy Masina amin\'ny andro farany.', thumb: 'assets/livres/ranonorana.jpg', count: 15},
    {id: 'kristy', title: 'Ny dia ho eo amin\'i Kristy', author: 'E.G.White', summary: 'Hanakaiky an\'i Jesosy, handray famelan-keloka, ary hivelona amin’ny finoana', thumb: 'assets/livres/diaeokristy.jpg', count: 12},
    {id: 'mifanandrina2', title: 'Hery mifanandrina II', author: 'E.G.White', summary: 'Hery mifanandrina eo amin\’i Kristy sy i Satana ary ny safidy malalaky ny olombelona.', thumb: 'assets/livres/mifanandrina.jpg', count: 42},
    {id: 'patriarka', title: 'Patriarka sy mpaminany', author: 'E.G.White', summary: 'Tantaran\'ireo olo-malazan’ny Baiboly hatramin\’i Adama ka hatramin’i Davida.', thumb: 'assets/livres/patriarka.jpg', count: 48}
  ];
  
  books.forEach((book) => {
    const row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = `
      <img class="thumb" src="${book.thumb}" alt="${book.title}" />
      <div class="meta">
        <div class="title">${book.title}</div>
        <div class="subtitle">${book.summary}</div>
      </div>
      <div class="chapters"><img src="assets/icons/folder.svg" alt="Dossier" /><span class="count">${book.count}</span></div>
    `;
    
    row.onclick = () => {
      window.goToSpaPage(book.id);
    };
    
    list.appendChild(row);
  });

  const style = document.createElement('style');
  style.textContent = `
    #livres .list{display:flex;flex-direction:column;gap:0px}
    #livres .row{display:flex;align-items:center;gap:12px;padding:15px;border-radius:10px;background:transparent;}
    #livres .row:active{background:rgba(0,0,0,0.05);}
    #livres .thumb{width:140px;height:200px;border-radius:8px;object-fit:cover;flex-shrink:0; border: 2px solid #F6F7FC;}
    #livres .meta .title{font-size:20px;font-weight:bold;color:#4E3D43}
    #livres .meta .subtitle{font-size:15px;color:#757575;margin-top:10px}
    #livres .chapters{margin-left:auto;display:flex;align-items:center;gap:6px;color:#727272}
    #livres .chapters img{width:20px;height:20px;color:#1976d2;filter: invert(0.5) sepia(1) saturate(5) hue-rotate(190deg);}
    #livres .chapters .count{font-weight:700}
  `;
  document.head.appendChild(style);
})();