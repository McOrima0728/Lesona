(function() {
  var pageId = 'tonokalo';

  var chapters = [];
  var currentView = 'list';
  var currentChapterIndex = null;
  var currentSearchQuery = '';

  // Fonction pour charger les chapitres avec XMLHttpRequest
  function loadChapters() {
    return new Promise(function(resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'data/lisitra/tonokalo.json');
      xhr.onload = function() {
        if (xhr.status === 200) {
          try {
            var data = JSON.parse(xhr.responseText);
            resolve(data.tonokalo);
          } catch (error) {
            console.error("Erreur lors de l'analyse JSON:", error);
            reject(error);
          }
        } else {
          console.error("Erreur de chargement des chapitres:", xhr.statusText);
          reject(new Error('Erreur de chargement des chapitres: ' + xhr.statusText));
        }
      };
      xhr.onerror = function() {
        console.error("Erreur réseau lors du chargement des chapitres.");
        reject(new Error("Erreur réseau."));
      };
      xhr.send();
    });
  }

  // Extrait le titre du chapitre
  function getTitle(chapter) {
    for (var key in chapter) {
      if (key.startsWith('title_')) {
        return chapter[key];
      }
    }
    return 'Titre inconnu';
  }

  // Fonction pour mettre la première lettre en majuscule et le reste en minuscule
  function formatTitleCase(str) {
    if (!str) return '';
    var formattedStr = str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();

    var specialWords = ['jesosy', 'tompo', 'andriamanitra', 'kristy'];
    for (var i = 0; i < specialWords.length; i++) {
      var word = specialWords[i];
      var regex = new RegExp('\\b' + word + '\\b', 'gi');
      formattedStr = formattedStr.replace(regex, function(match) {
        return match.charAt(0).toUpperCase() + match.slice(1).toLowerCase();
      });
    }

    return formattedStr;
  }

  // Rend la vue de la liste des chapitres
  function renderList() {
    return (
      '<div class="spa-page" id="tonokalo-page">' +
      '  <div class="spa-header">' +
      '    <img src="assets/icons/arrow_back.svg" alt="Back" class="back-button">' +
      '    <div class="title">Tonokalom-panahy</div>' +
      '    <img src="assets/icons/search.svg" alt="Search" class="search-button">' +
      '  </div>' +
      '  <div class="spa-content list-container">' +
      '    <div class="list">' +
      '      <div class="loading">' +
      '        <div class="spinner-button-container">' +
      '          <div class="spinner-button"></div>' +
      '          <div class="spinner-button delay-1"></div>' +
      '          <div class="spinner-button delay-2"></div>' +
      '        </div>' +
      '      </div>' +
      '    </div>' +
      '  </div>' +
      '  <style>' +
      '          .spa-header { display: flex; align-items: center; justify-content: space-between; padding-left: 12px; position: fixed; top: 0; width: 100%; background: #006A60; z-index: 1000; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }' +
      '          .spa-page { position: relative; height: 100%; overflow: hidden; }' +
      '          .spa-header .search-button { margin-right: 0; cursor: none; }' +
      '          .spa-header .title { flex-grow: 1; text-align: left; }' +
      '          .spa-page-nested .spa-header { display: flex; align-items: center; }' +
      '          .spa-page-nested .spa-header .title { flex: 1 1 auto; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-right: 20px; }' +
      '          .spa-header .search-button { cursor: none; }' +
      '          .list-container { padding: 0px; margin-top:50px; min-height: 300px; position: relative; }' +
      '          .list { display: flex; flex-direction: column; gap: 0px; }' +
      '          .row { display: flex; align-items: center; gap: 15px; padding: 15px; color: #424242; border-bottom: 1px solid #d9d9d9;}' +
      '          .row:active { background:rgba(0,0,0,0.05); }' +
      '          .row .icon { width: 24px; height: 24px; filter:invert(0.5); }' +
      '          .row .meta { flex-grow: 1; }' +
      '          .row .title { font-size: 18px; font-weight: bold; color: #424242}' +
      '          .row .subtitle { font-size: 14px; color: #757575; margin-top: 4px;}' +
      '          .loading { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); display: flex; justify-content: center; }' +
      '          .spinner-button-container { display: flex; gap: 10px; align-items: center; justify-content: center; }' +
      '          .spinner-button { width: 10px; height: 10px; border-radius: 50%; background-color: #006A60; animation: bounce 1s infinite; }' +
      '          .spinner-button.delay-1 { animation-delay: 0.1s; }' +
      '          .spinner-button.delay-2 { animation-delay: 0.2s; }' +
      '          @keyframes bounce { 0%, 80%, 100% { transform: scale(0); opacity: 0; } 40% { transform: scale(1); opacity: 1; } }' +
      '          .error { text-align: center; color: #fff; padding: 20px; }' +
      '  </style>' +
      '</div>'
    );
  }

  // Génère le contenu HTML de la liste des chapitres
  function renderListContent(loadedChapters) {
    return loadedChapters.map(function(chap, i) {
      return (
        '<div class="row chapter-item" data-index="' + i + '">' +
        '  <img class="icon" src="assets/icons/poem.svg" alt="Icon" />' +
        '  <div class="meta">' +
        '    <div class="title">' + formatTitleCase(getTitle(chap)) + '</div>' +
        '    <div class="subtitle">' + chap.author + '</div>' +
        '  </div>' +
        '</div>'
      );
    }).join('');
  }

  // Rend la vue d'un chapitre spécifique
  function renderChapterContent(chapter) {
    var paragraphsHtml = chapter.paragraphs.map(function(p, i) {
      var formattedText = formatTitleCase(p.text).replace(/\n/g, '<br>');
      return (
        '<p id="' + p.id + '" data-paragraph-index="' + i + '">' +
        '  <span class="paragraph-number">' + (i + 1) + '</span>' +
        '  <span class="paragraph-text">' + formattedText + '</span>' +
        '</p>'
      );
    }).join('');

    return (
      '<div class="spa-page-nested" id="tonokalo-content-page">' +
      '  <header class="spa-header transparent">' +
      '    <img src="assets/icons/arrow_back.svg" alt="Back" class="chapter-back-button">' +
      '    <div class="title hidden">' + formatTitleCase(getTitle(chapter)) + '</div>' +
      '    <div style="display: flex; gap: 30px;">' +
      '      <img src="assets/icons/copy.svg" alt="Copy" class="copy-button">' +
      '      <img src="assets/icons/share.svg" alt="Share" class="share-button">' +
      '    </div>' +
      '  </header>' +
      '  <div class="spa-content content-container">' +
      '    <div class="image-container">' +
      '      <img src="' + chapter.header_image + '" alt="Header Image" class="header-image" />' +
      '      <div class="image-title">' + formatTitleCase(getTitle(chapter)) + '</div>' +
      '    </div>' +
      '    ' + paragraphsHtml +
      '  </div>' +
      '  <div id="copy-feedback" class="copy-feedback">Chapitres copiés</div>' +
      '  <style>' +
      '          .content-container { padding: 0px; padding-bottom: 20px; color: #2C2C2C; margin-top:0px;}' +
      '          .content-container p, li { font-size: 22px; padding:5px; line-height: 1.6; margin: 0 6px 0 6px; text-align: left; text-indent: 14px; display: flex; align-items: flex-start; }' +
      '          .paragraph-number { font-size: 18px; font-weight: bold; color: #BF9B7A; margin-right: 10px; text-indent: 0; }' +
      '          .paragraph-text { flex-grow: 1; text-align: left; text-indent: 0; }' +
      '          strong {color:#BF9B7A; font-style:italic;}' +
      '          .image-container { position: relative; text-align: left; margin-bottom: 6px; overflow: hidden; }' +
      '          .header-image { width: 100%; height: 350px; border-radius: 0px; object-fit: cover; transition: height 0.2s ease; }' +
      '          .image-title { position: absolute; bottom: 20px; left: 10px; color: #fff; font-size: 20px; font-weight: bold; text-shadow: 1px 1px 4px rgba(0,0,0,0.7); transition: font-size 0.2s ease, bottom 0.2s ease; }' +
      '          .highlight { background-color: #ffff00; color: #2C2C2C; transition: background-color 0.5s ease-out; }' +
      '          .highlight-paragraph { background-color: rgba(255, 255, 0, 0.2); transition: background-color 0.5s ease; }' +
      '          #tonokalo-content-page .spa-header.transparent { background: transparent; box-shadow: none; transition: background 0.3s ease, box-shadow 0.3s ease; justify-content: space-between; }' +
      '          #tonokalo-content-page .spa-header.scrolled { background: #006A60; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }' +
      '          #tonokalo-content-page .spa-header .share-button, #tonokalo-content-page .spa-header .copy-button { margin-right: 0px; cursor: none; }' +
      '          #tonokalo-content-page .spa-header .title { opacity: 0; transition: opacity 0.3s ease; }' +
      '          #tonokalo-content-page .spa-header.scrolled .title { opacity: 1; }' +
      '          .copy-feedback { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background-color: #d9d9d9; color: #000000; padding: 10px 20px; border-radius: 50px; z-index: 2000; opacity: 0; transition: opacity 0.5s ease-in-out; font-size: 16px; }' +
      '          .copy-feedback.show { opacity: 1; }' +
      '  </style>' +
      '</div>'
    );
  }

  // Rend la vue de la page de recherche
  function renderSearchPage() {
    return (
      '<div class="spa-page-nested" id="tonokalo-search-page">' +
      '  <header class="spa-header">' +
      '    <img src="assets/icons/arrow_back.svg" alt="Back" class="search-back-button">' +
      '    <div class="search-box">' +
      '      <input type="text" id="search-input" placeholder="Rechercher un mot..." value="' + currentSearchQuery + '">' +
      '    </div>' +
      '  </header>' +
      '  <div id="search-count-container">' +
      '    <div id="search-results-count"></div>' +
      '  </div>' +
      '  <div class="spa-content search-results-container">' +
      '    <div id="search-results" class="list"></div>' +
      '  </div>' +
      '  <style>' +
      '          #tonokalo-search-page .spa-header { display: flex; align-items: center; gap: 5px; padding: 10px; }' +
      '          .search-box { flex-grow: 1; }' +
      '          #search-input { width: 90%; padding: 0px; border: none; background: none; color: #fff; font-size: 16px; box-sizing: border-box; }' +
      '          #search-input:focus { outline: none; background: none; }' +
      '          #search-input::placeholder { color: #f9f9f9; }' +
      '          #search-count-container { position: fixed; top: 50px; width: 100%; padding: 10px; background: transparent; color: #2C2C2C; text-align: left; z-index: 999; font-weight:bold; }' +
      '          .search-results-container { margin-top: 90px; padding: 0px; position: relative; height: 100%; }' +
      '          .search-results-item { padding: 15px; border-bottom: 1px solid #d9d9d9; }' +
      '          .search-results-item h4 { margin: 0; color: #fff; }' +
      '          .search-results-item p { margin: 15px 0 0; color: #f9f9f9; font-size: #757575; }' +
      '          .highlight-search { background-color: yellow; color: black; }' +
      '          .search-empty-icon { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); opacity: 0.5; width: 50px; height: 50px; filter:invert(0.5); }' +
      '  </style>' +
      '</div>'
    );
  }

  // Effectue la recherche et met à jour les résultats
  function performSearch(query) {
    var resultsContainer = document.getElementById('search-results');
    var resultsCountContainer = document.getElementById('search-results-count');
    if (!resultsContainer || !resultsCountContainer) return;

    resultsContainer.innerHTML = '';

    if (query.length < 2) {
      resultsContainer.innerHTML = '<img src="assets/icons/empty.svg" alt="Search icon" class="search-empty-icon">';
      resultsCountContainer.textContent = '';
      return;
    }

    var lowerCaseQuery = query.toLowerCase();
    var results = [];

    chapters.forEach(function(chapter, chapterIndex) {
      var title = getTitle(chapter);
      if (title.toLowerCase().indexOf(lowerCaseQuery) !== -1) {
        results.push({
          chapterIndex: chapterIndex,
          title: title,
          snippet: 'Titre : ' + title,
          isTitle: true,
          paragraphId: null
        });
      }

      chapter.paragraphs.forEach(function(paragraph) {
        if (paragraph.text.toLowerCase().indexOf(lowerCaseQuery) !== -1) {
          var words = paragraph.text.split(' ');
          var firstOccurrenceIndex = -1;
          for (var i = 0; i < words.length; i++) {
            if (words[i].toLowerCase().indexOf(lowerCaseQuery) !== -1) {
              firstOccurrenceIndex = i;
              break;
            }
          }
          if (firstOccurrenceIndex === -1) return;

          var snippetStart = Math.max(0, firstOccurrenceIndex - 5);
          var snippetEnd = Math.min(words.length, firstOccurrenceIndex + 10);
          var snippet = words.slice(snippetStart, snippetEnd).join(' ') + '...';

          results.push({
            chapterIndex: chapterIndex,
            title: title,
            snippet: snippet.replace(new RegExp(query, 'gi'), '<span class="highlight-search">' + query + '</span>'),
            paragraphId: paragraph.id
          });
        }
      });
    });

    resultsCountContainer.textContent = results.length + ' résultat' + (results.length > 1 ? 's' : '') + ' trouvé' + (results.length > 1 ? 's' : '');

    if (results.length > 0) {
      resultsContainer.innerHTML = results.map(function(result) {
        return (
          '<div class="row search-results-item chapter-item" data-index="' + result.chapterIndex + '" data-paragraph-id="' + result.paragraphId + '">' +
          '  <div class="meta">' +
          '    <div class="title">' + result.title + '</div>' +
          '    <div class="subtitle">' + result.snippet + '</div>' +
          '  </div>' +
          '</div>'
        );
      }).join('');
    } else {
      resultsContainer.innerHTML = '';
    }
  }

  // Affiche un chapitre et surligne un mot-clé si nécessaire
  function showChapter(index, query, paragraphId) {
    var page = document.getElementById('tonokalo-page');
    if (!page) return;

    var chapter = chapters[index];
    if (!chapter) return;

    page.insertAdjacentHTML('beforeend', renderChapterContent(chapter));

    var nestedPage = page.querySelector('#tonokalo-content-page');
    var backButton = nestedPage.querySelector('.chapter-back-button');
    var shareButton = nestedPage.querySelector('.share-button');
    var copyButton = nestedPage.querySelector('.copy-button');
    var headerImage = nestedPage.querySelector('.header-image');
    var imageTitle = nestedPage.querySelector('.image-title');
    var contentContainer = nestedPage.querySelector('.spa-content');
    var chapterHeader = nestedPage.querySelector('.spa-header');
    var copyFeedback = nestedPage.querySelector('#copy-feedback');

    if (backButton) {
      backButton.onclick = function() {
        window.history.back();
      };
    }

    if (shareButton) {
      shareButton.onclick = function() {
        var titleToShare = getTitle(chapter);
        var textToShare = 'Découvrez ce chapitre de \'Hery tonokalo\': ' + titleToShare;
        var urlToShare = window.location.href;

        if (window.plugins && window.plugins.socialsharing) {
          window.plugins.socialsharing.share(textToShare, titleToShare, null, urlToShare);
        }
      };
    }

    // Ajout d'un écouteur de clic pour le bouton de copie
    if (copyButton) {
      copyButton.onclick = function() {
        var textToCopy = getTitle(chapter) + '\n\n' + chapter.paragraphs.map(function(p) { return p.text; }).join('\n\n');
        
        // Méthode de copie pour les anciens navigateurs
        var tempTextArea = document.createElement('textarea');
        tempTextArea.style.position = 'fixed';
        tempTextArea.style.left = '-9999px';
        tempTextArea.style.top = '0';
        tempTextArea.value = textToCopy;
        document.body.appendChild(tempTextArea);
        tempTextArea.focus();
        tempTextArea.select();
        try {
          var successful = document.execCommand('copy');
          if (successful) {
            copyFeedback.classList.add('show');
            setTimeout(function() {
              copyFeedback.classList.remove('show');
            }, 2000);
          } else {
            console.error('Erreur lors de la copie: execCommand échoué.');
          }
        } catch (err) {
          console.error('Erreur lors de la copie:', err);
        }
        document.body.removeChild(tempTextArea);
      };
    }

    if (contentContainer) {
      contentContainer.addEventListener('scroll', function(e) {
        var scrollTop = e.target.scrollTop;
        var minHeight = 50;
        var newHeight = Math.max(350 - scrollTop, minHeight);
        headerImage.style.height = newHeight + 'px';

        var scaleTitle = Math.max(1, newHeight / 350);
        imageTitle.style.fontSize = 20 * scaleTitle + 'px';
        imageTitle.style.bottom = 20 * scaleTitle + 'px';

        if (scrollTop > 150) {
          chapterHeader.classList.add('scrolled');
        } else {
          chapterHeader.classList.remove('scrolled');
        }
      });
    }

    if (query && paragraphId) {
      var targetParagraph = document.getElementById(paragraphId);
      if (targetParagraph) {
        targetParagraph.classList.add('highlight-paragraph');

        setTimeout(function() {
          targetParagraph.classList.remove('highlight-paragraph');
        }, 5000);

        var highlightedText = targetParagraph.innerHTML.replace(new RegExp(query, 'gi'), function(match) {
          return '<span class="highlight">' + match + '</span>';
        });
        targetParagraph.innerHTML = highlightedText;
        targetParagraph.scrollIntoView({ behavior: 'smooth', block: 'center' });

        setTimeout(function() {
          var highlightedSpans = targetParagraph.querySelectorAll('.highlight');
          for (var i = 0; i < highlightedSpans.length; i++) {
            var span = highlightedSpans[i];
            span.outerHTML = span.innerHTML;
          }
        }, 5000);
      }
    }

    setTimeout(function() {
      nestedPage.classList.add('active');
    }, 10);
  }

  // Affiche la page de recherche
  function showSearchPage() {
    var page = document.getElementById('tonokalo-page');
    if (!page) return;

    page.insertAdjacentHTML('beforeend', renderSearchPage());

    var nestedPage = page.querySelector('#tonokalo-search-page');
    var backButton = nestedPage.querySelector('.search-back-button');
    var searchInput = nestedPage.querySelector('#search-input');
    var resultsContainer = nestedPage.querySelector('#search-results');

    if (backButton) {
      backButton.onclick = function() {
        window.history.back();
      };
    }

    if (searchInput) {
      searchInput.focus();
      searchInput.addEventListener('input', function(e) {
        currentSearchQuery = e.target.value;
        performSearch(currentSearchQuery);
      });
    }

    if (resultsContainer) {
      resultsContainer.onclick = function(e) {
        var row = e.target.closest('.chapter-item');
        if (row) {
          var index = parseInt(row.dataset.index);
          var paragraphId = row.dataset.paragraphId;
          hideSearchPage();
          showChapter(index, currentSearchQuery, paragraphId);
          window.history.pushState({ spa: pageId, view: 'content', chapter: index, paragraphId: paragraphId }, "");
        }
      };
    }

    performSearch(currentSearchQuery);

    setTimeout(function() {
      nestedPage.classList.add('active');
    }, 10);
  }

  // Masque la vue du chapitre
  function hideChapter() {
    var page = document.getElementById('tonokalo-page');
    if (!page) return;

    var nestedPage = page.querySelector('#tonokalo-content-page');
    if (nestedPage) {
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(function() {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  // Masque la page de recherche
  function hideSearchPage() {
    var page = document.getElementById('tonokalo-page');
    if (!page) return;

    var nestedPage = page.querySelector('#tonokalo-search-page');
    if (nestedPage) {
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(function() {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  // Initialise les événements de la page
  function init() {
    var page = document.getElementById('tonokalo-page');
    if (!page) return;

    var backButton = page.querySelector('.back-button');
    if (backButton) {
      backButton.onclick = function() {
        window.history.back();
      };
    }

    var searchButton = page.querySelector('.search-button');
    if (searchButton) {
      searchButton.onclick = function() {
        currentSearchQuery = '';
        showSearchPage();
        window.history.pushState({ spa: pageId, view: 'search' }, "");
      };
    }

    var listContainer = page.querySelector('.list-container .list');

    loadChapters()
      .then(function(loadedChapters) {
        chapters = loadedChapters;
        if (chapters.length > 0) {
          listContainer.innerHTML = renderListContent(chapters);
        } else {
          listContainer.innerHTML = '<div class="error">Impossible de charger le contenu.</div>';
        }

        listContainer.onclick = function(e) {
          var row = e.target.closest('.chapter-item');
          if (row) {
            currentChapterIndex = parseInt(row.dataset.index);
            showChapter(currentChapterIndex);
            window.history.pushState({ spa: pageId, view: 'content', chapter: currentChapterIndex }, "");
          }
        };
      })
      .catch(function(error) {
        listContainer.innerHTML = '<div class="error">Erreur de chargement: ' + error.message + '</div>';
      });
  }

  // Gère la navigation de l'historique du navigateur
  function handlePopState(state) {
    var spaPage = document.getElementById('tonokalo-page');
    if (!spaPage) return;

    if (state && state.spa === pageId) {
      if (state.view === 'content' && state.chapter !== undefined) {
        if (parseInt(state.chapter) !== currentChapterIndex) {
          hideSearchPage();
          showChapter(parseInt(state.chapter));
        }
        currentView = 'content';
        currentChapterIndex = parseInt(state.chapter);
      } else if (state.view === 'search') {
        hideChapter();
        showSearchPage();
        currentView = 'search';
        currentChapterIndex = null;
      } else if (state.view === 'list') {
        hideChapter();
        hideSearchPage();
        currentView = 'list';
        currentChapterIndex = null;
      } else {
        window.history.back();
      }
    } else {
      hideSpaPage();
    }
  }

  window.drawerPages = window.drawerPages || {};
  window.drawerPages[pageId] = {
    render: function() {
      currentView = 'list';
      currentChapterIndex = null;
      return renderList();
    },
    init: init,
    destroy: function() {},
    handlePopState: handlePopState
  };

})();