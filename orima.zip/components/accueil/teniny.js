window.drawerPages = window.drawerPages || {};

window.drawerPages["teniny"] = {
    render: function() {
        return ''
            + '<style>'
            + '.spa-page { position: relative; height: 100%; overflow: hidden; }'
            + '.spa-headers { position: fixed; top: 0; left: 0; width: 100%; height: 50px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; z-index: 100; background-color: transparent; transition: background-color 0.3s, box-shadow 0.3s; }'
            + '.spa-headers.scrolled { background-color: #006A60; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }'
            + '.spa-headers img { width: 24px; height: 24px; }'
            + '.header-left, .header-right { display: flex; align-items: center; }'
            + '.header-left { overflow: hidden; }'
            + '.header-left img, .header-right img { display: flex; align-items: center; justify-content: center; width: 48px; height: 48px; transition: background-color 0.2s; padding: 12px; margin: -12px; }'
            + '.spa-headers .titles { font-size: 18px; font-weight: bold; color: transparent; transition: color 0.3s; margin-left: 8px; max-width: 90%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }'
            + '.spa-headers.scrolled .titles { color: #ffffff; }'
            + '.spa-content { position: absolute; top: 0; left: 0; right: 0; bottom: 0; overflow-y: scroll; padding-top: 0px; }'
            + '.teniny-image-container { width: 100%; height: 350px; overflow: hidden; position: relative; }'
            + '.teniny-image-container img { width: 100%; height: 100%; object-fit: cover; display: block; }'
            + '.teniny-image-container .teniny-actions { position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); display: flex; gap: 40px; padding-bottom: 20px; }'
            + '.teniny-content-container { background: #ffffff; border-top-left-radius: 10px; border-top-right-radius: 10px; margin-top: -20px; padding: 14px; position: relative; }'
            + '.teniny-content-container .teniny-date { color: #888; font-size: 16px; text-align: center; margin-bottom: 8px; }'
            + '.teniny-content-container .h2-wrapper { display: flex; align-items: center; justify-content: center; margin-bottom: 16px; }'
            + '.teniny-content-container .h2-wrapper::before, .teniny-content-container .h2-wrapper::after { content: ""; flex-grow: 1; height: 2px; background-color: #006A60; }'
            + '.teniny-content-container h2 { color: #006A60; font-size: 22px; margin: 0 16px; white-space: nowrap; }'
            + '.teniny-content-container p { color: #424242; line-height: 1.7; margin-bottom: 16px; text-align: left; font-size: 22px; }'
            + '.teniny-content-container p span.verse-number { font-weight: bold; margin-right: 6px; color: #006A60; }'
            + '.teniny-content-container p.first-verse::first-letter { font-size: 36px; font-weight: bold; float: left; line-height: 1; margin-right: 6px; color: #006A60; }'
            + '.teniny-actions .action-button { background-color: rgba(255, 255, 255, 0.2); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; transition: background-color 0.2s; }'
            + '.teniny-actions .action-button:active { background-color: rgba(28, 98, 126, 0.1); }'
            + '.teniny-actions .action-button img { width: 22px; height: 22px; }'
            + '.toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 2px; padding: 16px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); opacity: 0; transition: visibility 0s, opacity 0.5s linear; }'
            + '.toast.show { visibility: visible; opacity: 1; }'
            + '.date-picker-input { position: absolute; top: 0; left: 0; width: 1px; height: 1px; opacity: 0; overflow: hidden; }'
            + '</style>'
            + '<div class="spa-page">'
            + '<header class="spa-headers">'
            + '<div class="header-left">'
            + '<img src="assets/icons/arrow_back.svg" alt="Retour" onclick="history.back()">'
            + '<div class="titles" id="header-title"></div>'
            + '</div>'
            + '<div class="header-right">'
            + '<img src="assets/icons/calendar.svg" alt="Calendrier" id="calendar-icon">'
            + '</div>'
            + '</header>'
            + '<input type="date" id="date-input" class="date-picker-input">'
            + '<div class="spa-content">'
            + '<div class="teniny-image-container">'
            + '<img src="assets/acceuil/bible.jpg" alt="Velomin\'ny Teniny">'
            + '<div class="teniny-actions">'
            + '<div class="action-button" onclick="window.drawerPages.teniny.shareVerse()">'
            + '<img src="assets/icons/share.svg" alt="Partager">'
            + '</div>'
            + '<div class="action-button" onclick="window.drawerPages.teniny.copyVerse()">'
            + '<img src="assets/icons/copy.svg" alt="Copier">'
            + '</div>'
            + '</div>'
            + '</div>'
            + '<div class="teniny-content-container" id="teniny-content">'
            + '<p id="teniny-date" class="teniny-date"></p>'
            + '<div class="h2-wrapper"><h2 id="teniny-title"></h2></div>'
            + '<div id="teniny-verses"></div>'
            + '</div>'
            + '</div>'
            + '<div id="toast" class="toast"></div>'
            + '</div>';
    },

    showToast: function(message) {
        var toast = document.getElementById("toast");
        toast.innerHTML = message;
        toast.className = "toast show";
        setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
    },
    
    loadVerse: function(date) {
        var teninyDate = document.getElementById("teniny-date");
        var teninyTitle = document.getElementById("teniny-title");
        var headerTitle = document.getElementById("header-title");
        var teninyVerses = document.getElementById("teniny-verses");

        var monthNames = ["Janoary", "Febroary", "Martsa", "Aprily", "Mey", "Jona", "Jolay", "Aogositra", "Septambra", "Oktobra", "Novambra", "Desambra"];
        var day = date.getDate();
        var monthIndex = date.getMonth();
        var year = date.getFullYear();

        teninyDate.innerHTML = day + ' ' + monthNames[monthIndex] + ' ' + year;

        var teninyBibleBooks = [
            { name: "Genesisy", file: "genesisy.json", chapters: 50 },
            { name: "Eksodosy", file: "eksodosy.json", chapters: 40 },
            { name: "Levitikosy", file: "levitikosy.json", chapters: 27 },
            { name: "Nomery", file: "nomery.json", chapters: 36 },
            { name: "Deoteronomia", file: "deoteronomia.json", chapters: 34 },
            { name: "Josoa", file: "josoa.json", chapters: 24 },
            { name: "Mpitsara", file: "mpitsara.json", chapters: 21 },
            { name: "Rota", file: "rota.json", chapters: 4 },
            { name: "1 Samoela", file: "1-samoela.json", chapters: 31 },
            { name: "2 Samoela", file: "2-samoela.json", chapters: 24 },
            { name: "1 Mpanjaka", file: "1-mpanjaka.json", chapters: 22 },
            { name: "2 Mpanjaka", file: "2-mpanjaka.json", chapters: 25 },
            { name: "1 Tantara", file: "1-tantara.json", chapters: 29 },
            { name: "2 Tantara", file: "2-tantara.json", chapters: 36 },
            { name: "Ezra", file: "ezra.json", chapters: 10 },
            { name: "Nehemia", file: "nehemia.json", chapters: 13 },
            { name: "Estera", file: "estera.json", chapters: 10 },
            { name: "Joba", file: "joba.json", chapters: 42 },
            { name: "Salamo", file: "salamo.json", chapters: 150 },
            { name: "Ohabolana", file: "ohabolana.json", chapters: 31 },
            { name: "Mpitoriteny", file: "mpitoriteny.json", chapters: 12 },
            { name: "Tononkiran'i Solomona", file: "tononkirani-solomona.json", chapters: 8 },
            { name: "Isaia", file: "isaia.json", chapters: 66 },
            { name: "Jeremia", file: "jeremia.json", chapters: 52 },
            { name: "Fitomaniana", file: "fitomaniana.json", chapters: 5 },
            { name: "Ezekiela", file: "ezekiela.json", chapters: 48 },
            { name: "Daniela", file: "daniela.json", chapters: 12 },
            { name: "Hosea", file: "hosea.json", chapters: 14 },
            { name: "Joela", file: "joela.json", chapters: 3 },
            { name: "Amosy", file: "amosy.json", chapters: 9 },
            { name: "Obadia", file: "obadia.json", chapters: 1 },
            { name: "Jona", file: "jona.json", chapters: 4 },
            { name: "Mika", file: "mika.json", chapters: 7 },
            { name: "Nahoma", file: "nahoma.json", chapters: 3 },
            { name: "Habakoka", file: "habakoka.json", chapters: 3 },
            { name: "Zefania", file: "zefania.json", chapters: 3 },
            { name: "Hagay", file: "hagay.json", chapters: 2 },
            { name: "Zakaria", file: "zakaria.json", chapters: 14 },
            { name: "Malakia", file: "malakia.json", chapters: 4 },
            { name: "Matio", file: "matio.json", chapters: 28 },
            { name: "Marka", file: "marka.json", chapters: 16 },
            { name: "Lioka", file: "lioka.json", chapters: 24 },
            { name: "Jaona", file: "jaona.json", chapters: 21 },
            { name: "Asan'ny Apostoly", file: "asa.json", chapters: 28 },
            { name: "Romana", file: "romana.json", chapters: 16 },
            { name: "1 Korintiana", file: "1-korintiana.json", chapters: 16 },
            { name: "2 Korintiana", file: "2-korintiana.json", chapters: 13 },
            { name: "Galatiana", file: "galatiana.json", chapters: 6 },
            { name: "Efesiana", file: "efesiana.json", chapters: 6 },
            { name: "Filipiana", file: "filipiana.json", chapters: 4 },
            { name: "Kolosiana", file: "kolosiana.json", chapters: 4 },
            { name: "1 Tesalonianina", file: "1-tesalonianina.json", chapters: 5 },
            { name: "2 Tesalonianina", file:"2-tesalonianina.json", chapters: 3 },
            { name: "1 Timoty", file: "1-timoty.json", chapters: 6 },
            { name: "2 Timoty", file: "2-timoty.json", chapters: 4 },
            { name: "Titosy", file: "titosy.json", chapters: 3 },
            { name: "Filemona", file: "filemona.json", chapters: 1 },
            { name: "Hebreo", file: "hebreo.json", chapters: 13 },
            { name: "Jakoba", file: "jakoba.json", chapters: 5 },
            { name: "1 Petera", file: "1-petera.json", chapters: 5 },
            { name: "2 Petera", file: "2-petera.json", chapters: 3 },
            { name: "1 Jaona", file: "1-jaona.json", chapters: 5 },
            { name: "2 Jaona", file: "2-jaona.json", chapters: 1 },
            { name: "3 Jaona", file: "3-jaona.json", chapters: 1 },
            { name: "Joda", file: "joda.json", chapters: 1 },
            { name: "Apokalypsy", file: "apokalypsy.json", chapters: 22 }
        ];

        var startDate = new Date("2022-01-14");
        // Ajustement pour ne tenir compte que de la date, pas de l'heure
        startDate.setHours(0, 0, 0, 0);
        date.setHours(0, 0, 0, 0);
        
        var diffDays = Math.floor((date - startDate) / (1000 * 60 * 60 * 24));
        
        var totalChaptersPassed = diffDays;
        var bookIndex = 0;
        var chapterNumber = 1;
        var totalBooks = teninyBibleBooks.length;
        var totalChaptersInBible = teninyBibleBooks.reduce((sum, book) => sum + book.chapters, 0);

        // Boucle pour trouver le bon chapitre en se basant sur la date de début
        totalChaptersPassed = (totalChaptersPassed % totalChaptersInBible + totalChaptersInBible) % totalChaptersInBible;

        for(var i=0; i<totalBooks; i++){
            if(totalChaptersPassed < teninyBibleBooks[i].chapters){
                bookIndex = i;
                chapterNumber = totalChaptersPassed + 1;
                break;
            } else {
                totalChaptersPassed -= teninyBibleBooks[i].chapters;
            }
        }
        
        var book = teninyBibleBooks[bookIndex];
        var bookFilePath = "data/baiboly/protestanta/" + book.file;
        var localStorageKey = "baiboly_" + book.file;

        teninyTitle.innerHTML = book.name + " " + chapterNumber;
        headerTitle.innerHTML = book.name + " " + chapterNumber;
        
        // Fonction pour afficher le contenu
        var displayContent = function(data) {
            var chapter = data[chapterNumber];
            teninyVerses.innerHTML = "";
            var firstVerse = true;
            for(var verseNum in chapter){
                var p = document.createElement("p");
                p.innerHTML = '<span class="verse-number">' + verseNum + '</span> ' + chapter[verseNum];
                if(firstVerse){ p.className = "first-verse"; firstVerse=false; }
                teninyVerses.appendChild(p);
            }
        };

        // 1. Tenter de récupérer depuis le localStorage
        try {
            var cachedData = localStorage.getItem(localStorageKey);
            if (cachedData) {
                var data = JSON.parse(cachedData);
                displayContent(data);
                return; // Arrêter la fonction si les données sont en cache
            }
        } catch (e) {
            console.error("Erreur d'accès au localStorage:", e);
        }

        // 2. Sinon, charger via XHR et mettre en cache
        var xhr = new XMLHttpRequest();
        xhr.open("GET", bookFilePath, true);
        xhr.onreadystatechange = function(){
            if(xhr.readyState === 4 && xhr.status === 200){
                var data = JSON.parse(xhr.responseText);
                try {
                    localStorage.setItem(localStorageKey, xhr.responseText);
                } catch (e) {
                    console.error("Erreur d'écriture dans le localStorage:", e);
                }
                displayContent(data);
            }
        };
        xhr.send();
    },

    loadDailyVerse: function() {
        this.loadVerse(new Date());
    },

    setupMidnightUpdate: function() {
        var now = new Date();
        var tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
        var timeToMidnight = tomorrow.getTime() - now.getTime();

        setTimeout(function() {
            window.drawerPages.teniny.loadDailyVerse();
            window.drawerPages.teniny.scheduleDailyNotification();
            setInterval(function() {
                window.drawerPages.teniny.loadDailyVerse();
                window.drawerPages.teniny.scheduleDailyNotification();
            }, 24 * 60 * 60 * 1000);
        }, timeToMidnight);
    },

    scheduleDailyNotification: function() {
        if (window.cordova && window.cordova.plugins && window.cordova.plugins.notification.local) {
            cordova.plugins.notification.local.cancel(1, function() {
                var now = new Date();
                var notificationTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 4, 0, 0); 
                
                if (now.getHours() >= 4) {
                    notificationTime.setDate(now.getDate() + 1);
                }
                
                var monthNames = ["Janoary", "Febroary", "Martsa", "Aprily", "Mey", "Jona", "Jolay", "Aogositra", "Septambra", "Oktobra", "Novambra", "Desambra"];
                var today = new Date();
                var formattedDate = today.getDate() + ' ' + monthNames[today.getMonth()] + ' ' + today.getFullYear();
                
                var teninyTitle = document.getElementById("teniny-title").innerText;
                var notificationTitle = "Velomin'ny Teniny";
                var notificationText = "Ny Velomin'ny teniny androany " + formattedDate + " dia ao amin'ny " + teninyTitle + ". Manasa anao hamaky izany.\n\nNy hafatro";

                cordova.plugins.notification.local.schedule({
                    id: 1,
                    title: notificationTitle,
                    text: notificationText,
                    smallIcon: 'res://icon',
                    at: notificationTime,
                    every: 'day',
                    data: { page: 'teniny.js' }
                });
            });
        }
    },

    copyVerse: function() {
        var versesElement = document.getElementById("teniny-verses");
        var versesText = versesElement.innerText;
        var titleText = document.getElementById("teniny-title").innerText;
        var textToCopy = titleText + '\n\n' + versesText;

        navigator.clipboard.writeText(textToCopy).then(() => {
            this.showToast('Verset copié !');
        }).catch(() => {
            this.showToast('Impossible de copier le verset.');
        });
    },

    shareVerse: function() {
        var titleText = document.getElementById("teniny-title").innerText;
        var versesElement = document.getElementById("teniny-verses");
        var versesText = versesElement.innerText;
        var textToShare = titleText + '\n\n' + versesText;
        
        if (window.plugins && window.plugins.socialsharing) {
            window.plugins.socialsharing.share(textToShare, null, null, null, () => {
                this.showToast('Verset partagé avec succès.');
            }, () => {
                this.showToast('Erreur de partage.');
            });
        } else if (navigator.share) {
            var shareData = {
                title: titleText,
                text: textToShare,
            };
            navigator.share(shareData).then(() => {
                this.showToast('Verset partagé avec succès.');
            }).catch(() => {
                this.showToast('Erreur de partage.');
            });
        } else {
            this.showToast('La fonction de partage n\'est pas supportée.');
        }
    },

    init: function() {
        console.log("Page Teniny initialisée.");
        
        this.loadDailyVerse();
        this.setupMidnightUpdate();
        this.scheduleDailyNotification();

        if (window.cordova && window.cordova.plugins && window.cordova.plugins.notification.local) {
            cordova.plugins.notification.local.on("click", function (notification) {
                if (notification.data && notification.data.page === 'teniny.js') {
                    window.location.hash = '#teniny'; 
                }
            });
        }

        var header = document.querySelector(".spa-headers");
        var content = document.querySelector(".spa-content");
        var imageContainer = document.querySelector(".teniny-image-container");
        var image = imageContainer.getElementsByTagName("img")[0];
        var imageHeight = imageContainer.offsetHeight;

        content.onscroll = function() {
            var scrollY = content.scrollTop;
            if(scrollY >= imageHeight - 50) header.className = "spa-headers scrolled";
            else header.className = "spa-headers";
            imageContainer.style.height = Math.max(350, imageHeight - scrollY) + "px";
            image.style.transform = "scale(" + (1 + scrollY/1000) + ")";
        };

        var calendarIcon = document.getElementById("calendar-icon");
        var dateInput = document.getElementById("date-input");

        calendarIcon.addEventListener("click", function() {
            dateInput.showPicker();
        });

        dateInput.addEventListener("change", function(event) {
            var selectedDate = new Date(event.target.value);
            window.drawerPages.teniny.loadVerse(selectedDate);
        });
    },
    destroy: function() {
        console.log("Page Teniny détruite.");
    }
};