window.drawerPages = window.drawerPages || {};

window.drawerPages["lehibe"] = {
    render: function() {
        return ''
            + '<style>'
            + '.spa-page { position: relative; height: 100%; overflow: hidden; }'
            + '.spa-headers { position: fixed; top: 0; left: 0; width: 100%; height: 50px; display: flex; align-items: center; justify-content: space-between; padding: 0 12px; z-index: 100; background-color: transparent; transition: background-color 0.3s, box-shadow 0.3s; }'
            + '.spa-headers.scrolled { background-color: #006A60; box-shadow: 0 2px 8px rgba(0,0,0,0.2); }'
            + '.spa-headers img { width: 24px; height: 24px; }'
            + '.header-left, .header-right { display: flex; align-items: center; }'
            + '.header-left img, .header-right img { display: flex; align-items: center; justify-content: center; width: 48px; height: 48px; transition: background-color 0.2s; padding: 12px; margin: -12px; }'
            + '.spa-headers .titles { font-size: 18px; font-weight: bold; color: transparent; transition: color 0.3s; margin-left: 8px; max-width: 90%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }'
            + '.spa-headers.scrolled .titles { color: #ffffff; }'
            + '.spa-content { position: absolute; top: 0; left: 0; right: 0; bottom: 0; overflow-y: scroll; padding-top: 0px; }'
            + '.lehibe-image-container { width: 100%; height: 350px; overflow: hidden; position: relative; }'
            + '.lehibe-image-container img { width: 100%; height: 100%; object-fit: cover; display: block; }'
            + '.lehibe-image-container .lehibe-actions { position: absolute; bottom: 10px; left: 50%; transform: translateX(-50%); display: flex; gap: 40px; padding-bottom: 20px; }'
            + '.lehibe-content-container { background: #ffffff; border-top-left-radius: 10px; border-top-right-radius: 10px; margin-top: -20px; padding: 14px; position: relative; display: none; }'
            + '.lehibe-content-container .lehibe-date { color: #888; font-size: 16px; text-align: center; margin-bottom: 8px; }'
            + '.lehibe-content-container .h2-wrapper { display: flex; align-items: center; justify-content: center; margin-bottom: 16px; }'
            + '.lehibe-content-container .h2-wrapper::before, .lehibe-content-container .h2-wrapper::after { content: ""; flex-grow: 1; height: 2px; background-color: #006A60; }'
            + '.lehibe-content-container h2 { color: #006A60; font-size: 22px; margin: 0 16px; white-space: nowrap; }'
            + '.lehibe-content-container p { color: #424242; line-height: 1.7; margin-bottom: 16px; text-align: left; font-size: 18px; }'
            + '.lehibe-content-container p span.verse-number { font-weight: bold; margin-right: 6px; color: #006A60; }'
            + '.lehibe-content-container p.first-verse::first-letter { font-size: 36px; font-weight: bold; float: left; line-height: 1; margin-right: 6px; color: #006A60; }'
            + '.lehibe-actions .action-button { background-color: rgba(255, 255, 255, 0.2); display: flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 50%; transition: background-color 0.2s; }'
            + '.lehibe-actions .action-button:active { background-color: rgba(28, 98, 126, 0.1); }'
            + '.lehibe-actions .action-button img { width: 22px; height: 22px; }'
            + '.toast { visibility: hidden; min-width: 250px; background-color: #333; color: #fff; text-align: center; border-radius: 2px; padding: 16px; position: fixed; z-index: 1000; left: 50%; bottom: 30px; transform: translateX(-50%); opacity: 0; transition: visibility 0s, opacity 0.5s linear; }'
            + '.toast.show { visibility: visible; opacity: 1; }'
            + '@keyframes shimmer { 0% { background-position: -468px 0; } 100% { background-position: 468px 0; } }'
            + '.lehibe-skeleton { background: #fff; border-top-left-radius: 10px; border-top-right-radius: 10px; margin-top: -20px; padding: 14px; box-shadow: 0 -2px 10px rgba(0,0,0,0.1); }'
            + '.skeleton-box { height: 20px; background: #f6f7f8; background-image: linear-gradient(to right, #f6f7f8 0%, #edeef1 20%, #f6f7f8 40%, #f6f7f8 100%); background-repeat: no-repeat; background-size: 800px 100%; animation: shimmer 1.5s infinite linear; border-radius: 4px; }'
            + '.skeleton-title { width: 60%; height: 28px; margin: 0 auto 16px; }'
            + '.skeleton-line { width: 100%; height: 18px; margin-bottom: 12px; }'
            + '.skeleton-line:last-child { width: 80%; }'
            + '</style>'
            + '<div class="spa-page">'
            + '<header class="spa-headers">'
            + '<div class="header-left">'
            + '<img src="assets/icons/arrow_back.svg" alt="Retour" onclick="history.back()">'
            + '<div class="titles" id="header-title">Fiambenana Maraina</div>'
            + '</div>'
            + '<div class="header-right">'
            + '<img src="assets/icons/share.svg" alt="Partager" onclick="window.drawerPages.lehibe.shareVerse()">'
            + '</div>'
            + '</header>'
            + '<div class="spa-content">'
            + '<div class="lehibe-image-container">'
            + '<img src="assets/acceuil/breads.jpg" alt="Velomin\'ny Teniny">'
            + '</div>'
            + '<div class="lehibe-content-container" id="lehibe-content">'
            + '<p id="lehibe-date" class="lehibe-date"></p>'
            + '<div class="h2-wrapper"><h2 id="lehibe-title"></h2></div>'
            + '<div id="lehibe-verses"></div>'
            + '</div>'
            + '<div id="lehibe-skeleton" class="lehibe-skeleton">'
            + '<p id="skeleton-date" class="lehibe-date"></p>'
            + '<div class="h2-wrapper"><div class="skeleton-box skeleton-title"></div></div>'
            + '<div id="skeleton-lines">'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '<div class="skeleton-box skeleton-line"></div>'
            + '</div>'
            + '</div>'
            + '</div>'
            + '<div id="toast" class="toast"></div>'
            + '</div>';
    },

    showToast: function(message) {
        var toast = document.getElementById("toast");
        toast.innerHTML = message;
        toast.className = "toast show";
        setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
    },

    loadVerse: function() {
        var lehibeDate = document.getElementById("lehibe-date");
        var skeletonDate = document.getElementById("skeleton-date");
        var lehibeTitle = document.getElementById("lehibe-title");
        var headerTitle = document.getElementById("header-title");
        var lehibeVerses = document.getElementById("lehibe-verses");
        var lehibeContent = document.getElementById("lehibe-content");
        var lehibeSkeleton = document.getElementById("lehibe-skeleton");

        lehibeContent.style.display = 'none';
        lehibeSkeleton.style.display = 'block';

        var today = new Date();
        var monthNames = ["Janoary","Febroary","Martsa","Aprily","Mey","Jona","Jolay","Aogositra","Septambra","Oktobra","Novambra","Desambra"];
        var dateText = today.getDate() + ' ' + monthNames[today.getMonth()] + ' ' + today.getFullYear();
        lehibeDate.textContent = dateText;
        skeletonDate.textContent = dateText;

        var targetUrl = encodeURIComponent('https://www.advantistalyon.com/mg/fiambenana-maraina-androany');
        var proxyUrl = `https://api.allorigins.win/get?url=${targetUrl}`;

        fetch(proxyUrl)
            .then(response => { 
                if(response.ok) return response.json(); 
                throw new Error('Erreur serveur proxy'); 
            })
            .then(data => {
                var parser = new DOMParser();
                var doc = parser.parseFromString(data.contents, 'text/html');
                var mainContent = doc.querySelector('.entry-content, .post-content, .et_pb_post_content, article');

                if(mainContent) {
                    var realTitle = mainContent.querySelector('h2, h3')?.innerText || "lehiben’aina";
                    var paragraphs = Array.from(mainContent.querySelectorAll('p'))
                        .map(p => `<p>${p.innerText}</p>`).join("");

                    lehibeTitle.textContent = realTitle;
                    headerTitle.textContent = realTitle;
                    lehibeVerses.innerHTML = paragraphs;
                    
                    lehibeSkeleton.style.display = 'none';
                    lehibeContent.style.display = 'block';

                } else {
                    lehibeTitle.textContent = "lehiben’aina";
                    headerTitle.textContent = "lehiben’aina";
                    lehibeVerses.innerHTML = "<p>Impossible de trouver le contenu du jour.</p>";
                    lehibeSkeleton.style.display = 'none';
                    lehibeContent.style.display = 'block';
                }
            })
            .catch(err => {
                lehibeTitle.textContent = "lehiben’aina";
                headerTitle.textContent = "lehiben’aina";
                lehibeVerses.innerHTML = `<p>ressayer plus tard...</p>`;
                lehibeSkeleton.style.display = 'none';
                lehibeContent.style.display = 'block';
            });
    },

    shareVerse: function() {
        var titleText = document.getElementById("lehibe-title").innerText;
        var versesText = document.getElementById("lehibe-verses").innerText;
        var textToShare = titleText + '\n\n' + versesText;

        if (window.plugins && window.plugins.socialsharing) {
            window.plugins.socialsharing.share(textToShare, titleText, null, null,
                () => { this.showToast('Verset partagé avec succès.'); },
                () => { this.showToast('Erreur de partage.'); }
            );
        } else {
            this.showToast('Partage non disponible.');
        }
    },

    init: function() {
        console.log("Page lehibe initialisée.");
        this.loadVerse();

        var header = document.querySelector(".spa-headers");
        var content = document.querySelector(".spa-content");
        var imageContainer = document.querySelector(".lehibe-image-container");
        var image = imageContainer.getElementsByTagName("img")[0];
        var imageHeight = imageContainer.offsetHeight;

        content.onscroll = function() {
            var scrollY = content.scrollTop;
            if(scrollY >= imageHeight - 50) header.className = "spa-headers scrolled";
            else header.className = "spa-headers";
            imageContainer.style.height = Math.max(350, imageHeight - scrollY) + "px";
            image.style.transform = "scale(" + (1 + scrollY/1000) + ")";
        };

        // Add event listeners for network status
        window.addEventListener('online', () => {
            console.log("Network connection re-established. Reloading content...");
            this.loadVerse();
        });

        window.addEventListener('offline', () => {
            console.log("Network connection lost.");
            // Optional: you can add a toast message here
            this.showToast('Connexion Internet perdue.');
        });
    },

    destroy: function() {
        console.log("Page lehibe détruite.");
        // Optional: remove event listeners on destroy to prevent memory leaks
        window.removeEventListener('online', this.loadVerse);
    }
};