(function() {
  var pageId = 'mifanandrina1';

  var chapters = [];
  var currentView = 'list';
  var currentChapterIndex = null;
  var currentSearchQuery = '';

  function capitalizeFirstLetter(string) {
    if (typeof string !== 'string' || string.length === 0) {
      return '';
    }
  
    var wordsToCapitalize = ['andriamanitra', 'kristy', 'tompo', 'jesosy'];
  
    var lowerCaseString = string.toLowerCase();
  
    var regex = new RegExp('\\b(' + wordsToCapitalize.join('|') + ')\\b', 'gi');
  
    var result = lowerCaseString.replace(regex, function(match) {
      return match.charAt(0).toUpperCase() + match.slice(1);
    });
  
    return result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  function stripHtml(htmlString) {
    var doc = new DOMParser().parseFromString(htmlString, 'text/html');
    return doc.body.textContent || "";
  }
  
  function loadChapters() {
    return new Promise(function(resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('GET', 'data/boky/mifanandrina1.json');
      xhr.onload = function() {
        if (xhr.status === 200) {
          try {
            var data = JSON.parse(xhr.responseText);
            resolve(data.mifanandrina1);
          } catch (e) {
            reject(new Error("Erreur lors de l'analyse JSON: " + e.message));
          }
        } else {
          reject(new Error("Erreur de chargement des chapitres: " + xhr.status));
        }
      };
      xhr.onerror = function() {
        reject(new Error("Erreur réseau lors du chargement des chapitres."));
      };
      xhr.send();
    });
  }

  function getTitle(chapter) {
    for (var key in chapter) {
      if (key.startsWith('title_')) {
        return capitalizeFirstLetter(chapter[key]);
      }
    }
    return 'Titre inconnu';
  }

  function renderList() {
    return (
      '<div class="spa-page" id="mifanandrina1-page">' +
        '<div class="spa-header">' +
          '<img src="assets/icons/arrow_back.svg" alt="Back" class="back-button">' +
          '<div class="title">Hery mifanandrina I</div>' +
          '<img src="assets/icons/search.svg" alt="Search" class="search-button">' +
        '</div>' +
        '<div class="spa-content list-container">' +
          '<div class="list">' +
            '<div class="loading">' +
              '<div class="spinner-button-container">' +
                '<div class="spinner-button"></div>' +
                '<div class="spinner-button delay-1"></div>' +
                '<div class="spinner-button delay-2"></div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<style>' +
          '.spa-header { display: flex; align-items: center; justify-content: space-between; padding-left: 12px; position: fixed; top: 0; width: 100%; background: #006A60; z-index: 1000; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }' +
          '.spa-page { position: relative; height: 100%; overflow: hidden; }' +
          '.spa-header .search-button { margin-right: 0; cursor: none; }' +
          '.spa-header .title { flex-grow: 1; text-align: left; }' +
          '.spa-page-nested .spa-header { display: flex; align-items: center; }' +
          '.spa-page-nested .spa-header .title { flex: 1 1 auto; min-width: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-right: 20px; }' +
          '.spa-header .search-button { cursor: none; }' +
          '.list-container { padding: 0px; margin-top:50px; min-height: 300px; position: relative; }' +
          '.list { display: flex; flex-direction: column; gap: 0px; }' +
          '.row { display: flex; align-items: center; gap: 15px; padding: 15px; color: #424242; border-bottom: 1px solid #d9d9d9; }' +
          '.row:active { background:rgba(0,0,0,0.05); }' +
          '.row .icon { width: 24px; height: 24px; filter:invert(0.5); }' +
          '.row .meta { flex-grow: 1; }' +
          '.row .title { font-size: 18px; font-weight: 500; color: #424242 }' +
          '.row .subtitle { font-size: 14px; color: #757575; margin-top: 4px; }' +
          '.loading { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); display: flex; justify-content: center; }' +
          '.spinner-button-container { display: flex; gap: 10px; align-items: center; justify-content: center; }' +
          '.spinner-button { width: 10px; height: 10px; border-radius: 50%; background-color: #006A60; animation: bounce 1s infinite; }' +
          '.spinner-button.delay-1 { animation-delay: 0.1s; }' +
          '.spinner-button.delay-2 { animation-delay: 0.2s; }' +
          '@keyframes bounce { 0%, 80%, 100% { transform: scale(0); opacity: 0; } 40% { transform: scale(1); opacity: 1; } }' +
          '.error { text-align: center; color: #fff; padding: 20px; }' +
        '</style>' +
      '</div>'
    );
  }

  function renderListContent(loadedChapters) {
    var html = '';
    for (var i = 0; i < loadedChapters.length; i++) {
      var chap = loadedChapters[i];
      html += '<div class="row chapter-item" data-index="' + i + '">' +
        '<img class="icon" src="assets/icons/livre.svg" alt="Icon" />' +
        '<div class="meta">' +
          '<div class="title">' + getTitle(chap) + '</div>' +
          '<div class="subtitle">' + chap.chapter + '</div>' +
        '</div>' +
      '</div>';
    }
    return html;
  }

  function renderChapterContent(chapter) {
    var paragraphsHtml = chapter.paragraphs.map(function(p, i) {
      return '<p id="' + p.id + '" data-paragraph-index="' + i + '">' + p.text + '</p>';
    }).join('');
    return (
      '<div class="spa-page-nested" id="mifanandrina1-content-page">' +
        '<header class="spa-header transparent">' +
          '<img src="assets/icons/arrow_back.svg" alt="Back" class="chapter-back-button">' +
          '<div class="title hidden">' + getTitle(chapter) + '</div>' +
          '<div style="display: flex; gap: 30px;">' +
              '<img src="assets/icons/copy.svg" alt="Copy" class="copy-button">' +
              '<img src="assets/icons/share.svg" alt="Share" class="share-button">' +
          '</div>' +
        '</header>' +
        '<div class="spa-content content-container">' +
          '<div class="image-container">' +
            '<img src="' + chapter.header_image + '" alt="Header Image" class="header-image" />' +
            '<div class="image-title">' + getTitle(chapter) + '</div>' +
          '</div>' +
          paragraphsHtml +
        '</div>' +
        '<div id="copy-feedback" class="copy-feedback">Chapitres copiés</div>' +
        '<style>' +
          '.content-container { padding: 0px; padding-bottom: 20px; color: #2C2C2C; margin-top:0px; }' +
          '.content-container p { font-size: 22px; padding:5px; line-height: 1.6; margin: 0 6px 0 6px; text-align:justify; text-indent: 14px; }' +
          'strong {color:#BF9B7A; font-style:italic; }' +
          '.image-container { position: relative; text-align: left; margin-bottom: 6px; overflow: hidden; }' +
          '.header-image { width: 100%; height: 350px; border-radius: 0px; object-fit: cover; transition: height 0.2s ease; }' +
          '.image-title { position: absolute; bottom: 20px; left: 10px; color: #fff; font-size: 20px; font-weight: bold; text-shadow: 1px 1px 4px rgba(0,0,0,0.7); transition: font-size 0.2s ease, bottom 0.2s ease; }' +
          '.highlight { background-color: #ffff00; color: #2C2C2C; transition: background-color 0.5s ease-out; }' +
          '.highlight-paragraph { background-color: rgba(255, 255, 0, 0.2); transition: background-color 0.5s ease; }' +
          '#mifanandrina1-content-page .spa-header.transparent { background: transparent; box-shadow: none; transition: background 0.3s ease, box-shadow 0.3s ease; justify-content: space-between; }' +
          '#mifanandrina1-content-page .spa-header.scrolled { background: #006A60; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }' +
          '#mifanandrina1-content-page .spa-header .share-button, #mifanandrina1-content-page .spa-header .copy-button { margin-right: 0px; cursor: none; }' +
          '#mifanandrina1-content-page .spa-header .title { opacity: 0; transition: opacity 0.3s ease; }' +
          '#mifanandrina1-content-page .spa-header.scrolled .title { opacity: 1; }' +
          '.copy-feedback { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background-color: #d9d9d9; color: #000000; padding: 10px 20px; border-radius: 50px; z-index: 2000; opacity: 0; transition: opacity 0.5s ease-in-out; font-size: 16px; }' +
          '.copy-feedback.show { opacity: 1; }' +
        '</style>' +
      '</div>'
    );
  }

  function renderSearchPage() {
    return (
      '<div class="spa-page-nested" id="mifanandrina1-search-page">' +
        '<header class="spa-header">' +
          '<img src="assets/icons/arrow_back.svg" alt="Back" class="search-back-button">' +
          '<div class="search-box">' +
            '<input type="text" id="search-input" placeholder="Rechercher un mot..." value="' + currentSearchQuery + '">' +
          '</div>' +
        '</header>' +
        '<div id="search-count-container">' +
          '<div id="search-results-count"></div>' +
        '</div>' +
        '<div class="spa-content search-results-container">' +
          '<div id="search-results" class="list"></div>' +
        '</div>' +
        '<style>' +
          '#mifanandrina1-search-page .spa-header { display: flex; align-items: center; gap: 5px; padding: 10px; }' +
          '.search-box { flex-grow: 1; }' +
          '#search-input { width: 90%; padding: 0px; border: none; background: none; color: #fff; font-size: 16px; box-sizing: border-box; }' +
          '#search-input:focus { outline: none; background: none; }' +
          '#search-input::placeholder { color: #f9f9f9; }' +
          '#search-count-container { position: fixed; top: 50px; width: 100%; padding: 10px; background: transparent; color: #2C2C2C; text-align: left; z-index: 999; font-weight:bold; }' +
          '.search-results-container { margin-top: 90px; padding: 0px; position: relative; height: 100%; }' +
          '.search-results-item { padding: 15px; border-bottom: 1px solid #d9d9d9; }' +
          '.search-results-item h4 { margin: 0; color: #fff; }' +
          '.search-results-item p { margin: 15px 0 0; color: #f9f9f9; font-size: #757575; }' +
          '.highlight-search { background-color: yellow; color: black; }' +
          '.search-empty-icon { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); opacity: 0.5; width: 50px; height: 50px; filter:invert(0.5); }' +
        '</style>' +
      '</div>'
    );
  }

  function performSearch(query) {
    var resultsContainer = document.getElementById('search-results');
    var resultsCountContainer = document.getElementById('search-results-count');
    if (!resultsContainer || !resultsCountContainer) return;

    resultsContainer.innerHTML = '';
    
    if (query.length < 2) {
      resultsContainer.innerHTML = '<img src="assets/icons/empty.svg" alt="Search icon" class="search-empty-icon">';
      resultsCountContainer.textContent = '';
      return;
    }

    var lowerCaseQuery = query.toLowerCase();
    var results = [];

    chapters.forEach(function(chapter, chapterIndex) {
      var title = getTitle(chapter);
      if (title.toLowerCase().includes(lowerCaseQuery)) {
        results.push({
          chapterIndex: chapterIndex,
          title: title,
          snippet: 'Titre : ' + title,
          isTitle: true,
          paragraphId: null
        });
      }

      chapter.paragraphs.forEach(function(paragraph) {
        if (paragraph.text.toLowerCase().includes(lowerCaseQuery)) {
          var words = paragraph.text.split(' ');
          var firstOccurrenceIndex = words.findIndex(function(word) { return word.toLowerCase().includes(lowerCaseQuery); });
          var snippetStart = Math.max(0, firstOccurrenceIndex - 5);
          var snippetEnd = Math.min(words.length, firstOccurrenceIndex + 10);
          var snippet = words.slice(snippetStart, snippetEnd).join(' ') + '...';
          
          results.push({
            chapterIndex: chapterIndex,
            title: title,
            snippet: snippet.replace(new RegExp(query, 'gi'), '<span class="highlight-search">' + query + '</span>'),
            paragraphId: paragraph.id
          });
        }
      });
    });

    resultsCountContainer.textContent = results.length + ' résultat' + (results.length > 1 ? 's' : '') + ' trouvé' + (results.length > 1 ? 's' : '');

    if (results.length > 0) {
      resultsContainer.innerHTML = results.map(function(result) {
        return '<div class="row search-results-item chapter-item" data-index="' + result.chapterIndex + '" data-paragraph-id="' + result.paragraphId + '">' +
          '<div class="meta">' +
            '<div class="title">' + result.title + '</div>' +
            '<div class="subtitle">' + result.snippet + '</div>' +
          '</div>' +
        '</div>';
      }).join('');
    } else {
      resultsContainer.innerHTML = '';
    }
  }

  function showChapter(index, query, paragraphId) {
    var page = document.getElementById('mifanandrina1-page');
    if (!page) return;

    var chapter = chapters[index];
    if (!chapter) return;

    page.insertAdjacentHTML('beforeend', renderChapterContent(chapter));
    
    var nestedPage = page.querySelector('#mifanandrina1-content-page');
    var backButton = nestedPage.querySelector('.chapter-back-button');
    var shareButton = nestedPage.querySelector('.share-button');
    var copyButton = nestedPage.querySelector('.copy-button');
    var headerImage = nestedPage.querySelector('.header-image');
    var imageTitle = nestedPage.querySelector('.image-title');
    var contentContainer = nestedPage.querySelector('.spa-content');
    var chapterHeader = nestedPage.querySelector('.spa-header');
    var copyFeedback = nestedPage.querySelector('#copy-feedback');

    if (backButton) {
      backButton.onclick = function() { window.history.back(); };
    }
    
    if (shareButton) {
      shareButton.onclick = function() {
        var plainTextContent = chapter.paragraphs.map(function(p) { return stripHtml(p.text); }).join('\n\n');
        var shareText = 'Découvrez ce chapitre de \'Hery mifanandrina1\': ' + getTitle(chapter) + '\n\n' + plainTextContent;
        var shareUrl = window.location.href;

        if (window.plugins && window.plugins.socialsharing) {
          window.plugins.socialsharing.shareWithOptions({
            message: shareText,
            url: shareUrl,
            subject: getTitle(chapter)
          }, 
          function(result) {
            console.log("Partage réussi: " + result.completed);
          }, 
          function(error) {
            console.error("Erreur de partage avec Cordova: " + error);
          });
        }
        else if (navigator.share) {
          navigator.share({
            title: getTitle(chapter),
            text: shareText,
            url: shareUrl
          }).then(function() {
            console.log('Partage réussi avec l\'API web.');
          }).catch(function(error) {
            console.error('Erreur lors du partage avec l\'API web:', error);
          });
        }
        else {
          console.error('Aucune API de partage disponible.');
        }
      };
    }

    if (copyButton) {
      copyButton.onclick = function() {
        var textToCopy = getTitle(chapter) + '\n\n' + chapter.paragraphs.map(function(p) { return stripHtml(p.text); }).join('\n\n');
        
        if (navigator.clipboard) {
          navigator.clipboard.writeText(textToCopy).then(function() {
            copyFeedback.classList.add('show');
            setTimeout(function() {
              copyFeedback.classList.remove('show');
            }, 2000);
          }).catch(function(error) {
            console.error('Erreur lors de la copie:', error);
          });
        } else {
            var tempInput = document.createElement('textarea');
            tempInput.style.position = 'absolute';
            tempInput.style.left = '-9999px';
            tempInput.value = textToCopy;
            document.body.appendChild(tempInput);
            tempInput.select();
            try {
                document.execCommand('copy');
                copyFeedback.classList.add('show');
                setTimeout(function() {
                    copyFeedback.classList.remove('show');
                }, 2000);
            } catch (err) {
                console.error('Erreur de copie avec execCommand:', err);
            }
            document.body.removeChild(tempInput);
        }
      };
    }
    
    contentContainer.addEventListener('scroll', function(e) {
      var scrollTop = e.target.scrollTop;
      var minHeight = 50;
      var newHeight = Math.max(350 - scrollTop, minHeight);
      headerImage.style.height = newHeight + 'px';

      var scaleTitle = Math.max(1, newHeight / 350);
      imageTitle.style.fontSize = (20 * scaleTitle) + 'px';
      imageTitle.style.bottom = (20 * scaleTitle) + 'px';
      
      if (scrollTop > 150) {
        chapterHeader.classList.add('scrolled');
      } else {
        chapterHeader.classList.remove('scrolled');
      }
    });

    if (query && paragraphId) {
      var targetParagraph = document.getElementById(paragraphId);
      if (targetParagraph) {
        targetParagraph.classList.add('highlight-paragraph');
        setTimeout(function() {
            targetParagraph.classList.remove('highlight-paragraph');
        }, 5000);

        var highlightedText = targetParagraph.innerHTML.replace(new RegExp(query, 'gi'), function(match) { return '<span class="highlight">' + match + '</span>'; });
        targetParagraph.innerHTML = highlightedText;
        targetParagraph.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        setTimeout(function() {
            var highlightedSpans = targetParagraph.querySelectorAll('.highlight');
            highlightedSpans.forEach(function(span) {
                span.outerHTML = span.innerHTML;
            });
        }, 5000);
      }
    }
    
    setTimeout(function() {
        nestedPage.classList.add('active');
    }, 10);
  }

  function showSearchPage() {
    var page = document.getElementById('mifanandrina1-page');
    if (!page) return;

    page.insertAdjacentHTML('beforeend', renderSearchPage());
    
    var nestedPage = page.querySelector('#mifanandrina1-search-page');
    var backButton = nestedPage.querySelector('.search-back-button');
    var searchInput = nestedPage.querySelector('#search-input');
    var resultsContainer = nestedPage.querySelector('#search-results');
    
    if (backButton) {
      backButton.onclick = function() { window.history.back(); };
    }
    
    if (searchInput) {
      searchInput.focus();
      searchInput.addEventListener('input', function(e) {
        currentSearchQuery = e.target.value;
        performSearch(currentSearchQuery);
      });
    }

    if (resultsContainer) {
      resultsContainer.onclick = function(e) {
        var row = e.target.closest('.chapter-item');
        if (row) {
          var index = parseInt(row.dataset.index);
          var paragraphId = row.dataset.paragraphId;
          hideSearchPage();
          showChapter(index, currentSearchQuery, paragraphId);
          window.history.pushState({ spa: pageId, view: 'content', chapter: index, paragraphId: paragraphId }, "");
        }
      };
    }

    performSearch(currentSearchQuery);

    setTimeout(function() {
        nestedPage.classList.add('active');
    }, 10);
  }

  function hideChapter() {
    var page = document.getElementById('mifanandrina1-page');
    if (!page) return;

    var nestedPage = page.querySelector('#mifanandrina1-content-page');
    if (nestedPage) {
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(function() {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  function hideSearchPage() {
    var page = document.getElementById('mifanandrina1-page');
    if (!page) return;

    var nestedPage = page.querySelector('#mifanandrina1-search-page');
    if (nestedPage) {
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(function() {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  function init() {
    var page = document.getElementById('mifanandrina1-page');
    if (!page) return;
    
    var backButton = page.querySelector('.back-button');
    if (backButton) {
      backButton.onclick = function() { window.history.back(); };
    }

    var searchButton = page.querySelector('.search-button');
    if (searchButton) {
      searchButton.onclick = function() {
        currentSearchQuery = '';
        showSearchPage();
        window.history.pushState({ spa: pageId, view: 'search' }, "");
      };
    }

    var listContainer = page.querySelector('.list-container .list');
    
    loadChapters().then(function(loadedChapters) {
      chapters = loadedChapters;
      if (chapters.length > 0) {
        listContainer.innerHTML = renderListContent(chapters);
      } else {
        listContainer.innerHTML = '<div class="error">Impossible de charger le contenu.</div>';
      }

      listContainer.onclick = function(e) {
        var row = e.target.closest('.chapter-item');
        if (row) {
          currentChapterIndex = parseInt(row.dataset.index);
          showChapter(currentChapterIndex);
          window.history.pushState({ spa: pageId, view: 'content', chapter: currentChapterIndex }, "");
        }
      };
    }).catch(function(error) {
      console.error(error);
      listContainer.innerHTML = '<div class="error">Impossible de charger le contenu.</div>';
    });
  }

  function handlePopState(state) {
    var spaPage = document.getElementById('mifanandrina1-page');
    if (!spaPage) return;
    
    if (state && state.spa === pageId) {
      if (state.view === 'content' && state.chapter !== undefined) {
        if (parseInt(state.chapter) !== currentChapterIndex) {
            hideSearchPage();
            showChapter(parseInt(state.chapter));
        }
        currentView = 'content';
        currentChapterIndex = parseInt(state.chapter);
      } else if (state.view === 'search') {
          hideChapter();
          showSearchPage();
          currentView = 'search';
          currentChapterIndex = null;
      } else if (state.view === 'list') {
        hideChapter();
        hideSearchPage();
        currentView = 'list';
        currentChapterIndex = null;
      } else {
        window.history.back();
      }
    } else {
      hideSpaPage();
    }
  }

  window.drawerPages = window.drawerPages || {};
  window.drawerPages[pageId] = {
    render: function() {
      currentView = 'list';
      currentChapterIndex = null;
      return renderList();
    },
    init: init,
    destroy: function() {},
    handlePopState: handlePopState
  };

})();