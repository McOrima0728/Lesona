(function(){
  const accueil = document.getElementById("accueil");

  const getDailyVerse = async () => {
    try {
      const response = await fetch("data/lisitra/motivation.json");
      const data = await response.json();
      const randomIndex = Math.floor(Math.random() * data.motivs.length);
      return data.motivs[randomIndex].texte;
    } catch (error) {
      console.error("Error fetching verse:", error);
      return "Car Dieu a tant aimé le monde qu'il a donné son Fils unique... (Jean 3:16)";
    }
  };

  const colors = [
    "#e74c3c","#3498db","#2ecc71","#f1c40f","#9b59b6",
    "#e67e22","#1abc9c","#ff6f61","#34495e","#d35400"
  ];

  const getRandomColor = () => colors[Math.floor(Math.random() * colors.length)];

  const updateVerse = async () => {
    const verseText = await getDailyVerse();
    const verseTextElement = document.querySelector(".verse-text");

    const words = verseText.split(" ");
    const indices = new Set();
    while (indices.size < 3 && indices.size < words.length) {
      indices.add(Math.floor(Math.random() * words.length));
    }

    let highlightedVerse = words.map((word,index)=>{
      if(indices.has(index)){
        return `<span style="color: ${getRandomColor()};">${word}</span>`;
      }
      return word;
    }).join(" ");

    if(verseTextElement){
      verseTextElement.innerHTML = highlightedVerse;
    } else {
      accueil.innerHTML = `
        <div class="verse-container">
          <img src="assets/acceuil/verses.jpg" alt="Verset" />
          <div class="verse-overlay">
            <p class="verse-text">${highlightedVerse}</p>
            <div class="verse-actions">
              <div class="icon-action" id="copyVerse">
                <img src="assets/icons/copy.svg" alt="Copier"/>
              </div>
              <div class="icon-action" id="shareVerse">
                <img src="assets/icons/share.svg" alt="Partager"/>
              </div>
            </div>
          </div>
        </div>

        <div class="content-section">
          <h2>Tenin'Andriamanitra</h2>
          <div class="carousel no-scrollbar">
            <div class="item" data-page="teniny"><img src="assets/acceuil/bible.jpg" alt="Velomin'ny Teniny"><p>Velomin'ny Teniny</p></div>
            <div class="item" data-page="salamo"><img src="assets/acceuil/psaume.jpg" alt="Salamo"><p>Salamo</p></div>
            <div class="item" data-page="filazantsara"><img src="assets/acceuil/evangile.jpg" alt="Filazantsara"><p>Filazantsara</p></div>
            <div class="item" data-page="epistily"><img src="assets/acceuil/epitres.jpg" alt="Epistily"><p>Epistily</p></div>
          </div>

          <h2>Lesona isan'andro</h2>
          <div class="carousel no-scrollbar">
            <div class="item" data-page="mofo"><img src="assets/acceuil/pains.jpg" alt="Mofon'aina"><p>Mofon'aina</p></div>
            <div class="item" data-page="mofonaina"><img src="assets/acceuil/message.jpg" alt="Mofon'aina"><p>Vatsim-panahy</p></div>
            <div class="item" data-page="lehibe"><img src="assets/acceuil/lehibe.png" alt="Lehibe"><p>Leson'ny lehibe</p></div>
            <div class="item" data-page="tanoraz"><img src="assets/acceuil/tanora.png" alt="Tanora"><p>Leson'ny tanora</p></div>
          </div>
        </div>
      `;
    }

    document.getElementById("copyVerse").onclick = async ()=>{
      try {
        await navigator.clipboard.writeText(verseText);
        window.showToast("Verset copié");
      } catch {
        window.showToast("Erreur de copie");
      }
    };

    document.getElementById("shareVerse").onclick = ()=>{
      if(navigator.share){
        navigator.share({ title:"Verset biblique", text:verseText })
          .then(()=> window.showToast("Verset partagé"))
          .catch(()=> window.showToast("Partage annulé"));
      } else {
        window.showToast("Partage non supporté");
      }
    };

    document.querySelectorAll('.carousel').forEach(c=>{
      c.addEventListener('touchstart', e=> e.stopPropagation(), {passive:true});
      c.addEventListener('touchmove', e=> e.stopPropagation(), {passive:true});
    });

    const handleCarouselClick = (e) => {
        const item = e.currentTarget;
        const pageName = item.dataset.page;
        window.goToSpaPage(pageName);
    };
    
    document.querySelectorAll('.carousel .item').forEach(item => {
        item.addEventListener('click', handleCarouselClick);
    });
  };

  const scheduleNextUpdate = () => {
    const now = new Date();
    const midnight = new Date(now);
    midnight.setDate(now.getDate()+1);
    midnight.setHours(0,0,0,0);
    const msUntilMidnight = midnight.getTime() - now.getTime();

    setTimeout(()=>{
      updateVerse();
      setInterval(updateVerse,24*60*60*1000);
    },msUntilMidnight);
  };

  const init = async () => {
    await updateVerse();

    const style = document.createElement("style");
    style.textContent = `
      .verse-container {
        position:relative;
        margin-bottom:0;
        border-radius:0;
        overflow:hidden;
        height:400px;
        z-index:2;
        width:100%;
      }
      .verse-container img { height:100%; width:100%; display:block; }
      .verse-overlay {
        position:absolute; inset:0;
        background-color: rgba(0, 0, 0, 0.1);
        display:flex; flex-direction:column; justify-content:center; align-items:center;
        color:#fff; padding:14px; text-align:center;
      }
      .verse-text {
        margin-top:auto;
        font-size:22px;
        font-weight:bold;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.9);
      }

      .verse-actions {
        margin-top:100px;
        display:flex;
        gap:80px;
      }
      .icon-action {
        width:40px;
        height:40px;
        border-radius:50%;
        margin-bottom:20px;
        display:flex;
        justify-content:center;
        align-items:center;
        background: rgba(255,255,255,0.1);
        cursor:none;
        transition: transform 0.2s;
      }
      .icon-action img {
        width:22px;
        height:22px;
      }
      .content-section {
        background:#ffffff;
        position:relative;
        margin-top:-20px;
        z-index:3;
        border-top-left-radius:15px;
        border-top-right-radius:15px;
        padding:10px 0;
      }

      .content-section h2 {
        margin:10px 20px;
        font-size:20px;
        font-weight:700;
        color: #4E3D43;
      }

      .carousel {
        display:flex;
        gap:6px;
        overflow-x:auto;
        padding-bottom:8px;
        margin-bottom:10px;
        margin-right:1px;
        margin-left:1px;
      }
      .carousel .item:first-child{margin-left:10px;}
      .carousel .item:last-child{margin-right:10px;}
      .carousel .item {
        margin-left:10px; width:42%;
        background:#F6F7FC; border-radius:8px;
        box-shadow:0 2px 6px rgba(0,0,0,.12);
        overflow:hidden; flex-shrink:0;
        scroll-snap-align:start;
        border: 2px solid #d9d9d9;
      }
      .carousel .item img{ width:100%; height:200px; object-fit:cover; }
      .carousel .item p{
        padding:10px; font-size:16px; font-weight:bold;
        text-align:center; text-transform:uppercase; color: #006A60;
      }
    `;
    document.head.appendChild(style);
    scheduleNextUpdate();
  };

  init();
})();