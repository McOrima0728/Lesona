window.drawerPages = window.drawerPages || {};

window.drawerPages["recherche"] = {
    render: function() {
        return `
            <style>
                /* Styles pour le header fixé */
                .spa-header {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    z-index: 1000;
                    background-color: #006A60;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    padding: 14px;
                    display: flex;
                    align-items: center;
                    color: #fff;
                }
                .spa-header img {
                    width: 24px;
                    height: 24px;
                    margin-right: 10px;
                }
                .spa-header .title {
                    font-size: 20px;
                    font-weight: bold;
                }
            
                .recherche-content {
                    padding: 14px;
                    margin-top: 50px;
                    background: #ffffff;
                }

                /* Barre de recherche fixée */
                .search-bar {
                    position: sticky;
                    top: 50px; /* juste sous le header SPA */
                    background: #fff;
                    z-index: 10;
                    padding: 10px 0;
                }

                .search-input-wrapper {
                    position: relative;
                    width: 100%;
                }

                .search-input {
                    width: 100%;
                    padding: 10px 40px 10px 14px; /* padding right pour icône */
                    border-radius: 25px;
                    border: 1px solid #ccc;
                    font-size: 14px;
                    outline: none;
                    transition: border 0.3s;
                }

                .search-input:focus {
                    border-color: #1C627E;
                }

                .search-icon {
                    position: absolute;
                    right: 14px;
                    top: 50%;
                    transform: translateY(-50%);
                    width: 20px;
                    height: 20px;
                    pointer-events: none;
                    opacity: 0.6;
                }

                /* Résultats */
                .results {
                    margin-top: 20px;
                }

                .result-item {
                    padding: 12px;
                    border-bottom: 1px solid #eee;
                }
                .result-item:last-child {
                    border-bottom: none;
                }
            </style>

            <div class="spa-page">
                <header class="spa-header">
                    <img src="assets/icons/arrow_back.svg" alt="Retour">
                    <div class="title">Recherche</div>
                </header>

                <div class="spa-content recherche-content">

                    <div class="search-bar">
                        <div class="search-input-wrapper">
                            <input type="text" id="search-input" class="search-input" placeholder="Rechercher...">
                            <img src="assets/icons/search.svg" class="search-icon" alt="Search">
                        </div>
                    </div>

                    <div class="results" id="search-results">
                        </div>
                </div>
            </div>
        `;
    },

    init: function() {
        console.log("Page 'Recherche' initialisée.");

        const input = document.getElementById("search-input");
        const results = document.getElementById("search-results");

        input.addEventListener("input", () => {
            const query = input.value.trim();
            results.innerHTML = "";

            if (query.length > 0) {
                // 👉 Exemple de mock résultats
                const fakeResults = [
                    "Résultat 1 pour " + query,
                    "Résultat 2 pour " + query,
                    "Résultat 3 pour " + query
                ];

                fakeResults.forEach(r => {
                    const item = document.createElement("div");
                    item.className = "result-item";
                    item.textContent = r;
                    results.appendChild(item);
                });
            }
        });
    },

    destroy: function() {
        console.log("Page 'Recherche' détruite.");
    }
};