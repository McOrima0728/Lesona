document.addEventListener('deviceready', function() {
    StatusBar.overlaysWebView(true);
    StatusBar.backgroundColorByHexString('#00000000');
    StatusBar.styleDefault(); 
}, false);