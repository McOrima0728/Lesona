(function() {
  const pageId = 'protestanta';
  const BIBLE_DATA_PATH = 'data/baiboly/protestanta/';
  const BOOK_LIST = [
      'genesisy', 'eksodosy', 'levitikosy', 'nomery', 'deoteronomia',
      'josoa', 'mpitsara', 'rota', '1-samoela', '2-samoela', '1-mpanjaka', '2-mpanjaka',
      '1-tantara', '2-tantara', 'ezra', 'nehemia', 'estera', 'joba', 'salamo',
      'ohabolana', 'mpitoriteny', 'tononkira-tononkira', 'isaia', 'jeremia',
      'fitomaniana', 'zekielia', 'daniela', 'hosea', 'joela', 'amosa', 'obadia',
      'jona', 'mika', 'nahoma', 'habakoka', 'zefania', 'hagea', 'zakaria', 'malakia',
      'matio', 'marka', 'lioka', 'jaona', 'asa', 'romana', '1-korintiana',
      '2-korintiana', 'galatiana', 'efesiana', 'filipiana', 'kolosiana',
      '1-tesaloniana', '2-tesaloniana', '1-timoty', '2-timoty', 'titosy', 'filemona',
      'hebreo', 'jakoba', '1-petera', '2-petera', '1-jaona', '2-jaona', '3-jaona',
      'joda', 'apokalypsy'
  ];

  let currentView = 'list';
  let currentBook = 'genesisy';
  let currentChapter = '1';
  let currentVerse = null;
  const spaContainer = document.getElementById('spa-container');
  let bibleDataCache = {};
  let selectedVerseElements = [];
  const localStorageKey = 'protestanta_verse_colors';

  async function fetchBookData(bookName) {
      if (bibleDataCache[bookName]) {
          return bibleDataCache[bookName];
      }
      try {
        const response = await fetch(`${BIBLE_DATA_PATH}${bookName}.json`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        bibleDataCache[bookName] = data;
        return data;
      } catch (error) {
        console.error(`Failed to fetch book data for ${bookName}:`, error);
        return null;
      }
  }

  function renderList() {
    const bookTitle = currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ');
    return `
      <div class="spa-page" id="protestanta-page">
        <div class="spa-header" id="list-header">
          <img src="assets/icons/menu.svg" alt="Menu" class="menu-button">
          <div class="title" id="list-title">${bookTitle} ${currentChapter}</div>
        </div>
        <div class="spa-content list-container" id="list-container">
          <div class="image-wrapper" id="chapter-image-container">
            <img src="assets/bible/bibles.jpg" alt="Image de fond du chapitre de la Bible" class="chapter-image">
            <div class="image-overlay">
              <h1 class="image-chapter-title" id="image-chapter-title-placeholder"></h1>
            </div>
          </div>
          <div class="verse-content" id="verse-content-placeholder">
            <p>Loading verses...</p>
          </div>
        </div>
        <div class="navigation-controls">
            <button id="previous-chapter-button" class="nav-button">
              <img src="assets/icons/precedent.svg" alt="Précédent" class="nav-icon">
            </button>
            <button id="next-chapter-button" class="nav-button">
              <img src="assets/icons/next.svg" alt="Suivant" class="nav-icon">
            </button>
        </div>
        <style>
          /* Styles pour la navigation fixée en bas */
          .navigation-controls {
            position: fixed;
            bottom: 10px;
            left: 0;
            right: 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px;
            z-index: 1000;
          }

          .nav-button {
            background-color: #006A60;
            border: none;
            cursor: none;
            padding: 8px;
            border-radius: 10px;
            transition: background-color 0.3s ease;
          }

          .nav-button:disabled {
            opacity: 0.3;
            cursor: not-allowed;
          }

          .nav-icon {
            width: 24px;
            height: 24px;
          }
          
          .list-container { 
            padding: 0px; 
            margin-top:0px;
            padding-bottom: 80px;
          }
          .verse-content { display: flex; flex-direction: column; color: #2c2c2c; line-height: 1.5; }
          .verse-content p { font-size: 20px; margin-bottom: 0; padding-left: 14px; padding-right: 14px;cursor: none; margin-bottom:20px;}
          
          /* Style de la lettrine */
          .verse-content p:first-child .lettrine-first-letter {
              font-size: 4em;
              font-family: serif;
              float: left;
              line-height: 1;
              margin-right: 10px;
              text-transform: uppercase;
              color: #006A60;
          }

          /* Style pour les numéros de verset */
          .verse-content p strong {
            color: #006A60;
          }

          @keyframes highlight-verse {
              from { background-color: #d9d9d9; }
              to { background-color: transparent; }
          }
          .highlighted {
              animation: highlight-verse 10s ease-out forwards;
              border-radius: 0px;
          }
          
          .verse-item.selected {
              background-color: #d9d9d9;
          }

          /* Styles pour le conteneur d'image */
          .image-wrapper {
              position: relative;
              width: 100%;
              height: 300px;
              overflow: hidden;
              transition: height 0.4s ease-out;
              margin-bottom:20px;
          }
          .scrolled-image {
              height: 250px;
          }

          .chapter-image {
              width: 100%;
              height: 100%;
              object-fit: cover;
              object-position: center;
          }

          .image-overlay {
              position: absolute;
              bottom: 0;
              left: 0;
              width: 100%;
              padding: 10px;
              background: linear-gradient(to top, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0));
              display: flex;
              align-items: flex-end;
          }

          .image-chapter-title {
              color: #fff;
              font-size: 24px;
              font-weight: bold;
              margin-bottom: 15px;
              padding: 0 5px;
          }

          /* Styles de l'en-tête (nouvelles classes) */
          .spa-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 50px;
            display: flex;
            align-items: center;
            padding: 0 16px;
            background-color: transparent;
            z-index: 1000;
          }
          
          .spa-page { position: relative; height: 100%; overflow: hidden; }
          
          .scrolled-header {
            background-color: #006A60;
          }
          
          /* Styles pour le titre */
          .spa-header .title {
              opacity: 0;
          }
          .scrolled-header .title {
              opacity: 1;
          }

          /* Styles pour le sous-menu de verset */
          .verse-menu-container {
              position: fixed;
              bottom: 0;
              left: 0;
              width: 100%;
              background-color: #1a1a1a;
              padding: 16px 0;
              border-top-left-radius: 16px;
              border-top-right-radius: 16px;
              transform: translateY(100%);
              transition: transform 0.3s ease-in-out;
              box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
              z-index: 2000;
          }
          .verse-menu-container.show {
              transform: translateY(0);
          }
          
          .menu-title {
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 16px;
          }
          
          .close-handle {
              width: 40px;
              height: 4px;
              background-color: #555;
              border-radius: 2px;
              margin: 0 auto 16px;
              cursor: none;
          }
          
          .menu-section {
              display: flex;
              justify-content: center;
              padding: 10px 0;
          }

          .color-palette {
              display: flex;
              gap: 12px;
          }
          .color-option {
              width: 32px;
              height: 32px;
              border-radius: 50%;
              border: 2px solid transparent;
              cursor: none;
              transition: transform 0.2s ease, border-color 0.2s ease;
          }
          .color-option:hover {
              transform: scale(1.1);
          }
          .color-option.reset {
              background-color: transparent;
              border: 1px dashed #555;
          }
          .color-option.reset img {
              width: 18px;
              height: 18px;
              opacity: 0.7;
              margin: 5px;
          }

          .action-buttons {
              display: flex;
              justify-content: space-around;
              width: 100%;
              padding: 0 16px;
              box-sizing: border-box;
              margin-top: 20px;
          }
          .action-button {
              display: flex;
              align-items: center;
              background-color: #2a2a2a;
              color: #fff;
              border: none;
              padding: 8px 16px;
              border-radius: 20px;
              cursor: none;
              font-size: 14px;
              transition: background-color 0.2s ease;
          }
          .action-button:hover {
              background-color: #3f3f3f;
          }
          .action-button img {
              width: 18px;
              height: 18px;
              margin-right: 8px;
          }
        </style>
      </div>
    `;
  }
  
  async function fetchAndRenderVerses(scrollToVerse = false) {
    const placeholder = document.getElementById('verse-content-placeholder');
    const imageTitlePlaceholder = document.getElementById('image-chapter-title-placeholder');
    if (!placeholder || !imageTitlePlaceholder) return;
    
    selectedVerseElements = [];
    hideVerseActionsMenu();
    
    const bookTitle = currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ');
    imageTitlePlaceholder.textContent = `${bookTitle} ${currentChapter}`;

    try {
      const data = await fetchBookData(currentBook);
      if (!data) {
          placeholder.innerHTML = `<p>Error loading book data.</p>`;
          return;
      }
      const chapterData = data[currentChapter];
      if (!chapterData) {
        placeholder.innerHTML = `<p>Chapter ${currentChapter} data not found.</p>`;
        return;
      }
      let htmlContent = '';
      for (const verseNumber in chapterData) {
        let verseText = chapterData[verseNumber];
        if (verseNumber === '1') {
            const firstLetter = verseText.charAt(0);
            const restOfText = verseText.slice(1);
            verseText = `<span class="lettrine-first-letter">${firstLetter}</span>${restOfText}`;
            htmlContent += `<p class="verse-item" id="verse-${verseNumber}" data-verse="${verseNumber}">${verseText}</p>`;
        } else {
            htmlContent += `<p class="verse-item" id="verse-${verseNumber}" data-verse="${verseNumber}"><strong>${verseNumber}</strong> ${verseText}</p>`;
        }
      }
      placeholder.innerHTML = htmlContent;
      
      loadVerseColors();
      
      if (scrollToVerse && currentVerse) {
          setTimeout(() => {
              const verseElement = document.getElementById(`verse-${currentVerse}`);
              if (verseElement) {
                  verseElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  verseElement.classList.add('highlighted');
              }
          }, 100);
      } else {
        const listContainer = document.getElementById('list-container');
        if (listContainer) {
          listContainer.scrollTop = 0;
        }
      }
      updateNavigationButtonsState();
      setupVerseClickListeners();
    } catch (error) {
      console.error("Failed to fetch verses:", error);
      placeholder.innerHTML = `<p>Error loading verses. Please check the file path and network connection.</p>`;
    }
  }

  function renderMenuPage() {
      return `
      <div class="spa-page-nested" id="menu-page">
          <div class="spa-header">
              <img src="assets/icons/arrow_back.svg" alt="Back" class="menu-back-button">
              <div class="title">Baiboly protestanta</div>
          </div>
          <div class="spa-nav-bar">
              <div class="nav-item active" data-tab="livre">
                  <span>Livre</span>
                  <div class="indicator"></div>
              </div>
              <div class="nav-item" data-tab="chapitre">
                  <span>Chapitre</span>
                  <div class="indicator"></div>
              </div>
              <div class="nav-item" data-tab="verset">
                  <span>Verset</span>
                  <div class="indicator"></div>
              </div>
          </div>
          <div class="spa-content content-container-menu">
              <div id="livre-content" class="tab-content active">
                <ul class="nav-list nav-list-grid-2" id="book-list"></ul>
              </div>
              <div id="chapitre-content" class="tab-content">
                <div class="nav-grid" id="chapter-list"></div>
              </div>
              <div id="verset-content" class="tab-content">
                <div class="nav-grid" id="verse-list"></div>
              </div>
          </div>
      </div>
      <style>
          .spa-page-nested .spa-header { position: fixed; top: 0; width: 100%; z-index: 1000; background-color: #006A60;}
          .spa-page-nested .spa-header .title { opacity: 1; }
          .spa-nav-bar { position: fixed; top: 50px; width: 100%; height: 50px; display: flex; justify-content: space-around; align-items: center; background-color: transparent; border-bottom: 1px solid #d9d9d9; z-index: 999; }
          .nav-item { display: flex; flex-direction: column; align-items: center; cursor: none; color: #2c2c2c; font-size: 18px; position: relative; padding: 0 10px; height: 100%; justify-content: center; }
          .nav-item.active { color: #006A60; font-weight:bold;}
          .nav-item .indicator { position: absolute; bottom: 0; left: 50%; transform: translateX(-50%); width: 0; height: 3px; background-color: #006A60; transition: width 0.3s ease-in-out; }
          .nav-item.active .indicator { width: 100%; }
          .content-container-menu { padding: 20px; color: #2c2c2c; line-height: 1.6; margin-top: 100px; }
          .tab-content { display: none; }
          .tab-content.active { display: block; }

          .nav-list-grid-2 {
            list-style: none;
            padding: 0;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
          }
          .nav-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(60px, 1fr));
            gap: 10px;
          }
          .nav-list-item, .nav-grid-item {
            padding: 8px;
            border: 1px solid #d9d9d9;
            border-radius: 12px;
            text-align: center;
            cursor: none;
            transition: background-color 0.3s ease;
          }
          .nav-list-item.active, .nav-grid-item.active { background-color: #d9d9d9; color: #006A60; font-weight: bold; }
      </style>
      `;
  }
  
  function updateMenuContent(view) {
      const menuPage = document.getElementById('menu-page');
      if (!menuPage) return;
      
      const navItems = menuPage.querySelectorAll('.nav-item');
      const tabContents = menuPage.querySelectorAll('.tab-content');

      navItems.forEach(nav => {
          if (nav.getAttribute('data-tab') === view) {
              nav.classList.add('active');
          } else {
              nav.classList.remove('active');
          }
      });
      tabContents.forEach(content => {
          if (content.id === `${view}-content`) {
              content.classList.add('active');
          } else {
              content.classList.remove('active');
          }
      });
  }

  async function populateBookList() {
      const list = document.getElementById('book-list');
      if (!list) return;
      let html = '';
      BOOK_LIST.forEach(book => {
          const bookTitle = book.charAt(0).toUpperCase() + book.slice(1).replace(/_/g, ' ').replace(/-/g, ' ');
          const activeClass = book === currentBook ? 'active' : '';
          html += `<li class="nav-list-item ${activeClass}" data-item="${book}">${bookTitle}</li>`;
      });
      list.innerHTML = html;
      list.querySelectorAll('.nav-list-item').forEach(item => {
          item.addEventListener('click', () => {
              currentBook = item.getAttribute('data-item');
              currentChapter = '1';
              currentVerse = null;
              populateChapterList();
              updateMenuContent('chapitre');
          });
      });
  }

  async function populateChapterList() {
      const list = document.getElementById('chapter-list');
      if (!list) return;
      
      try {
          const data = await fetchBookData(currentBook);
          if (!data) {
              list.innerHTML = `<div class="nav-grid-item">Erreur de chargement.</div>`;
              return;
          }
          const chapterNumbers = Object.keys(data).map(Number).sort((a, b) => a - b);
          let html = '';
          chapterNumbers.forEach(chapter => {
              const activeClass = String(chapter) === currentChapter ? 'active' : '';
              html += `<div class="nav-grid-item ${activeClass}" data-item="${chapter}">${chapter}</div>`;
          });
          list.innerHTML = html;
          list.querySelectorAll('.nav-grid-item').forEach(item => {
              item.addEventListener('click', () => {
                  currentChapter = item.getAttribute('data-item');
                  currentVerse = null;
                  populateVerseList();
                  updateMenuContent('verset');
              });
          });
          
      } catch (error) {
          console.error("Failed to populate chapter list:", error);
      }
  }
  
  async function populateVerseList() {
      const list = document.getElementById('verse-list');
      if (!list) return;
      try {
          const data = await fetchBookData(currentBook);
          if (!data) {
              list.innerHTML = `<div class="nav-grid-item">Erreur de chargement.</div>`;
              return;
          }
          const chapterData = data[currentChapter];
          if (!chapterData) {
              list.innerHTML = `<div class="nav-grid-item">Aucun verset trouvé pour ce chapitre.</div>`;
              return;
          }
          const verseNumbers = Object.keys(chapterData);
          let html = '';
          verseNumbers.forEach(verse => {
              const activeClass = verse === currentVerse ? 'active' : '';
              html += `<div class="nav-grid-item ${activeClass}" data-item="${verse}">${verse}</div>`;
          });
          list.innerHTML = html;
          list.querySelectorAll('.nav-grid-item').forEach(item => {
              item.addEventListener('click', () => {
                  currentVerse = item.getAttribute('data-item');
                  hideMenuPage();
                  fetchAndRenderVerses(true);
                  updatePageTitle();
              });
          });
      } catch (error) {
          console.error("Failed to populate verse list:", error);
      }
  }
  
  function updatePageTitle() {
      const pageTitleElement = document.querySelector('#protestanta-page .title');
      if(pageTitleElement) {
          const bookTitle = currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ');
          pageTitleElement.textContent = `${bookTitle} ${currentChapter}`;
      }
  }

  function showMenuPage() {
    const page = document.getElementById('protestanta-page');
    if (!page) return;
    
    page.insertAdjacentHTML('beforeend', renderMenuPage());
    
    const nestedPage = page.querySelector('#menu-page');
    const backButton = nestedPage.querySelector('.menu-back-button');
    if (backButton) {
        backButton.onclick = () => window.history.back();
    }

    const navItems = nestedPage.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const view = item.getAttribute('data-tab');
            updateMenuContent(view);
            if (view === 'livre') {
                populateBookList();
            } else if (view === 'chapitre') {
                populateChapterList();
            } else if (view === 'verset') {
                populateVerseList();
            }
        });
    });
    
    setTimeout(() => {
        nestedPage.classList.add('active');
        populateBookList();
    }, 10);
  }

  function hideChapter() {
      const page = document.getElementById('protestanta-page');
      if (!page) return;
      const nestedPage = page.querySelector('#protestanta-content-page');
      if (nestedPage) {
        nestedPage.classList.remove('active');
        setTimeout(() => nestedPage.parentNode.removeChild(nestedPage), 400);
      }
  }

  function hideMenuPage() {
      const page = document.getElementById('protestanta-page');
      if (!page) return;
      const nestedPage = page.querySelector('#menu-page');
      if (nestedPage) {
          nestedPage.classList.remove('active');
          nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
          nestedPage.style.transform = 'scale(0.98)';
          nestedPage.style.opacity = '0';
          setTimeout(() => {
              nestedPage.parentNode.removeChild(nestedPage);
          }, 400);
      }
  }

  function handleScroll() {
      const header = document.getElementById('list-header');
      const imageContainer = document.getElementById('chapter-image-container');
      const listContainer = document.getElementById('list-container');
      
      if (!header || !imageContainer || !listContainer) return;

      const scrollPosition = listContainer.scrollTop;

      if (scrollPosition >= 250) {
          header.classList.add('scrolled-header');
          imageContainer.classList.add('scrolled-image');
      } else {
          header.classList.remove('scrolled-header');
          imageContainer.classList.remove('scrolled-image');
      }
  }

  function updateNavigationButtonsState() {
      const previousButton = document.getElementById('previous-chapter-button');
      const nextButton = document.getElementById('next-chapter-button');

      if (!previousButton || !nextButton) return;

      const isFirstChapter = (currentBook === 'genesisy' && currentChapter === '1');
      const isLastChapter = (currentBook === 'apokalypsy' && currentChapter === '22');

      previousButton.disabled = isFirstChapter;
      nextButton.disabled = isLastChapter;
  }

  async function goToPreviousChapter() {
    if (currentBook === 'genesisy' && currentChapter === '1') {
      return;
    }
    const currentBookIndex = BOOK_LIST.indexOf(currentBook);
    let newChapter = parseInt(currentChapter) - 1;
    let newBook = currentBook;

    if (newChapter < 1) {
      newBook = BOOK_LIST[currentBookIndex - 1];
      const prevBookData = await fetchBookData(newBook);
      if (prevBookData) {
        const lastChapter = Object.keys(prevBookData).length;
        newChapter = lastChapter;
      } else {
        newChapter = 1; 
      }
    }

    currentBook = newBook;
    currentChapter = String(newChapter);
    fetchAndRenderVerses();
    updatePageTitle();
  }

  async function goToNextChapter() {
    if (currentBook === 'apokalypsy' && currentChapter === '22') {
      return;
    }
    const currentBookIndex = BOOK_LIST.indexOf(currentBook);
    const bookData = await fetchBookData(currentBook);
    const totalChapters = Object.keys(bookData).length;
    let newChapter = parseInt(currentChapter) + 1;
    let newBook = currentBook;

    if (newChapter > totalChapters) {
      newBook = BOOK_LIST[currentBookIndex + 1];
      newChapter = 1;
    }

    currentBook = newBook;
    currentChapter = String(newChapter);
    fetchAndRenderVerses();
    updatePageTitle();
  }

  function setupNavigationListeners() {
    const previousButton = document.getElementById('previous-chapter-button');
    const nextButton = document.getElementById('next-chapter-button');

    if (previousButton) {
      previousButton.addEventListener('click', goToPreviousChapter);
    }
    if (nextButton) {
      nextButton.addEventListener('click', goToNextChapter);
    }
  }

  function setupScrollListener() {
    const listContainer = document.getElementById('list-container');
    if (listContainer) {
        listContainer.addEventListener('scroll', handleScroll);
        handleScroll();
    }
  }

  function formatVerseRange() {
      if (selectedVerseElements.length === 0) {
          return '';
      }
      const verses = selectedVerseElements
          .map(el => parseInt(el.dataset.verse))
          .sort((a, b) => a - b);

      if (verses.length === 1) {
          return `${verses[0]}`;
      }

      let ranges = [];
      let start = verses[0];
      let end = verses[0];
      
      for (let i = 1; i < verses.length; i++) {
          if (verses[i] === end + 1) {
              end = verses[i];
          } else {
              if (start === end) {
                  ranges.push(start);
              } else {
                  ranges.push(`${start}-${end}`);
              }
              start = verses[i];
              end = verses[i];
          }
      }
      if (start === end) {
          ranges.push(start);
      } else {
          ranges.push(`${start}-${end}`);
      }
      
      return ranges.join(',');
  }
  
  function saveVerseColors(verseId, color) {
    let colors = JSON.parse(localStorage.getItem(localStorageKey)) || {};
    if (color) {
      colors[verseId] = color;
    } else {
      delete colors[verseId];
    }
    localStorage.setItem(localStorageKey, JSON.stringify(colors));
  }
  
  function loadVerseColors() {
    const colors = JSON.parse(localStorage.getItem(localStorageKey)) || {};
    const verseElements = document.querySelectorAll('.verse-item');
    verseElements.forEach(el => {
      const verseId = `${currentBook}-${currentChapter}-${el.dataset.verse}`;
      if (colors[verseId]) {
        el.style.color = colors[verseId];
      } else {
        el.style.color = ''; // Reset to default CSS color
      }
    });
  }

  // Fonctions pour le sous-menu de verset
  function renderVerseActionsMenu() {
      const bookTitle = currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ');
      const title = `${bookTitle} ${currentChapter}:${formatVerseRange()}`;
      return `
      <div class="verse-menu-container">
          <div class="close-handle"></div>
          <div class="menu-title" id="verse-menu-title">${title}</div>
          <div class="menu-section">
              <div class="color-palette">
                  <div class="color-option" style="background-color: #fdd835;" data-color="#fdd835"></div>
                  <div class="color-option" style="background-color: #d1c4e9;" data-color="#d1c4e9"></div>
                  <div class="color-option" style="background-color: #a5d6a7;" data-color="#a5d6a7"></div>
                  <div class="color-option" style="background-color: #ffab91;" data-color="#ffab91"></div>
                  <div class="color-option" style="background-color: #81d4fa;" data-color="#81d4fa"></div>
                  <div class="color-option" style="background-color: #cfd8dc;" data-color="#cfd8dc"></div>
                  <div class="color-option reset">
                      <img src="assets/icons/reset.svg" alt="Reset Color">
                  </div>
              </div>
          </div>
          <div class="menu-section action-buttons">
              <button class="action-button" id="copy-verse-button">
                  <img src="assets/icons/copy.svg" alt="Copy">
                  <span>Copier</span>
              </button>
              <button class="action-button" id="favorite-verse-button">
                  <img src="assets/icons/favorite.svg" alt="Favorite">
                  <span>Favoris</span>
              </button>
              <button class="action-button" id="share-verse-button">
                  <img src="assets/icons/share.svg" alt="Share">
                  <span>Partager</span>
              </button>
          </div>
      </div>
      `;
  }
  
  function showVerseActionsMenu() {
      const page = document.getElementById('protestanta-page');
      if (!page) return;

      const existingMenu = page.querySelector('.verse-menu-container');
      if (existingMenu) {
          existingMenu.remove();
      }
      
      page.insertAdjacentHTML('beforeend', renderVerseActionsMenu());
      const menuContainer = page.querySelector('.verse-menu-container');

      setTimeout(() => {
          menuContainer.classList.add('show');
      }, 10);

      const closeMenu = () => {
          menuContainer.classList.remove('show');
          selectedVerseElements.forEach(el => el.classList.remove('selected'));
          selectedVerseElements = [];
          setTimeout(() => menuContainer.remove(), 300);
      };
      
      menuContainer.querySelector('.close-handle').addEventListener('click', closeMenu);

      setupMenuActionListeners();
  }

  function hideVerseActionsMenu() {
    const page = document.getElementById('protestanta-page');
    if (!page) return;
    const existingMenu = page.querySelector('.verse-menu-container');
    if (existingMenu) {
        existingMenu.classList.remove('show');
        selectedVerseElements.forEach(el => el.classList.remove('selected'));
        selectedVerseElements = [];
        setTimeout(() => existingMenu.remove(), 300);
    }
  }

  function setupMenuActionListeners() {
      // Color options
      const colorOptions = document.querySelectorAll('.color-option');
      colorOptions.forEach(option => {
          option.addEventListener('click', (e) => {
              const color = e.currentTarget.getAttribute('data-color');
              selectedVerseElements.forEach(el => {
                  const verseId = `${currentBook}-${currentChapter}-${el.dataset.verse}`;
                  if (color) {
                      el.style.color = color;
                      saveVerseColors(verseId, color);
                  } else {
                      el.style.color = '';
                      saveVerseColors(verseId, null);
                  }
              });
              hideVerseActionsMenu(); // Fermer le menu après l'action
          });
      });

      // Action buttons
      document.getElementById('copy-verse-button').addEventListener('click', () => {
          const textToCopy = selectedVerseElements.map(el => el.innerText.trim()).join('\n');
          const finalText = `${currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ')} ${currentChapter}:${formatVerseRange()}\n${textToCopy}`;
          navigator.clipboard.writeText(finalText).catch(err => {
              console.error('Erreur lors de la copie: ', err);
          });
          hideVerseActionsMenu(); // Fermer le menu après l'action
      });

      document.getElementById('favorite-verse-button').addEventListener('click', () => {
          // Logique pour ajouter aux favoris (sans alerte)
          console.log('Ajouté aux favoris:', selectedVerseElements.map(el => el.id));
          hideVerseActionsMenu(); // Fermer le menu après l'action
      });

      document.getElementById('share-verse-button').addEventListener('click', async () => {
          if (navigator.share) {
              const textToShare = selectedVerseElements.map(el => el.innerText.trim()).join('\n');
              try {
                  await navigator.share({
                      title: `${currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ')} ${currentChapter}:${formatVerseRange()}`,
                      text: textToShare,
                  });
              } catch (error) {
                  console.error('Erreur de partage: ', error);
              }
          }
          hideVerseActionsMenu(); // Fermer le menu après l'action
      });
  }
  
  function setupVerseClickListeners() {
      const verseContent = document.getElementById('verse-content-placeholder');
      if (verseContent) {
          verseContent.addEventListener('click', (event) => {
              let target = event.target;
              while (target && !target.classList.contains('verse-item')) {
                  target = target.parentElement;
              }
              if (target && target.classList.contains('verse-item')) {
                  if (target.classList.contains('selected')) {
                      target.classList.remove('selected');
                      const index = selectedVerseElements.indexOf(target);
                      if (index > -1) {
                          selectedVerseElements.splice(index, 1);
                      }
                  } else {
                      target.classList.add('selected');
                      selectedVerseElements.push(target);
                  }
                  
                  const menu = document.querySelector('.verse-menu-container');
                  if (selectedVerseElements.length > 0) {
                      if (!menu) {
                          showVerseActionsMenu();
                      }
                      // Update menu title
                      const menuTitle = document.getElementById('verse-menu-title');
                      if (menuTitle) {
                          const bookTitle = currentBook.charAt(0).toUpperCase() + currentBook.slice(1).replace(/_/g, ' ').replace(/-/g, ' ');
                          menuTitle.textContent = `${bookTitle} ${currentChapter}:${formatVerseRange()}`;
                      }
                  } else {
                      if (menu) {
                          hideVerseActionsMenu();
                      }
                  }
              }
          });
      }
  }

  function init() {
    const page = document.getElementById('protestanta-page');
    if (!page) return;
    
    const menuButton = page.querySelector('.menu-button');
    if (menuButton) {
      menuButton.onclick = () => {
        showMenuPage();
        window.history.pushState({ spa: pageId, view: 'menu' }, "");
      };
    }
    fetchAndRenderVerses();
    setupScrollListener();
    setupNavigationListeners();
  }

  function handlePopState(state) {
    const spaPage = document.getElementById('protestanta-page');
    if (!spaPage) {
        return;
    }
    if (state && state.spa === pageId) {
      if (state.view === 'content' && state.chapter !== undefined && parseInt(state.chapter) === currentChapterIndex) {
      } else if (state.view === 'list') {
        hideChapter();
        hideMenuPage();
      } else {
        window.history.back();
      }
    } else {
      hideSpaPage();
    }
  }

  window.drawerPages = window.drawerPages || {};
  window.drawerPages[pageId] = {
    render: function() {
      currentView = 'list';
      return renderList();
    },
    init: init,
    destroy: function() {},
    handlePopState: handlePopState
  };
})();