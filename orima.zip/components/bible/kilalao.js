(function() {
  const pageId = 'kilalao';
  const categories = ["Débutant", "Intermédiaire", "Avancé"];
  const buttonCount = 20;
  const quizDataUrl = 'data/lisitra/quiz.json';
  const QUESTION_DURATION = 20; // in seconds

  let currentView = 'list';
  let quizData = null;
  let currentQuiz = null;
  let currentQuestionIndex = 0;
  let timerId = null;

  async function fetchQuizData() {
    if (quizData) {
      return quizData;
    }
    try {
      const response = await fetch(quizDataUrl);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      quizData = await response.json();
      return quizData;
    } catch (error) {
      console.error('Erreur lors du chargement des données de quiz:', error);
      return null;
    }
  }

  function startQuizTimer() {
    clearTimeout(timerId);
    let timeLeft = QUESTION_DURATION;
    const timerElement = document.getElementById('quiz-timer');
    if (!timerElement) return;
    
    timerElement.textContent = timeLeft;

    timerId = setInterval(() => {
      timeLeft--;
      timerElement.textContent = timeLeft;
      if (timeLeft <= 0) {
        handleTimeout();
      }
    }, 1000);
  }

  function handleTimeout() {
    clearTimeout(timerId);
    showFeedback(false, null);
  }

  function handleAnswerClick(e) {
    const button = e.target.closest('.quiz-choice');
    if (!button || button.classList.contains('disabled')) return;
    
    clearTimeout(timerId);
    
    const selectedAnswer = button.dataset.choice;
    const correctAnswer = currentQuiz[currentQuestionIndex].correct;
    const isCorrect = selectedAnswer === correctAnswer;

    showFeedback(isCorrect, selectedAnswer);
  }

  function showFeedback(isCorrect, selectedAnswer) {
    const choices = document.querySelectorAll('.quiz-choice');
    choices.forEach(choice => {
      choice.classList.add('disabled');
      if (choice.dataset.choice === selectedAnswer) {
        choice.style.backgroundColor = isCorrect ? '#4CAF50' : '#F44336';
      }
      if (choice.dataset.choice === currentQuiz[currentQuestionIndex].correct) {
        choice.style.backgroundColor = '#4CAF50';
      }
    });

    setTimeout(moveToNextQuestion, 2000);
  }

  function moveToNextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < currentQuiz.length) {
      renderQuizPage(currentQuiz, currentQuiz[currentQuestionIndex]);
    } else {
      // End of quiz logic
      alert('Quiz terminé !');
      window.history.back();
    }
  }

  function renderList() {
    let contentHtml = '';
    categories.forEach(category => {
      contentHtml += `
        <div class="category-section">
          <div class="category-title">${category}</div>
          <div class="button-grid">
            ${Array.from({ length: buttonCount }, (_, i) => `
              <div class="level-button" data-category="${category}" data-level="${i + 1}">${i + 1}</div>
            `).join('')}
          </div>
        </div>
      `;
    });

    return `
      <div class="spa-page" id="kilalao-page">
        <div class="spa-header">
          <img src="assets/icons/arrow_back.svg" alt="Back" class="back-button">
          <div class="title">Hery Kilalao</div>
        </div>
        <div class="spa-content list-container">
          ${contentHtml}
        </div>
        <style>
          .list-container {
            padding: 10px;
            margin-top: 50px;
          }
          .category-section {
            margin-bottom: 20px;
          }
          .category-title {
            font-size: 20px;
            font-weight: bold;
            color: #fff;
            margin-bottom: 10px;
            padding: 0 5px;
          }
          .button-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 10px;
            padding: 0 5px;
          }
          .level-button {
            background-color: #0F1929;
            color: #fff;
            border-radius: 8px;
            height: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.2s ease;
          }
          .level-button:active {
            background-color: #19273A;
          }
        </style>
      </div>
    `;
  }

  function renderQuizPage(quizArray, quizItem) {
    if (!quizItem) {
      return; // Should not happen with this logic, but good practice
    }

    const quizContentPage = document.getElementById('kilalao-content-page');
    if (!quizContentPage) return;

    // Shuffle the choices for the current question
    const shuffledChoices = [...quizItem.choices].sort(() => Math.random() - 0.5);

    const choicesHtml = shuffledChoices.map(choice => `
        <div class="quiz-choice" data-choice="${choice}">${choice}</div>
      `).join('');

    quizContentPage.querySelector('.quiz-question').textContent = `${currentQuestionIndex + 1}. ${quizItem.question}`;
    quizContentPage.querySelector('.quiz-choices-grid').innerHTML = choicesHtml;
    quizContentPage.querySelector('.quiz-verse').textContent = `Référence: ${quizItem.verse}`;
    
    quizContentPage.querySelector('.quiz-choices-grid').onclick = handleAnswerClick;
    
    startQuizTimer();
  }

  function renderQuizShell(level) {
    return `
      <div class="spa-page-nested" id="kilalao-content-page">
        <div class="spa-header">
          <img src="assets/icons/arrow_back.svg" alt="Back" class="chapter-back-button">
          <div class="title">Quiz ${level}</div>
        </div>
        <div class="quiz-timer-bar">
          <div id="quiz-timer"></div>
        </div>
        <div class="spa-content content-container">
          <div class="quiz-item">
            <div class="quiz-question"></div>
            <div class="quiz-choices-grid"></div>
            <p class="quiz-verse"></p>
          </div>
        </div>
        <style>
          .content-container { padding: 20px; color: #fff; line-height: 1.6; margin-top:50px;}
          .content-container p { font-size: 16px; margin-bottom: 20px; }
          .quiz-item { margin-bottom: 30px; }
          .quiz-question { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
          .quiz-choices-grid { display: grid; gap: 10px; }
          .quiz-choice {
            background-color: #19273A;
            border-radius: 8px;
            padding: 15px;
            cursor: pointer;
            transition: background-color 0.2s ease;
          }
          .quiz-choice.disabled { pointer-events: none; opacity: 0.6; }
          .quiz-verse { font-style: italic; font-size: 14px; text-align: right; margin-top: 10px; }
          .quiz-timer-bar { 
            height: 50px; 
            width: 100%; 
            background-color: #2a3e59; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            position: fixed; 
            top: 50px; 
            left: 0; 
            z-index: 10;
          }
          #quiz-timer {
            font-size: 24px;
            font-weight: bold;
            color: #fff;
          }
        </style>
      </div>
    `;
  }

  async function showChapter(category, level) {
    const page = document.getElementById('kilalao-page');
    if (!page) return;

    const allQuizzes = await fetchQuizData();
    if (!allQuizzes) {
      alert("Erreur de chargement des données de quiz.");
      return;
    }
    
    const quizKey = `quiz${level}`;
    const rawQuiz = allQuizzes[quizKey];
    
    if (!rawQuiz || rawQuiz.length === 0) {
      alert("Aucun quiz trouvé pour ce niveau.");
      return;
    }
    
    // Shuffle the entire quiz array
    currentQuiz = [...rawQuiz].sort(() => Math.random() - 0.5);
    currentQuestionIndex = 0;

    page.insertAdjacentHTML('beforeend', renderQuizShell(level));

    const nestedPage = page.querySelector('#kilalao-content-page');
    const backButton = nestedPage.querySelector('.chapter-back-button');
    if (backButton) {
      backButton.onclick = () => {
        clearTimeout(timerId);
        window.history.back();
      };
    }
    
    renderQuizPage(currentQuiz, currentQuiz[currentQuestionIndex]);
    
    setTimeout(() => {
        nestedPage.classList.add('active');
    }, 10);
  }

  function hideChapter() {
    const page = document.getElementById('kilalao-page');
    if (!page) return;

    const nestedPage = page.querySelector('#kilalao-content-page');
    if (nestedPage) {
      clearTimeout(timerId);
      nestedPage.classList.remove('active');
      nestedPage.style.transition = 'opacity 0.4s cubic-bezier(0.25, 0.8, 0.25, 1), transform 0.4s cubic-bezier(0.25, 0.8, 0.25, 1)';
      nestedPage.style.transform = 'scale(0.98)';
      nestedPage.style.opacity = '0';
      setTimeout(() => {
        nestedPage.parentNode.removeChild(nestedPage);
      }, 400);
    }
  }

  function init() {
    const page = document.getElementById('kilalao-page');
    if (!page) return;
    
    const backButton = page.querySelector('.back-button');
    if (backButton) {
      backButton.onclick = () => window.history.back();
    }

    const listContainer = page.querySelector('.list-container');
    listContainer.onclick = (e) => {
      const button = e.target.closest('.level-button');
      if (button) {
        const category = button.dataset.category;
        const level = button.dataset.level;
        showChapter(category, level);
        window.history.pushState({ spa: pageId, view: 'content', category: category, level: level }, "");
      }
    };
  }

  function handlePopState(state) {
    const spaPage = document.getElementById('kilalao-page');
    if (!spaPage) {
        return;
    }
    
    if (state && state.spa === pageId) {
      if (state.view === 'content' && state.category && state.level) {
      } else if (state.view === 'list') {
        hideChapter();
      } else {
        window.history.back();
      }
    } else {
      hideSpaPage();
    }
  }

  window.drawerPages = window.drawerPages || {};
  window.drawerPages[pageId] = {
    render: function() {
      currentView = 'list';
      return renderList();
    },
    init: init,
    destroy: function() {
        clearTimeout(timerId);
    },
    handlePopState: handlePopState
  };

})();