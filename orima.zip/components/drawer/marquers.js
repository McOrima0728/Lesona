// Fichier : components/drawer/marquers.js

window.drawerPages = window.drawerPages || {};

window.drawerPages["marquers"] = {
    render: function() {
        return `
            <style>
                /* Styles pour le header fixé */
                .spa-header {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    z-index: 1000;
                    background-color: #006A60;
                    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                    padding: 14px;
                    display: flex;
                    align-items: center;
                    color: #fff;
                }
                .spa-header img {
                    width: 24px;
                    height: 24px;
                    margin-right: 10px;
                }
                .spa-header .title {
                    font-size: 20px;
                    font-weight: bold;
                }

                .marquers-content {
                    padding: 14px;
                    margin-top: 50px;
                    background: #ffffff;
                    height: 100%;
                    display: flex;
                    flex-direction: column;
                }

                .marquers-list {
                    flex: 1;
                }

                .marquer-item {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 12px;
                    border-bottom: 1px solid #eee;
                }

                .marquer-item:last-child {
                    border-bottom: none;
                }

                .marquer-text {
                    font-size: 14px;
                    color: #fff;
                }

                .delete-btn {
                    background: none;
                    border: none;
                    cursor: none;
                    padding: 4px;
                }

                .delete-btn img {
                    width: 20px;
                    height: 20px;
                    opacity: 0.7;
                    filter: invert(1);
                }
                .delete-btn img:hover {
                    opacity: 1;
                }

                /* État vide */
                .empty-state {
                    flex: 1;
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    color: #888;
                    text-align: center;
                }
                .empty-state img {
                    width: 64px;
                    height: 64px;
                    margin-bottom: 12px;
                    opacity: 0.6;
                    filter: invert(1);
                }
            </style>

            <div class="spa-page">
                <header class="spa-header">
                    <img src="assets/icons/arrow_back.svg" alt="Retour">
                    <div class="title">Marqueurs</div>
                </header>

                <div class="spa-content marquers-content">
                    <div id="marquers-container" class="marquers-list"></div>
                </div>
            </div>
        `;
    },

    init: function() {
        console.log("Page 'Marqueurs' initialisée.");

        const container = document.getElementById("marquers-container");

        let marquers = JSON.parse(localStorage.getItem("marquers") || "[]");

        function renderMarquers() {
            container.innerHTML = "";

            if (marquers.length === 0) {
                container.innerHTML = `
                    <div class="empty-state">
                        <img src="assets/icons/bookmark_border.svg" alt="Aucun marqueur">
                        <p>Aucun marqueur</p>
                    </div>
                `;
                return;
            }

            marquers.forEach((item, index) => {
                const div = document.createElement("div");
                div.className = "marquer-item";
                div.innerHTML = `
                    <span class="marquer-text">${item}</span>
                    <button class="delete-btn" data-index="${index}">
                        <img src="assets/icons/delete.svg" alt="Supprimer">
                    </button>
                `;
                container.appendChild(div);
            });

            container.querySelectorAll(".delete-btn").forEach(btn => {
                btn.addEventListener("click", (e) => {
                    const idx = e.currentTarget.getAttribute("data-index");
                    marquers.splice(idx, 1);
                    localStorage.setItem("marquers", JSON.stringify(marquers));
                    renderMarquers();
                });
            });
        }

        renderMarquers();
    },

    destroy: function() {
        console.log("Page 'Marqueurs' détruite.");
    }
};