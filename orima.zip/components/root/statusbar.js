document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    if (window.StatusBar) {
        window.StatusBar.overlaysWebView(true);
        window.StatusBar.backgroundColorByHexString('#00000000');
        window.StatusBar.styleLightContent();
    }
}

// Récupère l'élément de la page d'accueil et le header
var accueilPage = document.getElementById("accueil");
var accueilHeader = document.getElementById("header-accueil");

accueilPage.addEventListener("scroll", function() {
    var scrollTop = accueilPage.scrollTop;
    if (window.StatusBar) {
        if (scrollTop >= 350) {
            // Le header est visible, on change la couleur de la barre de statut
            window.StatusBar.backgroundColorByHexString('#006A60');
            window.StatusBar.styleLightContent();
        } else {
            // Le header est transparent, on rend la barre de statut transparente
            window.StatusBar.backgroundColorByHexString('#00000000');
            window.StatusBar.styleLightContent();
        }
    }
});